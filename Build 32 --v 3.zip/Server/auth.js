const { authenticator } = require('otplib');

// Example inputs
const otp = '567890'; // User-provided OTP
const otp_secret = 'ABC123'; // Secret from your database

// Validate the OTP
const isValid = authenticator.check(otp, otp_secret);

if (isValid) {
    console.log('OTP is valid');
    // Proceed with generating JWT or logging the user in
} else {
    console.log('Invalid OTP');
    // Handle the invalid OTP case
}
