const sqlite3 = require("sqlite3").verbose();

exports.openDatabase = (URI_String) => {
  const connection = new sqlite3.Database(
    URI_String,
    sqlite3.OPEN_READWRITE,
    (error) => {
      if (error) {
        return console.error(error.message + "- Database failed to connect...");
      }
    }
  );

  return connection;
};

exports.closeDatabaseConnection = () => {
  educationDB.close((err) => {
    if (err) {
      return console.error(err.message);
    }
  });
};
