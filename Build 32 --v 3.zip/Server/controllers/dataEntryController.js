databaseOperation = require("../database_operations/operations");
let connectionString;

const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("database.db");
connectionString = databaseOperation.openDatabase(
  "database.db"
);


const executeTransaction = async (callback, res) => {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      db.run("BEGIN TRANSACTION", (err) => {
        if (err) {
          reject(err);
        } else {
          callback()
            .then(() => {
              db.run("COMMIT", (err) => {
                if (err) {
                  reject(err);
                } else {
                  resolve();
                }
              });
            })
            .catch((err) => {
              db.run("ROLLBACK", () => reject(err));
            });
        }
      });
    });
  }).catch((err) => {
    logger.error("Transaction Error:", err.message);
    res.status(500).json({ error: "Transaction failed" });
  });
};


exports.add_indicator_data = async (req, res) => {

    const { formData, KRA, Ministry } = req.body;

    if (!formData || !KRA || !Ministry) {
      return res.status(400).json({ error: "Form data is missing" });
    }

    const insertData = [];
    const query = `
          INSERT INTO Indicators (
            Indicator_ID,
            Indicator_Name,
            Date,
            District,
            Indicator_Value,
            KRA,
            Ministry
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

    Object.entries(formData).forEach(
      ([indicatorName, { date, district, value }]) => {
        const indicatorID = indicatorName.replace(/\s+/g, "_").toUpperCase();
        insertData.push([
          indicatorID,
          indicatorName,
          date,
          district,
          value || null,
          KRA,
          Ministry,
        ]);
      }
    );

    try {
      await executeTransaction(async () => {
        const stmt = db.prepare(query);

        for (const data of insertData) {
          await new Promise((resolve, reject) => {
            stmt.run(data, (err) => {
              if (err) {
                logger.error(`Failed to insert: ${data[0]}`, err);
                reject(err);
              } else {
                resolve();
              }
            });
          });
        }

        stmt.finalize();
      });

      res.status(200).json({ message: "Data added successfully" });
    } catch (error) {
      logger.error("Transaction Error:", error.message);
      if (!res.headersSent) {
        res.status(500).json({ error: "Failed to add data" });
      }
    }
  };


