const path = require("path");
const databaseOperation = require("../database_operations/operations");
let connectionString;

const dbPath = path.resolve("database.db");
const db = require("../database_operations/database");
connectionString = databaseOperation.openDatabase(dbPath);

const executeTransaction = async (callback, res) => {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      db.run("BEGIN TRANSACTION", (err) => {
        if (err) {
          reject(err);
        } else {
          callback()
            .then(() => {
              db.run("COMMIT", (err) => {
                if (err) {
                  reject(err);
                } else {
                  resolve();
                }
              });
            })
            .catch((err) => {
              db.run("ROLLBACK", () => reject(err));
            });
        }
      });
    });
  }).catch((err) => {
    logger.error("Transaction Error:", err.message);
    res.status(500).json({ error: "Transaction failed" });
  });
};

const validateParticipants = (participants) => {
  for (const participant of participants) {
    if (
      participant.presenceDay1 == null ||
      participant.presenceDay2 == null ||
      participant.presenceDay3 == null ||
      participant.presenceDay4 == null ||
      participant.presenceDay5 == null
    ) {
      throw new Error("All presence days must be provided.");
    }
  }
};


const insertFacilitator = (tableName, data) => {
  return new Promise((resolve, reject) => {
    const query = `INSERT INTO ${tableName} (facilitatorName, organizingMinistry, supportingAgencies, activity, subActivity, targetGroup, date, district, communityCouncil, village, venue)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    db.run(
      query,
      [
        data.facilitatorName,
        data.organizingMinistry,
        data.supportingAgencies,
        data.activity,
        data.subActivity,
        data.targetGroup,
        data.date,
        data.district,
        data.communityCouncil,
        data.village,
        data.venue, // Depending on the table structure
      ],
      function (err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID);
        }
      }
    );
  });
};

const insertParticipants = (
  tableName,
  facilitatorId,
  participants,
  participantFields
) => {
  const query = `INSERT INTO ${tableName} (${[
    "facilitatorId",
    ...participantFields,
  ].join(", ")})
                 VALUES (${Array(participantFields.length + 1)
      .fill("?")
      .join(", ")})`;

  return Promise.all(
    participants.map((participant) => {
      return new Promise((resolve, reject) => {
        db.run(
          query,
          [
            facilitatorId,
            ...participantFields.map((field) => participant[field]),
          ],
          (err) => {
            if (err) {
              reject(err);
            } else {
              resolve();
            }
          }
        );
      });
    })
  );
};

// post data

exports.community_attendance = async (req, res) => {
    console.log('Com_Att verify hit')
    const { participants, ...facilitatorData } = req.body;

    await executeTransaction(async () => {
      const facilitatorId = await insertFacilitator(
        "CommunityAttendanceFacilitator",
        facilitatorData
      );

      await insertParticipants(
        "CommunityAttendanceParticipants",
        facilitatorId,
        participants,
        [
          "name",
          "surname",
          "gender",
          "dob",
          "age",
          "village",
          "role",
          "contactNo",
        ]
      );
    }, res);

    res.json({ message: "Community attendance data successfully saved" });
  }


exports.staff_attandence = async (req, res) => {
    const { participants, ...facilitatorData } = req.body;
    await executeTransaction(async () => {
      const facilitatorId = await insertFacilitator(
        "StaffAttendanceFacilitator",
        facilitatorData
      );

      await insertParticipants(
        "StaffAttendanceParticipants",
        facilitatorId,
        participants,
        ["name", "surname", "gender", "agency", "role", "email", "contactNo"]
      );
    }, res);

    res.json({ message: "Staff attendance data successfully saved" });
  }


exports.distribution_institutions = async (req, res) => {
    const { recipients, ...facilitatorData } = req.body;

    await executeTransaction(async () => {
      const facilitatorId = await insertFacilitator(
        "InstitutionalDistributionFacilitator",
        facilitatorData
      );

      await insertParticipants(
        "InstitutionalDistributionRecipients",
        facilitatorId,
        recipients,
        [
          "name",
          "surname",
          "gender",
          "recipientVillage",
          "institutionName",
          "role",
          "items",
          "quantity",
          "contactNo",
        ]
      );
    }, res);

    res.json({ message: "Institutional distribution data successfully saved" });
  }

exports.distribution_individuals = async (req, res) => {
    const { recipients, ...facilitatorData } = req.body;

    await executeTransaction(async () => {
      const facilitatorId = await insertFacilitator(
        "IndividualDistributionFacilitator",
        facilitatorData
      );

      await insertParticipants(
        "IndividualDistributionRecipients",
        facilitatorId,
        recipients,
        [
          "name",
          "surname",
          "gender",
          "age",
          "village",
          "items",
          "quantity",
          "contactNo",
        ]
      );
    }, res);

    res.json({ message: "Individual distribution data successfully saved" });
  }


exports.community_training = async (req, res) => {
    const { participants, ...facilitatorData } = req.body;

    try {
      validateParticipants(participants);

      await executeTransaction(async () => {
        const facilitatorId = await insertFacilitator(
          "CommunityTrainingFacilitator",
          facilitatorData
        );

        await insertParticipants(
          "CommunityTrainingParticipants",
          facilitatorId,
          participants,
          [
            "name",
            "surname",
            "gender",
            "dob",
            "age",
            "village",
            "role",
            "contactNo",
            "presenceDay1",
            "presenceDay2",
            "presenceDay3",
            "presenceDay4",
            "presenceDay5",
          ]
        );
      }, res);

      // Send response after the transaction
      res.json({
        message: "Community training register data successfully saved",
      });
    } catch (error) {
      console.error(error.message);
      return res.status(400).json({ error: error.message });
    }
  }

exports.staff_training = async (req, res) => {
    const { participants, ...facilitatorData } = req.body;

    await executeTransaction(async () => {
      const facilitatorId = await insertFacilitator(
        "StaffTrainingFacilitator",
        facilitatorData
      );

      await insertParticipants(
        "StaffTrainingParticipants",
        facilitatorId,
        participants,
        [
          "name",
          "surname",
          "gender",
          "agency",
          "role",
          "email",
          "contactNo",
          "presenceDay1",
          "presenceDay2",
          "presenceDay3",
          "presenceDay4",
          "presenceDay5",
        ]
      );
    }, res);

    res.json({ message: "Staff training register data successfully saved" });
  };

exports.group_registration = async (req, res) => {
    console.log('Group Hit...')
    const {
      groupName,
      groupStatus,
      establishmentDate,
      groupType,
      district,
      communityCouncil,
      village,
      totalMembers,
      participants,
    } = req.body;

    if (
      !groupName ||
      !groupStatus ||
      !establishmentDate ||
      !groupType ||
      !district ||
      !communityCouncil ||
      !village ||
      !totalMembers ||
      !participants ||
      !participants.length
    ) {
      return res
        .status(400)
        .json({ error: "All required fields must be provided." });
    }

    try {
      await executeTransaction(async () => {
        // Insert group data into GroupRegistration table
        const insertGroup = `INSERT INTO GroupRegistration (groupName, groupStatus, establishmentDate, groupType, district, communityCouncil, village, totalFemaleMembers, totalMaleMembers, totalOtherMembers)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

        const groupId = await new Promise((resolve, reject) => {
          db.run(
            insertGroup,
            [
              groupName,
              groupStatus,
              establishmentDate,
              groupType,
              district,
              communityCouncil,
              village,
              totalMembers.female,
              totalMembers.male,
              totalMembers.other || 0,
            ],
            function (err) {
              if (err) {
                return reject(err);
              }
              resolve(this.lastID); // Get the ID of the newly inserted group
            }
          );
        });

        // Insert participants into GroupRegistrationParticipants table
        const insertParticipant = `INSERT INTO GroupRegistrationParticipants (groupId, name, surname, gender, age, village, role, contact) 
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

        const participantPromises = participants.map((participant) => {
          return new Promise((resolve, reject) => {
            db.run(
              insertParticipant,
              [
                groupId,
                participant.name,
                participant.surname,
                participant.gender,
                participant.age,
                participant.village,
                participant.role,
                participant.contact,
              ],
              (err) => {
                if (err) {
                  return reject(err);
                }
                resolve();
              }
            );
          });
        });

        await Promise.all(participantPromises);
      }, res);

      // Respond to the frontend after successful registration
      res.status(200).json({ message: "Group registration successful!" });
    } catch (err) {
      console.error(err.message);
      res
        .status(500)
        .json({ error: "Failed to register group and participants." });
    }
  };

exports.monitoring_visit = (req, res) => {
    const {
      visitBy,
      ministry,
      district,
      location,
      date,
      objectives,
      activities,
      challenges,
      mitigations,
    } = req.body;

    if (
      !visitBy ||
      !ministry ||
      !district ||
      !location ||
      !date ||
      objectives.length === 0 ||
      activities.length === 0
    ) {
      return res
        .status(400)
        .json({ error: "Missing required fields or objectives/activities." });
    }

    db.serialize(() => {
      // Insert the main Monitoring Visit data first
      const insertVisitQuery = `INSERT INTO MonitoringVisit (visitBy, ministry, district, location, date, challenges, mitigations)
                              VALUES (?, ?, ?, ?, ?, ?, ?)`;

      db.run(
        insertVisitQuery,
        [visitBy, ministry, district, location, date, challenges, mitigations],
        function (err) {
          if (err) {
            return res
              .status(500)
              .json({ error: "Failed to insert monitoring visit data." });
          }

          const visitId = this.lastID; // Get the ID of the inserted Monitoring Visit

          // Now insert each objective and its related activities
          objectives.forEach((objective, objectiveIndex) => {
            const insertObjectiveQuery = `INSERT INTO MonitoringVisitObjectives (visitId, objective) VALUES (?, ?)`;

            db.run(insertObjectiveQuery, [visitId, objective], function (err) {
              if (err) {
                return res
                  .status(500)
                  .json({ error: "Failed to insert objectives." });
              }

              const objectiveId = this.lastID; // Get the ID of the inserted objective

              // Now insert the activities related to the current objective
              const activitiesForObjective = activities[objectiveIndex];
              activitiesForObjective.forEach((activity) => {
                const insertActivityQuery = `INSERT INTO MonitoringVisitActivities (objectiveId, activity, requirement, findings)
                                         VALUES (?, ?, ?, ?)`;

                db.run(
                  insertActivityQuery,
                  [
                    objectiveId,
                    activity.activity,
                    activity.requirement,
                    activity.findings,
                  ],
                  (err) => {
                    if (err) {
                      return res
                        .status(500)
                        .json({ error: "Failed to insert activities." });
                    }
                  }
                );
              });
            });
          });

          // Send success response after all insertions are done
          res
            .status(200)
            .json({ message: "Monitoring visit data inserted successfully!" });
        }
      );
    });
  };

// get data
exports.get_community_attendance = (req, res) => {
    db.all(
      "SELECT * FROM CommunityAttendanceFacilitator",
      [],
      (err, facilitators) => {
        if (err) {
          console.error("Error retrieving facilitators:", err.message);
          return res.status(500).json({
            error: "An error occurred while retrieving facilitators.",
          });
        }

        const facilitatorIds = facilitators.map((f) => f.id);

        // Use Promise.all to fetch all participants for the facilitators
        const participantPromises = facilitatorIds.map((facilitatorId) => {
          return new Promise((resolve, reject) => {
            db.all(
              "SELECT * FROM CommunityAttendanceParticipants WHERE facilitatorId = ?",
              [facilitatorId],
              (err, participants) => {
                if (err) {
                  return reject(err);
                }
                resolve({ facilitatorId, participants });
              }
            );
          });
        });

        Promise.all(participantPromises)
          .then((participantData) => {
            // Create a map to easily access participants by facilitatorId
            const participantsByFacilitator = participantData.reduce(
              (acc, { facilitatorId, participants }) => {
                acc[facilitatorId] = participants;
                return acc;
              },
              {}
            );

            // Combine facilitators with their participants
            const result = facilitators.map((facilitator) => ({
              ...facilitator,
              participants: participantsByFacilitator[facilitator.id] || [],
            }));

            res.status(200).json(result);
          })
          .catch((err) => {
            console.error("Error retrieving participants:", err.message);
            res.status(500).json({
              error: "An error occurred while retrieving participants.",
            });
          });
      }
    );
  };

exports.get_staff_attendance = (req, res) => {
    db.all(
      "SELECT * FROM StaffAttendanceFacilitator",
      [],
      (err, facilitators) => {
        if (err) {
          console.error("Error retrieving facilitators:", err.message);
          return res.status(500).json({
            error: "An error occurred while retrieving facilitators.",
          });
        }

        const facilitatorIds = facilitators.map((f) => f.id);

        // Use Promise.all to fetch all participants for the facilitators
        const participantPromises = facilitatorIds.map((facilitatorId) => {
          return new Promise((resolve, reject) => {
            db.all(
              "SELECT * FROM StaffAttendanceParticipants WHERE facilitatorId = ?",
              [facilitatorId],
              (err, participants) => {
                if (err) {
                  return reject(err);
                }
                resolve({ facilitatorId, participants });
              }
            );
          });
        });

        Promise.all(participantPromises)
          .then((participantData) => {
            // Create a map to easily access participants by facilitatorId
            const participantsByFacilitator = participantData.reduce(
              (acc, { facilitatorId, participants }) => {
                acc[facilitatorId] = participants;
                return acc;
              },
              {}
            );

            // Combine facilitators with their participants
            const result = facilitators.map((facilitator) => ({
              ...facilitator,
              participants: participantsByFacilitator[facilitator.id] || [],
            }));

            res.status(200).json(result);
          })
          .catch((err) => {
            console.error("Error retrieving participants:", err.message);
            res.status(500).json({
              error: "An error occurred while retrieving participants.",
            });
          });
      }
    );
  };

exports.get_community_training = (req, res) => {
    db.all(
      "SELECT * FROM CommunityTrainingFacilitator",
      [],
      (err, facilitators) => {
        if (err) {
          console.error("Error retrieving facilitators:", err.message);
          return res.status(500).json({
            error: "An error occurred while retrieving facilitators.",
          });
        }

        const facilitatorIds = facilitators.map((f) => f.id);

        // Use Promise.all to fetch all participants for the facilitators
        const participantPromises = facilitatorIds.map((facilitatorId) => {
          return new Promise((resolve, reject) => {
            db.all(
              "SELECT * FROM CommunityTrainingParticipants WHERE facilitatorId = ?",
              [facilitatorId],
              (err, participants) => {
                if (err) {
                  return reject(err);
                }
                resolve({ facilitatorId, participants });
              }
            );
          });
        });

        Promise.all(participantPromises)
          .then((participantData) => {
            // Create a map to easily access participants by facilitatorId
            const participantsByFacilitator = participantData.reduce(
              (acc, { facilitatorId, participants }) => {
                acc[facilitatorId] = participants;
                return acc;
              },
              {}
            );

            // Combine facilitators with their participants
            const result = facilitators.map((facilitator) => ({
              ...facilitator,
              participants: participantsByFacilitator[facilitator.id] || [],
            }));

            res.status(200).json(result);
          })
          .catch((err) => {
            console.error("Error retrieving participants:", err.message);
            res.status(500).json({
              error: "An error occurred while retrieving participants.",
            });
          });
      }
    );
  };

exports.get_staff_training = (req, res) => {
    db.all(
      "SELECT * FROM StaffTrainingFacilitator",
      [],
      (err, facilitators) => {
        if (err) {
          console.error("Error retrieving facilitators:", err.message);
          return res.status(500).json({
            error: "An error occurred while retrieving facilitators.",
          });
        }

        const facilitatorIds = facilitators.map((f) => f.id);

        // Use Promise.all to fetch all participants for the facilitators
        const participantPromises = facilitatorIds.map((facilitatorId) => {
          return new Promise((resolve, reject) => {
            db.all(
              "SELECT * FROM StaffTrainingParticipants WHERE facilitatorId = ?",
              [facilitatorId],
              (err, participants) => {
                if (err) {
                  return reject(err);
                }
                resolve({ facilitatorId, participants });
              }
            );
          });
        });

        Promise.all(participantPromises)
          .then((participantData) => {
            // Create a map to easily access participants by facilitatorId
            const participantsByFacilitator = participantData.reduce(
              (acc, { facilitatorId, participants }) => {
                acc[facilitatorId] = participants;
                return acc;
              },
              {}
            );

            // Combine facilitators with their participants
            const result = facilitators.map((facilitator) => ({
              ...facilitator,
              participants: participantsByFacilitator[facilitator.id] || [],
            }));

            res.status(200).json(result);
          })
          .catch((err) => {
            console.error("Error retrieving participants:", err.message);
            res.status(500).json({
              error: "An error occurred while retrieving participants.",
            });
          });
      }
    );
  };

exports.get_beneficiary_distribution = (req, res) => {
    db.all(
      "SELECT * FROM IndividualDistributionFacilitator",
      [],
      (err, facilitators) => {
        if (err) {
          console.error("Error retrieving facilitators:", err.message);
          return res.status(500).json({
            error: "An error occurred while retrieving facilitators.",
          });
        }

        const facilitatorIds = facilitators.map((f) => f.id);

        // Use Promise.all to fetch all participants for the facilitators
        const participantPromises = facilitatorIds.map((facilitatorId) => {
          return new Promise((resolve, reject) => {
            db.all(
              "SELECT * FROM IndividualDistributionRecipients WHERE facilitatorId = ?",
              [facilitatorId],
              (err, participants) => {
                if (err) {
                  return reject(err);
                }
                resolve({ facilitatorId, participants });
              }
            );
          });
        });

        Promise.all(participantPromises)
          .then((participantData) => {
            // Create a map to easily access participants by facilitatorId
            const participantsByFacilitator = participantData.reduce(
              (acc, { facilitatorId, participants }) => {
                acc[facilitatorId] = participants;
                return acc;
              },
              {}
            );

            // Combine facilitators with their participants
            const result = facilitators.map((facilitator) => ({
              ...facilitator,
              participants: participantsByFacilitator[facilitator.id] || [],
            }));

            res.status(200).json(result);
          })
          .catch((err) => {
            console.error("Error retrieving participants:", err.message);
            res.status(500).json({
              error: "An error occurred while retrieving participants.",
            });
          });
      }
    );
  };

exports.get_institutional_distribution = (req, res) => {
    db.all(
      "SELECT * FROM InstitutionalDistributionFacilitator",
      [],
      (err, facilitators) => {
        if (err) {
          console.error("Error retrieving facilitators:", err.message);
          return res.status(500).json({
            error: "An error occurred while retrieving facilitators.",
          });
        }

        const facilitatorIds = facilitators.map((f) => f.id);

        // Use Promise.all to fetch all participants for the facilitators
        const participantPromises = facilitatorIds.map((facilitatorId) => {
          return new Promise((resolve, reject) => {
            db.all(
              "SELECT * FROM InstitutionalDistributionRecipients WHERE facilitatorId = ?",
              [facilitatorId],
              (err, participants) => {
                if (err) {
                  return reject(err);
                }
                resolve({ facilitatorId, participants });
              }
            );
          });
        });

        Promise.all(participantPromises)
          .then((participantData) => {
            // Create a map to easily access participants by facilitatorId
            const participantsByFacilitator = participantData.reduce(
              (acc, { facilitatorId, participants }) => {
                acc[facilitatorId] = participants;
                return acc;
              },
              {}
            );

            // Combine facilitators with their participants
            const result = facilitators.map((facilitator) => ({
              ...facilitator,
              participants: participantsByFacilitator[facilitator.id] || [],
            }));

            res.status(200).json(result);
          })
          .catch((err) => {
            console.error("Error retrieving participants:", err.message);
            res.status(500).json({
              error: "An error occurred while retrieving participants.",
            });
          });
      }
    );
  };

exports.get_group_registration = (req, res) => {
    db.all("SELECT * FROM GroupRegistration", [], (err, groups) => {
      if (err) {
        console.error("Error retrieving groups:", err.message);
        return res
          .status(500)
          .json({ error: "An error occurred while retrieving groups." });
      }

      const groupIds = groups.map((group) => group.id);

      // Use Promise.all to fetch all participants for the groups
      const participantPromises = groupIds.map((groupId) => {
        return new Promise((resolve, reject) => {
          db.all(
            "SELECT * FROM GroupRegistrationParticipants WHERE groupId = ?",
            [groupId],
            (err, participants) => {
              if (err) {
                return reject(err);
              }
              resolve({ groupId, participants });
            }
          );
        });
      });

      Promise.all(participantPromises)
        .then((participantData) => {
          const participantsByGroup = participantData.reduce(
            (acc, { groupId, participants }) => {
              acc[groupId] = participants;
              return acc;
            },
            {}
          );

          const result = groups.map((group) => ({
            ...group,
            participants: participantsByGroup[group.id] || [],
          }));

          res.status(200).json(result);
        })
        .catch((err) => {
          console.error("Error retrieving participants:", err.message);
          res.status(500).json({
            error: "An error occurred while retrieving participants.",
          });
        });
    });
  };

exports.get_monitoring_visit = (req, res) => {
    const visitQuery = `
      SELECT 
        mv.id as visitId,
        mv.visitBy,
        mv.ministry,
        mv.district,
        mv.location,
        mv.date,
        mv.challenges,
        mv.mitigations,
        mvo.id as objectiveId,
        mvo.objective,
        mva.activity,
        mva.requirement,
        mva.findings
      FROM MonitoringVisit mv
      LEFT JOIN MonitoringVisitObjectives mvo ON mv.id = mvo.visitId
      LEFT JOIN MonitoringVisitActivities mva ON mvo.id = mva.objectiveId
      ORDER BY mv.id, mvo.id
    `;

    db.all(visitQuery, [], (err, rows) => {
      if (err) {
        return res.status(500).json({ error: "Failed to retrieve data." });
      }

      // Process the rows into a structured format
      const visits = [];

      rows.forEach((row) => {
        // Check if this visit is already added
        let visit = visits.find((v) => v.visitId === row.visitId);

        if (!visit) {
          visit = {
            visitId: row.visitId,
            visitBy: row.visitBy,
            ministry: row.ministry,
            district: row.district,
            location: row.location,
            date: row.date,
            challenges: row.challenges,
            mitigations: row.mitigations,
            objectives: [],
          };
          visits.push(visit);
        }

        // Check if this objective is already added for the visit
        let objective = visit.objectives.find(
          (o) => o.objectiveId === row.objectiveId
        );

        if (!objective) {
          objective = {
            objectiveId: row.objectiveId,
            objective: row.objective,
            activities: [],
          };
          visit.objectives.push(objective);
        }

        // Add the activity under the current objective
        if (row.activity) {
          objective.activities.push({
            activity: row.activity,
            requirement: row.requirement,
            findings: row.findings,
          });
        }
      });

      res.status(200).json(visits);
    });
  };
