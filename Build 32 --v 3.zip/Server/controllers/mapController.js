databaseOperation = require("../database_operations/operations");
let connectionString;

const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("database.db");
connectionString = databaseOperation.openDatabase(
  "database.db"
);


const executeTransaction = async (callback, res) => {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      db.run("BEGIN TRANSACTION", (err) => {
        if (err) {
          reject(err);
        } else {
          callback()
            .then(() => {
              db.run("COMMIT", (err) => {
                if (err) {
                  reject(err);
                } else {
                  resolve();
                }
              });
            })
            .catch((err) => {
              db.run("ROLLBACK", () => reject(err));
            });
        }
      });
    });
  }).catch((err) => {
    logger.error("Transaction Error:", err.message);
    res.status(500).json({ error: "Transaction failed" });
  });
};


exports.get_map_indicators = async (req, res) => {

    const { indicator, year } = req.query;
  
    console.log("Filtering by indicator:", indicator, "and year:", year);
  
    // Validate query parameters
    if (!indicator || !year) {
      return res.status(400).json({ error: "Missing 'indicator' or 'year' query parameters" });
    }
  
    // SQL query to filter and group indicators
    const sql = `
      SELECT District, Indicator_Name, Indicator_Value, MAX(Date) as Date
      FROM Indicators
      WHERE Indicator_Name = ?
        AND strftime('%Y', Date) = ?
      GROUP BY District, Indicator_Name
      ORDER BY Date DESC
    `;
  
    const params = [indicator, year];
  
    // Debug query for logs
    console.log("Executing SQL:", sql, "with params:", params);
  
    db.all(sql, params, (err, rows) => {
      if (err) {
        console.error("Database error:", err.message);
        return res.status(500).json({ error: "Database error" });
      }
  
      console.log("Query results:", rows);
  
      if (rows.length === 0) {
        console.warn(`No data found for indicator '${indicator}' in year '${year}'.`);
      }
  
      res.json(rows);
    });
  };
  

  
