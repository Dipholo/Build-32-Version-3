databaseOperation = require("../database_operations/operations");
let connectionString;

const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("database.db");

connectionString = databaseOperation.openDatabase("database.db");

const executeTransaction = async (callback, res) => {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      db.run("BEGIN TRANSACTION", (err) => {
        if (err) {
          reject(err);
        } else {
          callback()
            .then(() => {
              db.run("COMMIT", (err) => {
                if (err) {
                  reject(err);
                } else {
                  resolve();
                }
              });
            })
            .catch((err) => {
              db.run("ROLLBACK", () => reject(err));
            });
        }
      });
    });
  }).catch((err) => {
    logger.error("Transaction Error:", err.message);
    res.status(500).json({ error: "Transaction failed" });
  });
};

const executeQuery = async (query, params) => {
  return new Promise((resolve, reject) => {
    db.all(query, params, (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
};

// get data
exports.get_all_indicators = async (req, res) => {
  try {
    const data = await new Promise((resolve, reject) => {
      db.all("SELECT * FROM Indicators", [], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
    res.status(200).json(data);
  } catch (error) {
    console.error("Error fetching all indicators:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.indicator_by_kra = async (req, res) => {
  const { kra } = req.params;
  try {
    const data = await new Promise((resolve, reject) => {
      db.all(
        `SELECT * FROM Indicators WHERE KRA = ?`,
        [kra],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
    res.status(200).json(data);
  } catch (error) {
    console.error("Error fetching indicator by KRA:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.indicator_by_kra_district_year = async (req, res) => {
  const { kra } = req.params;
  const { district, year, indicator } = req.query;

  if (!kra) {
    return res.status(400).json({ error: "KRA is required." });
  }

  const baseQuery = `
    SELECT strftime('%Y', Date) AS Year, Indicator_Value AS Value, District, Indicator_Name
    FROM Indicators
    WHERE KRA = ?`;

  const conditions = [];
  const params = [kra];

  if (district) {
    conditions.push("District = ?");
    params.push(district);
  }

  if (year) {
    conditions.push("strftime('%Y', Date) = ?");
    params.push(year);
  }

  if (indicator) {
    conditions.push("Indicator_Name = ?");
    params.push(indicator);
  }

  const finalQuery = `${baseQuery} ${conditions.length ? "AND " + conditions.join(" AND ") : ""}`;

  try {
    const data = await executeQuery(finalQuery, params); 
    res.status(200).json(data);
  } catch (error) {
    console.error("Error fetching indicator data:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};


exports.indicator_by_id = async (req, res) => {
  const { indicatorId } = req.params;

  try {
    const query = `
                  SELECT Indicator_Name, Date, district, Indicator_Value 
                  FROM Indicators 
                  WHERE Indicator_ID = ?
              `;
    db.all(query, [indicatorId], (err, rows) => {
      if (err) {
        console.error(err.message);
        return res.status(500).json({ error: "Failed to fetch data" });
      }
      res.status(200).json(rows);
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.impact_level_indicator = async (req, res) => {
  const { indicatorId } = req.params;

  try {
    const rows = await new Promise((resolve, reject) => {
      db.all(
        `SELECT District, strftime('%Y', Date) AS Year, Indicator_Value AS Value
             FROM Indicators
             WHERE Indicator_ID = ?`,
        [indicatorId],
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        }
      );
    });

    res.status(200).json(rows);
  } catch (error) {
    console.error("Error fetching data:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.indicator_by_ministry = async (req, res) => {
  const { ministry } = req.params;

  try {
    db.all(
      "SELECT * FROM Indicators WHERE Ministry = ?",
      [ministry],
      async (err, rows) => {
        if (err) {
          logger.error(err.message);
          return res.status(500).json({ error: "Failed to fetch data" });
        }

        res.status(200).json(rows);
      }
    );
  } catch (error) {
    logger.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

exports.indicator_by_date_range = async (req, res) => {
  const { startDate, endDate } = req.query;

  try {
    const query = `
                  SELECT * FROM Indicators 
                  WHERE Date BETWEEN ? AND ?
              `;

    db.all(query, [startDate, endDate], (err, rows) => {
      if (err) {
        console.error(err.message);
        return res.status(500).json({ error: "Failed to fetch data" });
      }
      res.status(200).json(rows);
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
