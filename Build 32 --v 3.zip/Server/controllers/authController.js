const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");



exports.checkRole = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "No token provided" });
  }

  jwt.verify(token, process.env.JWT_KEY, (error, user) => {
    if (error) {
      console.error("JWT verification error:", error);
      return res.status(403).json({ message: "Invalid token", status: 403 });
    }

    if (!user || !user.email || !user.user_permissions) {
      console.error("Token payload missing required fields:", user);
      return res
        .status(403)
        .json({ message: "Token missing necessary fields", status: 403 });
    }

    req.user = user;

    const logEntry = (status, message) => {
      const log = `${req.user.email || "Unknown User"} ${req.method} ${
        req.hostname
      } ${req.path} ${status} ${new Date().toISOString()} ${message}\n`;

      const dirPath = path.join(__dirname, "logs");
      const logFile =
        message === "AUTH FAILED" ? "adminAccess.log" : "requests.log";
      const logPath = path.join(dirPath, logFile);

      fs.mkdir(dirPath, { recursive: true }, (mkdirErr) => {
        if (mkdirErr) {
          console.error("Error creating log directory:", mkdirErr);
          return;
        }

        fs.appendFile(logPath, log, (writeErr) => {
          if (writeErr) {
            console.error("Error writing to log file:", writeErr);
          }
        });
      });
    };

    if (req.user.user_permissions !== "Admin") {
      logEntry(403, "AUTH FAILED");
      return res.status(403).json({ message: "Access denied. Admins only." });
    }

    logEntry(200, "AUTHENTICATED");
    next();
  });
};

exports.verifyToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Authorization token missing" });
  }

  jwt.verify(token, process.env.JWT_KEY, (error, user) => {
    if (error) {
      if (error.name === "TokenExpiredError") {
        return res.status(401).json({ message: "Token expired", status: 401 });
      }
      if (error.name === "JsonWebTokenError") {
        return res.status(403).json({ message: "Invalid token", status: 403 });
      }
      if (error.name === "NotBeforeError") {
        return res
          .status(403)
          .json({ message: "Token not active yet", status: 403 });
      }
      return res.status(403).json({ message: "Invalid token", status: 403 });
    }

    req.user = user;
    console.log("Token is valid. Proceeding with request...");
    next();
  });
};
