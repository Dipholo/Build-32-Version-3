const sqlite3 = require('sqlite3').verbose();

// Connect to the Users.db SQLite database
const db = new sqlite3.Database('./database_files/Users.db', (err) => {
    if (err) {
        console.error('Error connecting to the database:', err.message);
    } else {
        console.log('Connected to the Users.db database.');
    }
});

// SQL query to add the 'refreshToken' column to the 'users' table
const alterTableQuery = `ALTER TABLE users ADD COLUMN refreshToken TEXT`;

// Execute the query to update the database
db.run(alterTableQuery, (err) => {
    if (err) {
        console.error('Error altering the users table:', err.message);
    } else {
        console.log('Successfully added the refreshToken column to the users table.');
    }
});

// Close the database connection
db.close((err) => {
    if (err) {
        console.error('Error closing the database connection:', err.message);
    } else {
        console.log('Closed the database connection.');
    }
});
