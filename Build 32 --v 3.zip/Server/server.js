require("dotenv").config();
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const os = require("os");
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));


const usersRouter = require('./routes/users');
const dataEntry = require('./routes/dataEntry');
const dataCollection = require('./routes/dataCollection');
const dataVisualization = require('./routes/dataVisualization');
const mapVisualization = require('./routes/mapVisualization');

app.use('/users', usersRouter);
app.use('/api/data-entry', dataEntry);
app.use('/api/data-collection', dataCollection);
app.use('/api/data-visualization', dataVisualization)
app.use('/api/map-visualization', mapVisualization);

const serverIP = () => {
  const interfaces = os.networkInterfaces();
  let hostIP;

  Object.keys(interfaces).forEach((interfaceName) => {
    const networkInterface = interfaces[interfaceName];
    networkInterface.forEach((address) => {
      if (address.family === "IPv4" && !address.internal) {
        hostIP = address.address;
      }
    });
  });

  return hostIP;
};

const PORT = 1024 || process.env.PORT;

app.listen(PORT, ()=>{
    console.log(`Server Listening on Socket :: ${serverIP()}:${PORT}`);
})
