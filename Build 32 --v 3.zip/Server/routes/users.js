const express = require("express");
const router = express.Router();
const sqlite3 = require("sqlite3").verbose();
const bodyParser = require("body-parser");
require("dotenv").config();
router.use(express.json());
router.use(bodyParser.json());
const authController = require("../controllers/authController");
const bcrypt = require("bcrypt");
require("dotenv").config();
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");
const speakeasy = require("speakeasy");
const fs = require("fs");
const path = require("path");

const transporter = nodemailer.createTransport({
  service: "Gmail",
  host: "smtp.gmail.com",
  secure: true,
  port: 465,
  auth: {
    user: process.env.EMAIL_USERNAME,
    pass: process.env.APP_PASSWORD,
  },
  tls: {
    rejectUnauthorized: false,
  },
});

//database connections
const database = new sqlite3.Database(
  "database.db",
  sqlite3.OPEN_READWRITE,
  (error) => {
    if (error) {
      return console.error(error.message);
    }

    console.log("RUNNING :: Connected to the Database.....");
  }
);

const userDB = new sqlite3.Database(
  "users_database.db",
  sqlite3.OPEN_READWRITE,
  (error) => {
    if (error) {
      return console.error(
        error.message + "Users database could not connect..."
      );
    }
  }
);

function closeDatabaseConnection() {
  database.close((err) => {
    if (err) {
      return console.error(err.message);
    }
  });
}

router.post("/reg", authController.checkRole, async (req, res) => {
  const { name, email, branch, user_permissions, status } = req.body;

  console.log(req.body);

  if (!name || !email || !user_permissions || !branch || !status) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const emailRegex =
    /^[a-zA-Z0-9._%+-]+@(gmail\.com|outlook\.com|yahoo\.com|co\.ls|gov)$/;
  if (!emailRegex.test(email)) {
    return res
      .status(400)
      .json({ message: "Please Enter Valid Email Address" });
  }

  try {
    userDB.run(
      `INSERT INTO users (name, email, branch, user_permissions, status) 
       VALUES (?, ?, ?, ?, ?)`,
      [name, email, branch, user_permissions, status],
      function (error) {
        if (error) {
          console.log(error.message);
          return res
            .status(500)
            .json({ message: "Failed to register user", error: error.message });
        }
        return res.status(201).json({
          message: "User registered successfully",
          userId: this.lastID,
        });
      }
    );
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
});

router.put("/update-user/:email", authController.checkRole, (req, res) => {
  const userEmail = req.params.email;
  const { name, branch, user_permissions, status } = req.body;

  // Validate the input
  if (!name || !branch || !user_permissions || !status) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const emailRegex =
    /^[a-zA-Z0-9._%+-]+@(gmail\.com|outlook\.com|yahoo\.com|co\.ls|gov)$/;
  if (!emailRegex.test(userEmail)) {
    return res.status(400).json({ message: "Invalid email format" });
  }

  userDB.run(
    `UPDATE users 
     SET name = ?, branch = ?, user_permissions = ?, status = ? 
     WHERE email = ?`,
    [name, branch, user_permissions, status, userEmail],
    function (error) {
      if (error) {
        return res
          .status(500)
          .json({ message: "Database error", error: error.message });
      }

      if (this.changes === 0) {
        return res
          .status(404)
          .json({ message: "User not found or no changes made" });
      }

      res.status(200).json({ message: "User updated successfully" });
    }
  );
});

router.post("/login", (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({ message: "Email is required", status: false });
  }

  userDB.get(`SELECT * FROM users WHERE email = ?`, [email], (err, user) => {
    if (err) {
      return res
        .status(500)
        .json({ message: "Database error", status: false, error: err.message });
    }

    if (!user) {
      return res.status(404).json({ message: "User not found", status: false });
    }

    const secret = speakeasy.generateSecret({ length: 20 }).base32;
    const otp = speakeasy.totp({
      secret: secret,
      encoding: "base32",
      step: 60,
      window: 2,
    });
    const expiry = Date.now() + 5 * 60 * 1000;

    userDB.run(
      `UPDATE users SET otp_secret = ?, otp_expiry = ? WHERE id = ?`,
      [secret, expiry, user.id],
      (updateErr) => {
        if (updateErr) {
          return res
            .status(500)
            .json({ message: "Failed to save OTP", status: false });
        }

        const mailOptions = {
          from: process.env.EMAIL_USERNAME,
          to: email,
          subject: "Your OTP Code",
          text: `Your OTP is ${otp}. It will expire in 5 minutes.`,
        };

        transporter.sendMail(mailOptions, (mailErr, info) => {
          if (mailErr) {
            return res.status(500).json({
              message: "Failed to send OTP email",
              status: false,
              error: mailErr.message,
            });
          }

          res.status(200).json({
            message: "OTP sent to your email address. Please check your inbox.",
            status: true,
          });          
        });
      }
    );
  });
});


router.post("/validate-otp", (req, res) => {
  const { email, otp } = req.body;

  if (!email || !otp) {
    return res.status(400).json({ message: "Email and OTP are required" });
  }

  userDB.get(
    `SELECT email, otp_secret, otp_expiry, user_permissions FROM users WHERE email = ?`,
    [email],
    (err, user) => {
      if (err) {
        return res
          .status(500)
          .json({ message: "Database error", error: err.message });
      }

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (Date.now() > user.otp_expiry) {
        return res
          .status(400)
          .json({ message: "OTP has expired, please request a new one" });
      }

      const isValid = speakeasy.totp.verify({
        secret: user.otp_secret,
        encoding: "base32",
        token: otp,
        step: 60,
        window: 2,
      });

      if (!isValid) {
        return res
          .status(400)
          .json({ message: "Invalid OTP, please try again", status: false });
      }

      const accessToken = jwt.sign(
        { email: user.email, user_permissions: user.user_permissions },
        process.env.JWT_KEY,
        { expiresIn: "1d" }
      );

      const refreshToken = jwt.sign(
        { email: user.email },
        process.env.JWT_REF_KEY,
        { expiresIn: "7d" }
      );

      userDB.run(
        `UPDATE users SET refresh_token = ? WHERE email = ?`,
        [refreshToken, email],
        (dbErr) => {
          if (dbErr) {
            return res.status(500).json({
              message: "Failed to store refresh token",
              error: dbErr.message,
            });
          }

          const log = `LOGIN ${email} ${req.method} ${req.hostname} ${
            req.path
          } ${req.status} ${new Date(
            Date.now()
          ).toString()}\n ${"UNAUTHENTICATED"}`;
          const dirPath = path.join(__dirname, "./controllers/logs");
          const logPath = path.join(dirPath, "requests.log");

          res.status(200).json({
            message: "OTP validated Successfully",
            status: true,
            accessToken: accessToken,
            refreshToken: refreshToken,
          });

          fs.mkdir(dirPath, { recursive: true }, (mkdirErr) => {
            if (mkdirErr) {
              console.error("Error creating log directory:", mkdirErr);
              return next();
            }

            fs.appendFile(logPath, log, (writeErr) => {
              if (writeErr) {
                console.error("Error writing to log file:", writeErr);
              }
            });
          });
        }
      );
    }
  );
});

router.get("/get-users", authController.checkRole, (req, res) => {
  const query = `SELECT name, email, branch, user_permissions, status FROM users`;
  userDB.all(query, [], (err, rows) => {
    if (err) {
      console.error(err.message);
      return res.status(500).json({
        message: "Error fetching users from the database",
        error: err.message,
      });
    }

    if (rows.length === 0) {
      return res.status(404).json({ message: "No users found" });
    }
    return res.status(200).json(rows);
  });
});

router.post("/token", (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(400).json({ message: "Refresh token required" });
  }

  userDB.get(
    `SELECT * FROM users WHERE refresh_token = ?`,
    [refreshToken],
    (err, user) => {
      if (err) {
        return res
          .status(500)
          .json({ message: "Database error", error: err.message });
      }

      if (!user) {
        return res.status(403).json({ message: "Invalid refresh token" });
      }

      jwt.verify(refreshToken, process.env.JWT_REF_KEY, (err, decoded) => {
        if (err) {
          return res.status(403).json({ message: "Invalid refresh token" });
        }

        const newAccessToken = jwt.sign(
          {
            id: user.id,
            email: user.email,
            user_permissions: user.user_permissions,
          },
          process.env.JWT_KEY,
          { expiresIn: "1d" }
        );

        const newRefreshToken = jwt.sign(
          { id: user.id, email: user.email },
          process.env.JWT_REF_KEY,
          { expiresIn: "7d" }
        );

        // Update the refresh token in the database
        userDB.run(
          `UPDATE users SET refresh_token = ? WHERE id = ?`,
          [newRefreshToken, user.id],
          (err) => {
            if (err) {
              return res
                .status(500)
                .json({ message: "Failed to update refresh token" });
            }

            res.status(200).json({
              status: true,
              accessToken: newAccessToken,
              refreshToken: newRefreshToken,
            });
          }
        );
      });
    }
  );
});

//just added this here man
router.post("/validate-token", (req, res) => {
  const { token } = req.body;

  if (!token) {
    return res.status(400).json({ message: "Token is required" });
  }

  jwt.verify(token, process.env.JWT_KEY, (err, decoded) => {
    if (err) {
      return res
        .status(403)
        .json({ message: "Invalid or expired token", status: false });
    }

    res.status(200).json({
      message: "Token is valid",
      status: true,
      decodedToken: decoded, 
    });
  });
});

router.delete("/delete-user/:email", authController.checkRole, (req, res) => {
  const userEmail = req.params.email;

  userDB.run(`DELETE FROM USERS WHERE email = ?`, userEmail, function (error) {
    if (error) {
      return res
        .status(500)
        .json({ message: "Database error", error: error.message });
    }

    if (this.changes === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({ message: "User deleted successfully" });
  });
});

router.post("/logout", (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(400).json({ message: "Refresh token is required" });
  }

  userDB.run(
    `UPDATE users SET refresh_token = NULL WHERE refresh_token = ?`,
    [refreshToken],
    (err) => {
      if (err) {
        return res
          .status(500)
          .json({ message: "Failed to logout", error: err.message });
      }

      res.status(200).json({ message: "Logged out successfully" });
    }
  );
});

module.exports = router;
