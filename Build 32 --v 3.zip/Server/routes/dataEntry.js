const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
router.use(express.json());
router.use(bodyParser.json());

const dataEntryController = require('../controllers/dataEntryController');
const authController = require('../controllers/authController');

// adding indicator data to database
router.post('/add-indicator-data', authController.verifyToken, dataEntryController.add_indicator_data);

module.exports = router;
