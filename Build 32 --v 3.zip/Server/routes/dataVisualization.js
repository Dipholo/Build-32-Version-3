const express = require("express");
const router = express.Router();
const bodyParser = require("body-parser");
router.use(express.json());
router.use(bodyParser.json());

const dataVisualizationController = require("../controllers/dataVisualizationController");
const authController = require("../controllers/authController");


// get indicator data from database
router.get(
  "/get-all-indicators",
  authController.verifyToken,
  dataVisualizationController.get_all_indicators
);
router.get(
  "/indicator-by-kra/:kra",
  authController.verifyToken,
  dataVisualizationController.indicator_by_kra
);
router.get(
  "/indicator-by-kra-district-year/:kra",
  authController.verifyToken,
  dataVisualizationController.indicator_by_kra_district_year
);
router.get(
  "/indicator-by-id",
  authController.verifyToken,
  dataVisualizationController.indicator_by_id
);
router.get(
  "/impact-level-indicator",
  authController.verifyToken,
  dataVisualizationController.impact_level_indicator
);
router.get(
  "/indicator-by-ministry",
  authController.verifyToken,
  dataVisualizationController.indicator_by_ministry
);
router.get(
  "/indicator-by-date-range",
  authController.verifyToken,
  dataVisualizationController.indicator_by_date_range
);

module.exports = router;
