const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
router.use(express.json());
router.use(bodyParser.json());

const dataCollectionController = require('../controllers/dataCollectionController');
const authController = require('../controllers/authController');

// adding collection tools data to database
router.post('/community-attendance', authController.verifyToken, dataCollectionController.community_attendance);
router.post('/staff-attendance', authController.verifyToken, dataCollectionController.staff_attandence);
router.post('/distribution-institutions', authController.verifyToken, dataCollectionController.distribution_institutions);
router.post('/distribution-individuals', authController.verifyToken, dataCollectionController.distribution_individuals);
router.post('/community-training', authController.verifyToken, dataCollectionController.community_training);
router.post('/staff-training', authController.verifyToken, dataCollectionController.staff_training);
router.post('/group-registration', authController.verifyToken, dataCollectionController.group_registration);
router.post('/monitoring-visit', authController.verifyToken, dataCollectionController.monitoring_visit);

// get data collection tools data from database
router.get('/get-community-attendance', authController.verifyToken, dataCollectionController.get_community_attendance);
router.get('/get-staff-attendance', authController.verifyToken, dataCollectionController.get_staff_attendance);
router.get('/get-community-training', authController.verifyToken, dataCollectionController.get_community_training);
router.get('/get-staff-training', authController.verifyToken, dataCollectionController.get_staff_training);
router.get('/get-beneficiary-distribution', authController.verifyToken, dataCollectionController.get_beneficiary_distribution);
router.get('/get-institutional-distribution', authController.verifyToken, dataCollectionController.get_institutional_distribution);
router.get('/get-group-registration', authController.verifyToken, dataCollectionController.get_group_registration);
router.get('/get-monitoring-visit', authController.verifyToken, dataCollectionController.get_monitoring_visit);

module.exports = router;
