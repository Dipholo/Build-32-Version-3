const express = require("express");
const router = express.Router();
const  getMapIndicators = require("../controllers/mapController");

router.get("/filter", getMapIndicators.get_map_indicators);

module.exports = router;
