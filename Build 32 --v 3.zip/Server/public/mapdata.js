var simplemaps_countrymap_mapdata={
  main_settings: {
   //General settings
    width: "responsive", //'700' or 'responsive'
    background_color: "#FFFFFF",
    background_transparent: "yes",
    border_color: "#ffffff",
    
    //State defaults
    state_description: "State description",
    state_color: "#D2B48C",
    state_hover_color: "#D2691E",
    state_url: "",
    border_size: 1.5,
    all_states_inactive: "no",
    all_states_zoomable: "yes",
    
    //Location defaults
    location_description: "Location description",
    location_url: "",
    location_color: "#FF0067",
    location_opacity: 0.8,
    location_hover_opacity: 1,
    location_size: 25,
    location_type: "square",
    location_image_source: "frog.png",
    location_border_color: "#FFFFFF",
    location_border: 2,
    location_hover_border: 2.5,
    all_locations_inactive: "no",
    all_locations_hidden: "no",
    
    //Label defaults
    label_color: "#ffffff",
    label_hover_color: "#ffffff",
    label_size: "20",
    label_font: "Arial",
    label_display: "auto",
    label_scale: "yes",
    hide_labels: "no",
    hide_eastern_labels: "no",
   
    //Zoom settings
    zoom: "yes",
    manual_zoom: "yes",
    back_image: "no",
    initial_back: "no",
    initial_zoom: "-1",
    initial_zoom_solo: "no",
    region_opacity: 1,
    region_hover_opacity: 0.6,
    zoom_out_incrementally: "yes",
    zoom_percentage: 0.99,
    zoom_time: 0.5,
    
    //Popup settings
    popup_color: "white",
    popup_opacity: 0.9,
    popup_shadow: 1,
    popup_corners: 5,
    popup_font: "12px/1.5 Verdana, Arial, Helvetica, sans-serif",
    popup_nocss: "no",
    
    //Advanced settings
    div: "map",
    auto_load: "yes",
    url_new_tab: "no",
    images_directory: "default",
    fade_time: 0.1,
    link_text: "View Website",
    popups: "detect",
    state_image_url: "",
    state_image_position: "",
    location_image_url: ""
  },
  state_specific: {
    LSA: {
      name: "Maseru",
      description: " "
    },
    LSB: {
      name: "Butha-Buthe",
      description: " "
    },
    LSC: {
      name: "Leribe",
      description: " "
    },
    LSD: {
      name: "Berea",
      description: " "
    },
    LSE: {
      name: "Mafeteng",
      description: " "
    },
    LSF: {
      name: "Mohale's Hoek",
      description: " "
    },
    LSG: {
      name: "Quthing",
      description: " "
    },
    LSH: {
      name: "Qacha's Nek",
      description: " "
    },
    LSJ: {
      name: "Mokhotlong",
      description: " "
    },
    LSK: {
      name: "Thaba-Tseka",
      description: " "
    }
  },
  locations: {},
  labels: {
    "0": {
      name: "Maseru",
      parent_id: "LSA",
      x: 361.8,
      y: 471.6
    },
    "1": {
      name: "Butha-Buthe",
      parent_id: "LSB",
      x: 625.4,
      y: 122.2
    },
    "2": {
      name: "Leribe",
      parent_id: "LSC",
      x: 530.8,
      y: 210.5
    },
    "3": {
      name: "Berea",
      parent_id: "LSD",
      x: 374.2,
      y: 306.4
    },
    "4": {
      name: "Mafeteng",
      parent_id: "LSE",
      x: 142.2,
      y: 533.2
    },
    "5": {
      name: "Mohale's Hoek",
      parent_id: "LSF",
      x: 255.4,
      y: 730.2
    },
    "6": {
      name: "Quthing",
      parent_id: "LSG",
      x: 386.8,
      y: 842.6
    },
    "7": {
      name: "Qacha's Nek",
      parent_id: "LSH",
      x: 663.6,
      y: 655.3
    },
    "8": {
      name: "Mokhotlong",
      parent_id: "LSJ",
      x: 810.5,
      y: 338.1
    },
    "9": {
      name: "Thaba-Tseka",
      parent_id: "LSK",
      x: 579.1,
      y: 466.7
    }
  },
  legend: {
    entries: []
  },
  regions: {},
  data: {
    data: {}
  }
};