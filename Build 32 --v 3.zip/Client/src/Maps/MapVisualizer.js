import React, { useEffect, useState } from "react";
import axios from "axios";
import "./MapVisualizer.css";

const MapVisualizer = ({ selectedStat }) => {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [scriptLoaded, setScriptLoaded] = useState(false);

  // Load simplemaps scripts dynamically
  const loadSimplemapsScripts = async () => {
    const loadScript = (src) => {
      return new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = src;
        script.async = true;
        script.onload = resolve;
        script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
        document.body.appendChild(script);
      });
    };

    try {
      await loadScript("http://localhost:1024/mapdata.js");
      console.log("Mapdata.js loaded successfully.");
      await loadScript("http://localhost:1024/countrymap.js");
      console.log("Countrymap.js loaded successfully.");
      setScriptLoaded(true);
    } catch (error) {
      console.error(error.message);
    }
  };

  useEffect(() => {
    loadSimplemapsScripts();
  }, []);

  useEffect(() => {
    console.log("Selected indicator:", selectedStat);
    const fetchData = async () => {
      if (!selectedStat) return;

      try {
        const encodedIndicator = encodeURIComponent(selectedStat);
        const currentYear = new Date().getFullYear();
        const url = `http://localhost:1024/api/map-visualization/filter?indicator=${encodedIndicator}&year=${currentYear}`;

        const response = await axios.get(url);
        setData(response.data);
        setError(null);
      } catch (err) {
        console.error("Error fetching data for the map:", err.message);
        setError("Failed to fetch data. Please check the console for details.");
      }
    };

    fetchData();
  }, [selectedStat]);

  useEffect(() => {
    const initializeMap = () => {
      const interval = setInterval(() => {
        if (typeof window.simplemaps_countrymap !== "undefined") {
          clearInterval(interval);
          // Load the map from SimpleMaps
          window.simplemaps_countrymap.load(
            "https://simplemaps.com/custom/country/DlGcskdb"
          );
          console.log("Simplemaps initialized successfully.");
        } else {
          console.log("Waiting for simplemaps_countrymap to be defined...");
        }
      }, 100);

      return () => clearInterval(interval);
    };

    if (scriptLoaded) {
      initializeMap();
    }
  }, [scriptLoaded]);

  useEffect(() => {
    if (data) {
      const updateMapData = () => {
        if (
          window.simplemaps_countrymap &&
          typeof window.simplemaps_countrymap.refresh === "function"
        ) {
          const mapdata = window.simplemaps_countrymap_mapdata;

          // Reset map data
          Object.keys(mapdata.state_specific).forEach((districtCode) => {
            mapdata.state_specific[districtCode].description = "No data available";
            mapdata.state_specific[districtCode].color = "#D3D3D3"; // Grey for no data
          });

          // Update map data with fetched data
          data.forEach((entry) => {
            const districtCode = getDistrictCode(entry.District);
            if (mapdata.state_specific[districtCode]) {
              mapdata.state_specific[districtCode].description = `${selectedStat}: ${entry.Indicator_Value}`;
              mapdata.state_specific[districtCode].color = getColorForValue(
                entry.Indicator_Value
              );
            }
          });

          // Refresh the map
          window.simplemaps_countrymap.refresh();
          console.log("Simplemaps data updated successfully.");
        } else {
          console.error("Simplemaps mapdata or refresh function is undefined.");
        }
      };

      updateMapData();
    }
  }, [data, selectedStat]);

  const getDistrictCode = (district) => {
    const districtMap = {
      Maseru: "LSA",
      "Butha-Buthe": "LSB",
      Leribe: "LSC",
      Berea: "LSD",
      Mafeteng: "LSE",
      "Mohale's Hoek": "LSF",
      Quthing: "LSG",
      "Qacha's Nek": "LSH",
      Mokhotlong: "LSJ",
      "Thaba-Tseka": "LSK",
    };
    return districtMap[district] || null;
  };

  const getColorForValue = (value) => {
    if (value < 10) return "#28a745"; // Green for low
    if (value < 20) return "#007bff"; // Blue for moderate
    return "#dc3545"; // Red for high
  };

  return (
    <div className="map-container">
      {error && <p className="text-danger">{error}</p>}

      <div id="map"></div>

      {/* Color Legend */}
      <div className="color-legend">
        <label className="mapKeys-title">Map Keys</label>
        <div className="keys-container">
          <div className="key-elements">
            <button className="low-key-btn" style={{ backgroundColor: "#28a745" }}></button>
            <label className="key-label">Low</label>
          </div>
          <div className="key-elements">
            <button className="low-key-btn" style={{ backgroundColor: "#007bff" }}></button>
            <label className="key-label">Moderate</label>
          </div>
          <div className="key-elements">
            <button className="low-key-btn" style={{ backgroundColor: "#dc3545" }}></button>
            <label className="key-label">High</label>
          </div>
          <div className="key-elements">
            <button className="low-key-btn" style={{ backgroundColor: "#D3D3D3" }}></button>
            <label className="key-label">No Data Available</label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapVisualizer;