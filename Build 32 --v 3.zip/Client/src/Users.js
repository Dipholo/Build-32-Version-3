import React, { useState, useEffect, useRef } from "react";
import "./Tools.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import Footer from "./Footer";
import { MdCheckCircleOutline } from "react-icons/md";
import { IoClose } from "react-icons/io5";
import { IoMdAdd } from "react-icons/io";
import { MdEdit } from "react-icons/md";
import { MdDelete } from "react-icons/md";
import axios from "axios";
import { jwtDecode } from "jwt-decode";
import { useNavigate } from "react-router-dom";

const Users = () => {
  const navigate = useNavigate();

  const [alertType, setAlertType] = useState(null);
  const [showAddUserForm, setShowAddUserForm] = useState(false);
  const [showAddUserSuccessAlert, setShowAddUserSuccessAlert] = useState("");

  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [branch, setBranch] = useState("");
  const [permissions, setPermissions] = useState("");
  const [status, setStatus] = useState("");

  const [users, setUsers] = useState([]);
  const [showEditUserForm, setShowEditUserForm] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    if (alertType) {
      const timer = setTimeout(() => setAlertType(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [alertType]);

  const [userPermissions, setUserPermissions] = useState(null);
  const accessToken = sessionStorage.getItem("accessToken");
  const refreshToken = sessionStorage.getItem("refreshToken");

  useEffect(() => {
    if (accessToken) {
      try {
        const decodedToken = jwtDecode(accessToken);
        const permissions = decodedToken.user_permissions;
        setUserPermissions(permissions);
      } catch (error) {
        console.error("Error decoding token:", error);
      }
    }
  }, []);

  // Functions to toggle visibility of popups
  const handleAddUserClick = () => {
    setShowAddUserForm(true);
    setShowEditUserForm(false);
  };

  const handleCloseAddUserForm = () => {
    setShowAddUserForm(false);
  };

  const handleEditUserClick = (user) => {
    setCurrentUser(user);
    setShowEditUserForm(true);
  };
  // Handler for adding a user
  const handleAddUserSubmit = (e) => {
    e.preventDefault();
    setAlertType("add"); // Trigger "add" alert
    setShowAddUserForm(false); // Close the add-user form
  };

  const handleCloseEditUserForm = () => {
    setShowEditUserForm(false);
    setCurrentUser(null);
  };

  const handleEditUserSubmit = (event) => {
    event.preventDefault();

    const { email, name, branch, user_permissions, status } = currentUser;

    // we can do input validation here before sending

    axios
      .put(
        `http://localhost:1024/users/update-user/${email}`,
        { name, branch, user_permissions, status },
        {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
        }
      )
      .then((response) => {
        setShowEditUserForm(false);
        alert("User updated successfully.");
      })
      .catch((error) => {
        console.error(
          "Error updating user:",
          error.response?.data || error.message
        );

        // Handle error based on status code
        if (error.response?.status === 404) {
          alert("User not found.");
        }
      });
  };

  const handleDeleteUser = (userEmail) => {
    axios
      .delete(`http://localhost:1024/users/delete-user/${userEmail}`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      })
      .then((response) => {
        console.log(response.data.message);
        setUsers(users.filter((user) => user.email !== userEmail));
      })
      .catch((error) => {
        console.error(
          "Error deleting user:",
          error.response?.data || error.message
        );
      });
  };

  useEffect(() => {
    axios
      .get("http://localhost:1024/users/get-users", {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      })
      .then((response) => {
        setUsers(response.data);
      })
      .catch(async (error) => {
    
        if (error.response?.status === 403) {
          try {
            const refreshResponse = await axios.post(
              "http://localhost:1024/users/token",
              {
                refreshToken: sessionStorage.getItem("refreshToken"),
              }
            );

            const newAccessToken = refreshResponse.data.accessToken;
            sessionStorage.setItem("accessToken", newAccessToken);
          } catch (refreshError) {
            console.error(
              "Error during token refresh:",
              refreshError.response?.data || refreshError.message
            );

            alert("Session expired. Please log in again.");

            const refreshToken = sessionStorage.getItem("refreshToken");

            axios
              .post("http://localhost:1024/users/token", { refreshToken })
              .then((response) => {
                sessionStorage.setItem('accessToken', response.data.accessToken);
                sessionStorage.setItem('refreshToken', response.data.refreshToken);
              })
              .catch((error) => {
                alert("Session expired. Please log in again.");
                navigate("/");
              });
          }
        } else {
          // mona we may handle other types of errors
          console.error(
            "Error when adding user:",
            error.response?.data || error.message
          );
        }
      });
  }, []);

  const [AddSuccess, setAddSuccess] = useState(false);

  const handleAddUser = async (event) => {
    event.preventDefault();

    const userData = {
      name: userName,
      email: userEmail,
      branch: branch,
      user_permissions: permissions,
      status: status,
    };

    console.log(userData);

    try {
      const res = await axios.post(
        "http://localhost:1024/users/reg",
        userData,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      setShowAddUserSuccessAlert(res.data.message);
      setAddSuccess(true);
      console.log(res.data.message);
    } catch (error) {
      //status 403 keha token ele expired
      if (error.response?.status === 403) {
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);

          const retryResponse = await axios.post(
            "http://localhost:1024/users/reg",
            userData,
            {
              headers: {
                Authorization: `Bearer ${newAccessToken}`,
              },
            }
          );
          setShowAddUserSuccessAlert(retryResponse.data.message);
          setAddSuccess(true);
          console.log(retryResponse.data.message);
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );
          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/logout", { refreshToken })
            .then(() => {
              sessionStorage.removeItem("accessToken");
              sessionStorage.removeItem("refreshToken");
              alert("Logout successful!");
              navigate("/");
            })
            .catch((error) => {
              console.error(
                "Error during logout:",
                error.response?.data || error.message
              );
            });
          navigate("/");
        }
      } else {
        // mona we may handle other types of errors
        console.error(
          "Error when adding user:",
          error.response?.data || error.message
        );
      }
    }
  };

  return (
    <div className="tools">
      <Sidebar />

      <div className="main-content">
        {/* topbar */}
        <Topbar />

        <div className="dashboard-content">
          {/* Alerts */}
          {AddSuccess && (
            <div className="alert alert-success">
              <div>
                <MdCheckCircleOutline size={22} /> {showAddUserSuccessAlert}
              </div>
              <IoClose size={22} onClick={() => setAlertType(null)} />
            </div>
          )}

          {alertType === "edit" && (
            <div className="alert alert-success">
              <div>
                <MdCheckCircleOutline size={22} /> Well done! User Edited
                Successfully.
              </div>
              <IoClose size={22} onClick={() => setAlertType(null)} />
            </div>
          )}

          {alertType === "delete" && (
            <div className="alert alert-success">
              <div>
                <MdCheckCircleOutline size={22} /> Well done! User deleted
                successfully.
              </div>
              <IoClose size={22} onClick={() => setAlertType(null)} />
            </div>
          )}

          {/* Header */}
          <div className="users-header">
            <span className="toolsTitle">
              <strong>
                User’s
                <span style={{ color: "#168645" }}> List</span>
              </strong>
            </span>
            <button className="add-user-btn" onClick={handleAddUserClick}>
              <IoMdAdd /> Add New User
            </button>
          </div>

          {/* Add New User Form */}
          {showAddUserForm && (
            <div className="add-user-form">
              <form onSubmit={handleAddUserSubmit}>
                <div className="form-group-container">
                  <label className="form-group-label">
                    Name <label style={{ color: "#db4a3a" }}>*</label>
                  </label>
                  <input
                    type="text"
                    onChange={(e) => setUserName(e.target.value)}
                    className="form-control"
                    required
                  />
                </div>

                <div className="form-group-container">
                  <label className="form-group-label">
                    Email <label style={{ color: "#db4a3a" }}>*</label>
                  </label>
                  <input
                    type="email"
                    onChange={(e) => setUserEmail(e.target.value)}
                    className="form-control"
                    required
                  />
                </div>

                <div className="form-group-container">
                  <label className="form-group-label">
                    Branch <label style={{ color: "#db4a3a" }}>*</label>
                  </label>
                  <select
                    className="form-control"
                    onClick={(e) => setBranch(e.target.value)}
                    required
                  >
                    <option value="HQ">Headquarters - Maseru</option>
                    <option value="Leribe">District - Leribe</option>
                    <option value="Berea">District - Berea</option>
                    <option value="Butha-Buthe">District - Butha-Buthe</option>
                    <option value="Mafeteng">District - Mafeteng</option>
                    <option value="Mohale's Hoek">
                      District - Mohale's Hoek
                    </option>
                    <option value="Quthing">District - Quthing</option>
                    <option value="Qacha's Nek">District - Qacha's Nek</option>
                    <option value="Thaba Tseka">District - Thaba Tseka</option>
                    <option value="Mokhotlong">District - Mokhotlong</option>
                  </select>
                </div>

                <div className="form-group-container">
                  <label className="form-group-label">
                    User Permissions{" "}
                    <label style={{ color: "#db4a3a" }}>*</label>
                  </label>
                  <select
                    className="form-control"
                    onClick={(e) => {
                      {
                        setPermissions(e.target.value);
                      }
                    }}
                    required
                  >
                    <option value="Operational">Operational</option>
                    <option value="Admin">Admin</option>
                  </select>
                </div>
                <div className="form-group-container">
                  <label className="form-group-label">
                    Status <label style={{ color: "#db4a3a" }}>*</label>
                  </label>
                  <div className="status-choices">
                    <div className="active-container">
                      <input
                        type="radio"
                        id="active"
                        name="status"
                        value="Active"
                        onChange={(e) => setStatus(e.target.value)}
                      />
                      <label htmlFor="active">Active</label>
                    </div>

                    <div className="inactive-container">
                      <input
                        type="radio"
                        id="inactive"
                        name="status"
                        value="Inactive"
                        onChange={(e) => setStatus(e.target.value)}
                      />
                      <label htmlFor="inactive">Inactive</label>
                    </div>
                  </div>
                </div>

                <div className="edit-user-btn-container">
                  <button
                    type="submit"
                    className="edit-user-btn-two"
                    onClick={handleAddUser}
                  >
                    Add
                  </button>

                  <button
                    type="button"
                    className="edit-user-btn-one"
                    onClick={handleCloseAddUserForm}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Search Bar */}
          <div className="search-bar">
            <input
              type="text"
              placeholder="Search user name, email..."
              className="user-search-input"
            />
            <select className="permissions-select">
              <option>User Permissions</option>
              <option>Admin</option>
              <option>Operational</option>
            </select>
            <button className="user-search-btn">Search</button>
          </div>

          {/* User Table */}
          <table className="user-table">
            <thead>
              <tr>
                <th>Email</th>
                <th>Name</th>
                <th>Branch</th>
                <th>Status</th>
                <th>User Permissions</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.email}>
                  <td>{user.email}</td>
                  <td>{user.name}</td>
                  <td>{user.branch}</td>
                  <td>
                    <span
                      className={`badge ${user.status === "Active"
                          ? "badge-success"
                          : "badge-danger"
                        }`}
                    >
                      {user.status}
                    </span>
                  </td>
                  <td>{user.user_permissions}</td>
                  <td className="last-td">
                    <button
                      className="btn permission-edit-btn"
                      onClick={() => handleEditUserClick(user)}
                    >
                      <MdEdit /> Edit
                    </button>
                    <MdDelete
                      size={25}
                      className="delete-user-btn"
                      onClick={() => handleDeleteUser(user.email)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Edit User Form */}
          {showEditUserForm && currentUser && (
            <div className="edit-user-form">
              <form onSubmit={handleEditUserSubmit}>
                <div className="form-group-container">
                  <label className="form-group-label">
                    Name <label style={{ color: "#db4a3a" }}>*</label>
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    value={currentUser.name}
                    onChange={(e) =>
                      setCurrentUser({ ...currentUser, name: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="form-group-container">
                  <label className="form-group-label">
                    Email <label style={{ color: "#db4a3a" }}>*</label>
                  </label>
                  <input
                    type="email"
                    className="form-control"
                    value={currentUser.email}
                    onChange={(e) =>
                      setCurrentUser({ ...currentUser, email: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="form-group-container">
                  <label className="form-group-label">
                    User Permissions{" "}
                    <label style={{ color: "#db4a3a" }}>*</label>
                  </label>
                  <select
                    className="form-control"
                    value={currentUser.user_permissions}
                    onChange={(e) =>
                      setCurrentUser({
                        ...currentUser,
                        user_permissions: e.target.value,
                      })
                    }
                    required
                  >
                    <option value="Operational">Operational</option>
                    <option value="Admin">Admin</option>
                  </select>
                </div>
                <div className="form-group-container">
                  <label className="form-group-label">
                    Status <label style={{ color: "#db4a3a" }}>*</label>
                  </label>
                  <div className="status-choices">
                    <div className="active-container">
                      <input
                        type="radio"
                        id="active"
                        name="status"
                        value="Active"
                        checked={currentUser.status === "Active"}
                        onChange={(e) =>
                          setCurrentUser({
                            ...currentUser,
                            status: e.target.value,
                          })
                        }
                      />
                      <label htmlFor="active">Active</label>
                    </div>
                    <div className="inactive-container">
                      <input
                        type="radio"
                        id="inactive"
                        name="status"
                        value="Inactive"
                        checked={currentUser.status === "Inactive"}
                        onChange={(e) =>
                          setCurrentUser({
                            ...currentUser,
                            status: e.target.value,
                          })
                        }
                      />
                      <label htmlFor="inactive">Inactive</label>
                    </div>
                  </div>
                </div>

                <div className="edit-user-btn-container">
                  <button
                    type="button"
                    className="edit-user-btn-one"
                    onClick={handleCloseEditUserForm}
                  >
                    Cancel
                  </button>
                  <button type="submit" className="edit-user-btn-two">
                    Save
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default Users;
