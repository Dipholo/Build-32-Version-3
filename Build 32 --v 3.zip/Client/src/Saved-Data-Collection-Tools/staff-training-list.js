import React, { useEffect, useState } from "react";
import "./lists.css";
import "../styling/common.css";
import axios from "axios";

export const StaffTrainingList = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [filterBy, setFilterBy] = useState("name");
  const [visibleParticipants, setVisibleParticipants] = useState({}); // State to track visibility of participants

  const handleTokenRefresh = async () => {
    try {
      const refreshToken = sessionStorage.getItem("refreshToken");
      const refreshResponse = await axios.post(
        "http://localhost:1024/users/token",
        {
          refreshToken,
        }
      );
      const newAccessToken = refreshResponse.data.accessToken;
      const newRefreshToken = refreshResponse.data.refreshToken;

      sessionStorage.setItem("accessToken", newAccessToken);
      sessionStorage.setItem("refreshToken", newRefreshToken);
    } catch (error) {
      console.error("Error during token refresh:", error);
      alert("Session expired. Please log in again.");
      sessionStorage.removeItem("accessToken");
      sessionStorage.removeItem("refreshToken");
      window.location.reload(); // or navigate to login page
    }
  };

  const fetchFacilitatorsWithParticipants = async () => {
    try {
      const response = await fetch(
        "http://localhost:1024/api/data-collection/get-staff-training",
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
        }
      );

      if (!response.ok) {
        if (response.status === 401) {
          await handleTokenRefresh();
          await fetchFacilitatorsWithParticipants(); // Retry fetching after refreshing token
        } else {
          throw new Error("Error fetching data");
        }
      } else {
        const data = await response.json();
        setData(data);
      }
    } catch (error) {
      console.error("Failed to fetch data:", error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    fetchFacilitatorsWithParticipants();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  // Filtering logic
  const filteredData = data.filter((facilitator) => {
    const matchesName = facilitator.facilitatorName
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesDate = facilitator.date.includes(search);
    const matchesMinistry = facilitator.organizingMinistry
      .toLowerCase()
      .includes(search.toLowerCase());
    return (
      (filterBy === "name" && matchesName) ||
      (filterBy === "date" && matchesDate) ||
      (filterBy === "ministry" && matchesMinistry)
    );
  });

  const handleViewParticipants = (facilitatorId) => {
    setVisibleParticipants((prev) => ({
      ...prev,
      [facilitatorId]: !prev[facilitatorId], // Toggle visibility
    }));
  };

  return (
    <div className="community-attendance-list">
      <h2>Implementing Stakeholders Training Records</h2>

      <div className="filter-controls">
        <input
          className="search-input"
          type="text"
          placeholder={`Search by ${filterBy}`}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <div className="spacer"></div>
        <select
          className="selection"
          value={filterBy}
          onChange={(e) => setFilterBy(e.target.value)}
        >
          <option value="name">Facilitator Name</option>
          <option value="date">Date</option>
          <option value="ministry">Organizing Ministry</option>
        </select>
      </div>

      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Facilitator Name</th>
            <th>Organizing Ministry</th>
            <th>Activity</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map((facilitator) => (
            <tr key={facilitator.id}>
              <td>{facilitator.id}</td>
              <td>{facilitator.facilitatorName}</td>
              <td>{facilitator.organizingMinistry}</td>

              <td>{facilitator.activity}</td>
              <td>{facilitator.date}</td>
              <td>
                <button
                  className="show-participants-btn"
                  onClick={() => handleViewParticipants(facilitator.id)}
                >
                  {visibleParticipants[facilitator.id]
                    ? "Hide Participants"
                    : "View Participants"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Render participant details if visible */}
      {Object.keys(visibleParticipants).map((facilitatorId) =>
        visibleParticipants[facilitatorId] ? (
          <div key={facilitatorId} className="participants-table-section">
            <h3>
              Participants for{" "}
              {
                filteredData.find((f) => f.id === parseInt(facilitatorId))
                  .activity
              }{" "}
              as at{" "}
              {filteredData.find((f) => f.id === parseInt(facilitatorId)).date}{" "}
              Coordinated by{" "}
              {
                filteredData.find((f) => f.id === parseInt(facilitatorId))
                  .facilitatorName
              }
            </h3>
            <table className="participants-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Surname</th>
                  <th>Gender</th>
                  <th>Agency</th>
                  <th>Role</th>
                  <th>Email</th>
                  <th>Contact No</th>
                  <th>Presence Day 1</th>
                  <th>Presence Day 2</th>
                  <th>Presence Day 3</th>
                  <th>Presence Day 4</th>
                  <th>Presence Day 5</th>
                </tr>
              </thead>
              <tbody>
                {filteredData
                  .find((f) => f.id === parseInt(facilitatorId))
                  .participants.map((participant) => (
                    <tr key={participant.id}>
                      <td>{participant.name}</td>
                      <td>{participant.surname}</td>
                      <td>{participant.gender}</td>
                      <td>{participant.agency || "N/A"}</td>
                      <td>{participant.role || "N/A"}</td>
                      <td>{participant.email || "N/A"}</td>
                      <td>{participant.contactNo || "N/A"}</td>
                      <td>{participant.presenceDay1}</td>
                      <td>{participant.presenceDay2}</td>
                      <td>{participant.presenceDay3}</td>
                      <td>{participant.presenceDay4}</td>
                      <td>{participant.presenceDay5}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        ) : null
      )}
    </div>
  );
};

export default StaffTrainingList;
