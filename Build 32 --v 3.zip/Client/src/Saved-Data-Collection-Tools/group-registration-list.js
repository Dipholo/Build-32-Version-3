import React, { useEffect, useState } from "react";
import "./lists.css";
import "../styling/common.css";
import axios from "axios";

export const GroupRegistrationList = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [filterBy, setFilterBy] = useState("groupName");
  const [visibleParticipants, setVisibleParticipants] = useState({});

  const handleTokenRefresh = async () => {
    try {
      const refreshToken = sessionStorage.getItem("refreshToken");
      const refreshResponse = await axios.post(
        "http://localhost:1024/users/token",
        {
          refreshToken,
        }
      );
      const newAccessToken = refreshResponse.data.accessToken;
      const newRefreshToken = refreshResponse.data.refreshToken;

      sessionStorage.setItem("accessToken", newAccessToken);
      sessionStorage.setItem("refreshToken", newRefreshToken);
    } catch (error) {
      console.error("Error during token refresh:", error);
      alert("Session expired. Please log in again.");
      sessionStorage.removeItem("accessToken");
      sessionStorage.removeItem("refreshToken");
      window.location.reload(); // or navigate to login page
    }
  };
  
    const fetchGroupsWithParticipants = async () => {
      try {
        const response = await fetch(
          "http://localhost:1024/api/data-collection/get-group-registration",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
            },
          }
        );
  
        if (!response.ok) {
          if (response.status === 401) {
            await handleTokenRefresh();
            await fetchGroupsWithParticipants(); // Retry fetching after refreshing token
          } else {
            throw new Error("Error fetching data");
          }
        } else {
          const data = await response.json();
          setData(data);
        }
      } catch (error) {
        console.error("Failed to fetch data:", error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

  useEffect(() => {
    fetchGroupsWithParticipants();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  // Filtering logic
  const filteredData = data.filter((group) => {
    const matchesGroupName = group.groupName
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesType = group.groupType
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesVillage = group.village
      .toLowerCase()
      .includes(search.toLowerCase());
    return (
      (filterBy === "groupName" && matchesGroupName) ||
      (filterBy === "type" && matchesType) ||
      (filterBy === "village" && matchesVillage)
    );
  });

  const handleViewParticipants = (groupId) => {
    setVisibleParticipants((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
  };

  return (
    <div className="community-attendance-list">
      <h2>Group Registration Records</h2>

      <div className="filter-controls">
        <input
          className="search-input"
          type="text"
          placeholder={`Search by ${filterBy}`}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <div className="spacer"></div>
        <select
          className="selection"
          value={filterBy}
          onChange={(e) => setFilterBy(e.target.value)}
        >
          <option value="groupName">Group Name</option>
          <option value="type">Group Type</option>
          <option value="village">Village</option>
        </select>
      </div>

      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Group Name</th>
            <th>Type</th>
            <th>Village</th>
            <th>Date of Establishment</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map((group) => (
            <tr key={group.id}>
              <td>{group.id}</td>
              <td>{group.groupName}</td>
              <td>{group.groupType}</td>
              <td>{group.village}</td>
              <td>{group.establishmentDate}</td>
              <td>
                <button
                  className="show-participants-btn"
                  onClick={() => handleViewParticipants(group.id)}
                >
                  {visibleParticipants[group.id]
                    ? "Hide Participants"
                    : "View Participants"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Render participant details if visible */}
      {Object.keys(visibleParticipants).map((groupId) =>
        visibleParticipants[groupId] ? (
          <div key={groupId} className="participants-table-section">
            <h3>
              Participants for{" "}
              {filteredData.find((g) => g.id === parseInt(groupId)).groupName}
            </h3>
            <table className="participants-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Surname</th>
                  <th>Gender</th>
                  <th>Village</th>
                  <th>Role</th>
                  <th>Contact No</th>
                </tr>
              </thead>
              <tbody>
                {filteredData
                  .find((g) => g.id === parseInt(groupId))
                  .participants.map((participant) => (
                    <tr key={participant.id}>
                      <td>{participant.name}</td>
                      <td>{participant.surname}</td>
                      <td>{participant.gender}</td>
                      <td>{participant.village}</td>
                      <td>{participant.role}</td>
                      <td>{participant.contact}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        ) : null
      )}
    </div>
  );
};

export default GroupRegistrationList;
