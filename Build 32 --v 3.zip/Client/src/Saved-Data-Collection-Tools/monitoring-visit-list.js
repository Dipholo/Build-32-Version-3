import React, { useEffect, useState } from "react";
import "./lists.css";
import "../styling/common.css";
import axios from "axios";


export const MonitoringVisitList = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [filterBy, setFilterBy] = useState("date");


  const handleTokenRefresh = async () => {
    try {
      const refreshToken = sessionStorage.getItem("refreshToken");
      const refreshResponse = await axios.post(
        "http://localhost:1024/users/token",
        {
          refreshToken,
        }
      );
      const newAccessToken = refreshResponse.data.accessToken;
      const newRefreshToken = refreshResponse.data.refreshToken;

      sessionStorage.setItem("accessToken", newAccessToken);
      sessionStorage.setItem("refreshToken", newRefreshToken);
    } catch (error) {
      console.error("Error during token refresh:", error);
      alert("Session expired. Please log in again.");
      sessionStorage.removeItem("accessToken");
      sessionStorage.removeItem("refreshToken");
      window.location.reload(); // or navigate to login page
    }
  };

  const fetchMonitoringVisits = async () => {
      try {
        const response = await fetch(
          "http://localhost:1024/api/data-collection/get-monitoring-visit",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
            },
          }
        );
  
        if (!response.ok) {
          if (response.status === 401) {
            await handleTokenRefresh();
            await fetchMonitoringVisits(); // Retry fetching after refreshing token
          } else {
            throw new Error("Error fetching data");
          }
        } else {
          const data = await response.json();
          setData(data);
        }
      } catch (error) {
        console.error("Failed to fetch data:", error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };


  useEffect(() => {
    fetchMonitoringVisits();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  const filteredData = data.filter((visit) => {
    const matchesDate = visit.date?.includes(search);
    const matchesLocation = visit.location
      ?.toLowerCase()
      .includes(search.toLowerCase());
    return (
      (filterBy === "date" && matchesDate) ||
      (filterBy === "location" && matchesLocation)
    );
  });

  return (
    <div className="community-attendance-list">
      <h2>Monitoring Visits</h2>

      <div className="filter-controls">
        <input
          className="search-input"
          type="text"
          placeholder={`Search by ${filterBy}`}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <div className="spacer"></div>
        <select
          className="selection"
          value={filterBy}
          onChange={(e) => setFilterBy(e.target.value)}
        >
          <option value="date">Date</option>
          <option value="location">Location</option>
        </select>
      </div>

      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Visit Conducted By</th>
            <th>Relevant Ministry/Agency</th>
            <th>District</th>
            <th>Location/Sites</th>
            <th>Date</th>
            <th>Objectives & Activities</th>
            <th>Field Challenges</th>
            <th>Mitigations</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map((visit) => (
            <tr key={visit.visitId}>
              <td>{visit.visitId}</td>
              <td>{visit.visitBy}</td>
              <td>{visit.ministry}</td>
              <td>{visit.district}</td>
              <td>{visit.location}</td>
              <td>{visit.date}</td>
              <td>
                {visit.objectives?.length ? (
                  visit.objectives.map((objective, objIndex) => (
                    <div key={objIndex} className="objective">
                      <strong>Objective {objIndex + 1}:</strong>{" "}
                      {objective.objective}
                      <div className="activities">
                        {objective.activities?.map((activity, actIndex) => (
                          <div key={actIndex} className="activity-item">
                            <p>
                              <strong>Activity {actIndex + 1}:</strong>{" "}
                              {activity.activity}
                            </p>
                            <p>
                              <strong>Requirement:</strong>{" "}
                              {activity.requirement}
                            </p>
                            <p>
                              <strong>Findings:</strong> {activity.findings}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                ) : (
                  <p>No objectives listed.</p>
                )}
              </td>
              <td>
                <div className="challenges">
                  {visit.challenges || <p>No challenges reported.</p>}
                </div>
              </td>
              <td>
                <div className="mitigations">
                  {visit.mitigations || <p>No mitigations reported.</p>}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MonitoringVisitList;
