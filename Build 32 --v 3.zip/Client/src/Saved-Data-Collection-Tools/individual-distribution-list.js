import React, { useEffect, useState } from "react";
import "./lists.css";
import "../styling/common.css";
import axios from "axios";

export const IndividualDistributionList = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [filterBy, setFilterBy] = useState("name");
  const [visibleParticipants, setVisibleParticipants] = useState({});
  
  const handleTokenRefresh = async () => {
    try {
      const refreshToken = sessionStorage.getItem("refreshToken");
      const refreshResponse = await axios.post(
        "http://localhost:1024/users/token",
        {
          refreshToken,
        }
      );
      const newAccessToken = refreshResponse.data.accessToken;
      const newRefreshToken = refreshResponse.data.refreshToken;

      sessionStorage.setItem("accessToken", newAccessToken);
      sessionStorage.setItem("refreshToken", newRefreshToken);
    } catch (error) {
      console.error("Error during token refresh:", error);
      alert("Session expired. Please log in again.");
      sessionStorage.removeItem("accessToken");
      sessionStorage.removeItem("refreshToken");
      window.location.reload(); // or navigate to login page
    }
  };

  const fetchData = async () => {
    try {
      const response = await fetch(
        "http://localhost:1024/api/data-collection/get-beneficiary-distribution",
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
        }
      );
      if (!response.ok) {
        if (response.status === 401) {
          await handleTokenRefresh();
          await fetchData(); // Retry fetching after refreshing token
        } else {
          throw new Error("Error fetching data");
        }
      } else {
        const data = await response.json();
        setData(data);
      }
    } catch (error) {
      console.error("Failed to fetch data:", error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    fetchData();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  // Filtering logic
  const filteredData = data.filter((facilitator) => {
    const matchesName = facilitator.facilitatorName
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesDate = facilitator.date.includes(search);
    const matchesMinistry = facilitator.organizingMinistry
      .toLowerCase()
      .includes(search.toLowerCase());
    return (
      (filterBy === "name" && matchesName) ||
      (filterBy === "date" && matchesDate) ||
      (filterBy === "ministry" && matchesMinistry)
    );
  });

  const handleViewParticipants = (facilitatorId) => {
    setVisibleParticipants((prev) => ({
      ...prev,
      [facilitatorId]: !prev[facilitatorId], // Toggle visibility
    }));
  };

  return (
    <div className="community-attendance-list">
      <h2>Beneficiary Distribution Records</h2>

      <div className="filter-controls">
        <input
          className="search-input"
          type="text"
          placeholder={`Search by ${filterBy}`}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <div className="spacer"></div>
        <select
          className="selection"
          value={filterBy}
          onChange={(e) => setFilterBy(e.target.value)}
        >
          <option value="name">Facilitator Name</option>
          <option value="date">Date</option>
          <option value="ministry">Organizing Ministry</option>
        </select>
      </div>

      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Facilitator Name</th>
            <th>Organizing Ministry</th>
            <th>Activity</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map((facilitator) => (
            <tr key={facilitator.id}>
              <td>{facilitator.id}</td>
              <td>{facilitator.facilitatorName}</td>
              <td>{facilitator.organizingMinistry}</td>

              <td>{facilitator.activity}</td>
              <td>{facilitator.date}</td>
              <td>
                <button
                  className="show-participants-btn"
                  onClick={() => handleViewParticipants(facilitator.id)}
                >
                  {visibleParticipants[facilitator.id]
                    ? "Hide Participants"
                    : "View Participants"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Render participant details if visible */}
      {Object.keys(visibleParticipants).map((facilitatorId) =>
        visibleParticipants[facilitatorId] ? (
          <div key={facilitatorId} className="participants-table-section">
            <h3>
              Participants for{" "}
              {
                filteredData.find((f) => f.id === parseInt(facilitatorId))
                  .activity
              }{" "}
              as at{" "}
              {filteredData.find((f) => f.id === parseInt(facilitatorId)).date}{" "}
              Coordinated by{" "}
              {
                filteredData.find((f) => f.id === parseInt(facilitatorId))
                  .facilitatorName
              }
            </h3>
            <table className="participants-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Surname</th>
                  <th>Gender</th>
                  <th>Age</th>
                  <th>Village</th>
                  <th>Items</th>
                  <th>Quantity</th>
                  <th>Contact No</th>
                </tr>
              </thead>
              <tbody>
                {filteredData
                  .find((f) => f.id === parseInt(facilitatorId))
                  .participants.map((participant) => (
                    <tr key={participant.id}>
                      <td>{participant.name}</td>
                      <td>{participant.surname}</td>
                      <td>{participant.gender}</td>
                      <td>{participant.age}</td>
                      <td>{participant.village}</td>
                      <td>{participant.items}</td>
                      <td>{participant.quantity}</td>
                      <td>{participant.contactNo || "N/A"}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        ) : null
      )}
    </div>
  );
};

export default IndividualDistributionList;
