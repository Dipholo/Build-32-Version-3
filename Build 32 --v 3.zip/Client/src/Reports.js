import React, { useState, useRef, useEffect } from "react";
import "./Tools.css";
import "./Documents.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import Footer from "./Footer";
import { RiAiGenerate } from "react-icons/ri";
import { TfiSave } from "react-icons/tfi";
import SavedReports from './SavedReports';
import GenerateReport from './GenerateReport';

const Reports = () => {
  const [selectedStat, setSelectedStat] = useState("fnco-templates");

  const handleCardClick = (statName) => {
    setSelectedStat(statName);
  };

  useEffect(() => {
    setSelectedStat("fnco-templates");
  }, []);

  return (
    <div className="tools">
      <Sidebar />
      <div className="main-content">
        <Topbar />

        <div className="dashboard-content">
          <div className="stats-cards">
            <div
              className={`stat-card ${
                selectedStat === "fnco-documents"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("fnco-documents")}
            >
              <div className="tools-stat-elements">
                <h6>National Food and Nutrition</h6>
                <div className="tools-stat-icon">
                  <RiAiGenerate size={40} color="#b15d15" />
                </div>
              </div>
              <p3>Report Generator</p3>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "fnco-templates"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("fnco-templates")}
            >
              <div className="tools-stat-elements">
                <h6>National Food and Nutrition</h6>
                <div className="tools-stat-iconOne">
                  <TfiSave size={35} color="#076180" />
                </div>
              </div>
              <p3>Saved Reports</p3>
            </div>
          </div>

          {/* Conditional Rendering of Components */}
          <div className="stat-content">
            {selectedStat === "fnco-templates" && <SavedReports />}
            {selectedStat === "fnco-documents" && <GenerateReport />}
          </div>
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default Reports;
