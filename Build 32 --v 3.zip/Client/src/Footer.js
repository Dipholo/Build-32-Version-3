import React, { useState, useEffect } from 'react';
import { FaRegCopyright } from 'react-icons/fa';
import './Topbar.css';

const Footer = () => (
  <div className='footer' style={{ textAlign: "center", padding: "20px" }}>
    <p>Copyright <FaRegCopyright /> {new Date().getFullYear()} - FNCO. All Rights Reserved.</p>
  </div>
);

export default Footer;
