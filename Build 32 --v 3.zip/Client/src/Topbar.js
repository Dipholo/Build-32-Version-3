import React, { useState, useEffect, useRef } from 'react';
import { CiBellOn } from 'react-icons/ci';
import { FaRegUserCircle } from 'react-icons/fa';
import { IoMdCloseCircleOutline, IoMdClose } from "react-icons/io";
import { AiOutlineSearch } from 'react-icons/ai';
import recentsIcon from './Images/recents.png';
import { TiMessages } from "react-icons/ti";
import { FiUser } from "react-icons/fi";
import { BiLogOutCircle } from "react-icons/bi";
import { LuAlertTriangle } from "react-icons/lu";
import NotificationsPopup from './Popups/Notifications';
import './Topbar.css';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';



const Topbar = () => {
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const [showProfileMenu, setShowProfileMenu] = useState(false);
    const [isNotifOpen, setIsNotifOpen] = useState(false);
    const profileMenuRef = useRef(null);
    const notificationRef = useRef(null);

    const toggleSearch = () => {
        setIsSearchOpen(!isSearchOpen);
    };

    const toggleNotifPopup = () => {
        setIsNotifOpen(!isNotifOpen);
    };

    const toggleProfileMenu = () => {
        setShowProfileMenu(!showProfileMenu);
    };


    // Close the pop-ups when clicking outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (profileMenuRef.current && !profileMenuRef.current.contains(event.target)) {
                setShowProfileMenu(false);
            }
            if (notificationRef.current && !notificationRef.current.contains(event.target)) {
                setIsNotifOpen(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const navigate = useNavigate();

    const handleLogout = () => {

        const refreshToken = sessionStorage.getItem('refreshToken');
        axios.post('http://localhost:1024/users/logout', { refreshToken })
            .then(() => {
                sessionStorage.removeItem('accessToken');
                sessionStorage.removeItem('refreshToken');
                navigate('/');
                alert('Logout successful!');
                
            })
            .catch((error) => {
                //we can log this error to find out what is causing errors empa we still logout anyway
                navigate('/');
            });
    };

    return (
        <div className='topbar'>
            {/* <button className="mobile-menu-btn">
            {isOpen && isSmallScreen ? <IoMdCloseCircleOutline size={24} /> : <CgDetailsMore size={24} />}
        </button> */}

            <div className={`header-search ${isSearchOpen ? 'open' : ''}`}>
                <div className="search-input-group">
                    {isSearchOpen && (
                        <span className="search-input-group-addon search-close" onClick={toggleSearch}>
                            <IoMdClose />
                        </span>
                    )}
                    {isSearchOpen ? (
                        <div className="search-wrapper">
                            <span className="search-input-icon">
                                <AiOutlineSearch size={20} />
                            </span>
                            <input type="text" className="search-form-control" placeholder=" " />
                        </div>
                    ) : (
                        <span className="search-input-group-addon search-btn" onClick={toggleSearch}>
                            <AiOutlineSearch />
                        </span>
                    )}
                </div>
            </div>


            <div className='topbar-icons'>
                {/* Notification Icon */}
                <div className="icon-wrapper" onClick={toggleNotifPopup} ref={notificationRef}>
                    <CiBellOn size={22} className="topbar-icon" />
                    <span className="notification-badge">3</span>

                    {/* Notification Pop-up */}
                    {isNotifOpen && (
                        <NotificationsPopup isOpen={isNotifOpen} onClose={() => setIsNotifOpen(false)} />
                    )}
                </div>

                <div className='icon-wrapper'>
                    <TiMessages size={22} className='topbar-icon' />
                    <span className='notification-badge green'>0</span>
                </div>

                <img src={recentsIcon} alt="" className='recents-icon' />

                <FaRegUserCircle size={24} className='profile-pic' onClick={toggleProfileMenu} />
                {showProfileMenu && (
                    <div ref={profileMenuRef} className="profile-menu">
                        <ul>
                            <li>
                                <FiUser size={20} className="profile-icon" /> <span className="profile-text">Profile</span>
                            </li>
                            <li>
                                <LuAlertTriangle size={20} className="profile-icon" /> <span className="profile-text">Alerts</span>
                            </li>
                            <li onClick={handleLogout}>
                                <BiLogOutCircle size={20} className="profile-icon" /> <span className="profile-text">Logout</span>
                            </li>
                        </ul>
                    </div>
                )}
            </div>
        </div>
    );
}

export default Topbar;


