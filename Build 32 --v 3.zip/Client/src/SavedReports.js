import React, { useState, useRef } from "react";
import "./Tools.css";
import "./Documents.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { AiOutlineSearch } from "react-icons/ai";
import { MdDelete } from "react-icons/md";
import { MdOutlinePreview } from "react-icons/md";
import { BsDownload } from "react-icons/bs";
import { FaRegShareFromSquare } from "react-icons/fa6";
import { TbEdit } from "react-icons/tb";

const SavedReports = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const fileInputRef = useRef(null);

   // Sample data for the table
   const [files, setFiles] = useState([
    { id: 1, name: "Monthly_Report_January.pdf" },
    { id: 2, name: "Nutrition_Statistics_2024.xlsx" },
    { id: 3, name: "Quarterly_Analysis_Q3.docx" },
  ]);

  // Function to handle file selection (checkbox)
  const handleFileSelect = (id) => {
    const updatedFiles = files.map((file) =>
      file.id === id ? { ...file, selected: !file.selected } : file
    );
    setFiles(updatedFiles);
  };

  return (
    <div className="templates">
      <div className="templates-header">
        <span className="toolsTitle" style={{ color: "#14773d" }}>
          Saved Reports
        </span>

        <div className="docs-search-input-group">
          <div className="search-wrapper">
            <span className="docs-search-input-icon">
              <AiOutlineSearch size={20} />
            </span>
            <input type="text" placeholder="Search Report" />
          </div>
          <input type="file" ref={fileInputRef} style={{ display: "none" }} />
        </div>

        <button className="add-document-btn">
          <TbEdit /> Edit Report
        </button>
      </div>

      <div className="templates-body">
         {/* Table displaying saved reports */}
         <table className="documents-table">
          <thead>
            <tr>
              <th></th>
              <th scope="col">File Name</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {files.map((file) => (
              <tr key={file.id}>
                <td>
                  <input
                    type="checkbox"
                    checked={file.selected || false}
                    onChange={() => handleFileSelect(file.id)}
                  />
                </td>
                <td>{file.name}</td>
                <td>
                  <button className="preview-report-btn">
                    <MdOutlinePreview size={18} /> Preview
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="templates-body-btns">
          <button className="add-document-btn" title="Download Selection">
            <BsDownload size={16} /> Download
          </button>

          <button className="delete-report-btn" title="Delete Selection">
            <MdDelete size={18} /> Delete
          </button>

          <button className="download-report-btn" title="Share Selection">
            <FaRegShareFromSquare size={16} /> Share
          </button>
        </div>
      </div>
    </div>
  );
};

export default SavedReports;
