import * as React from "react";
import { styled } from "@mui/system";
import {
  TablePagination,
  tablePaginationClasses as classes,
} from "@mui/base/TablePagination";
import { Card, CardBody, CardTitle, Table } from "reactstrap";

export default function TableUnstyled() {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  return (
    <div>
      <Card>
        <CardBody>
          <CardTitle tag="h5" style={{fontSize:'1.5rem',color:'#095328'}}>Participants Table</CardTitle>

          <Table
            aria-label="custom pagination table"
            className="no-wrap mt-3 align-middle"
            responsive
            borderless
          >
            <thead>
              <tr>
                <th>S/N</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Gender (M/F/O)</th>
                <th>DOB</th>
                <th>Age</th>
                <th>Village</th>
                <th>Role</th>
                <th>Contact No</th>
              </tr>
            </thead>
            <tbody>
              {(rowsPerPage > 0
                ? rows.slice(
                    page * rowsPerPage,
                    page * rowsPerPage + rowsPerPage
                  )
                : rows
              ).map((row) => (
                <tr className="border-top">
                  <td className="mb-3">{row.num}</td>
                  <td className="mb-3">{row.name}</td>
                  <td className="mb-3">{row.surname}</td>
                  <td className="mb-3">{row.gender}</td>
                  <td className="mb-3">{row.birth}</td>
                  <td className="mb-3">{row.age}</td>
                  <td className="mb-3">{row.village}</td>
                  <td className="mb-3">{row.role}</td>
                  <td className="mb-3">{row.contact}</td>
                </tr>
              ))}
              {emptyRows > 0 && (
                <tr style={{ height: 41 * emptyRows }}>
                  <td colSpan={3} aria-hidden />
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr>
                <CustomTablePagination
                  rowsPerPageOptions={[5, 10, 25, { label: "All", value: -1 }]}
                  colSpan={3}
                  count={rows.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  slotProps={{
                    select: {
                      "aria-label": "rows per page",
                    },
                    actions: {
                      showFirstButton: true,
                      showLastButton: true,
                    },
                  }}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                />
              </tr>
            </tfoot>
          </Table>
        </CardBody>
      </Card>
    </div>
  );
}

function createData(
  num,
  name,
  surname,
  gender,
  birth,
  age,
  village,
  role,
  contact
) {
  return { num, name, surname, gender, birth, age, village, role, contact };
}

const rows = [
  createData(
    4,
    "Mpho",
    "Mosala",
    "F",
    "24/09/2000",
    24,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    12,
    "Thato",
    "Maseko",
    "F",
    "25/03/1989",
    35,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    3,
    "Neo",
    "Tau",
    "M",
    "24/09/2000",
    26,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    1,
    "Tsebo",
    "Maapesa",
    "F",
    "24/09/2000",
    42,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    6,
    "Mosa",
    "Puo",
    "M",
    "24/09/2000",
    56,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    10,
    "Kutlo",
    "Mphasa",
    "M",
    "24/09/2000",
    21,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    2,
    "Thuto",
    "Maseko",
    "M",
    "24/09/2000",
    38,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    8,
    "Neo",
    "Mpo",
    "F",
    "24/09/2000",
    63,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    13,
    "Lineo",
    "Maapesa",
    "F",
    "24/09/2000",
    30,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    9,
    "Tau",
    "Poho",
    "M",
    "24/09/2000",
    47,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    5,
    "Ntsheuoa",
    "Lipholo",
    "F",
    "24/09/2000",
    23,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    7,
    "Thabo",
    "Seala",
    "M",
    "24/09/2000",
    52,
    "Maseru",
    "Chief",
    56009090
  ),
  createData(
    11,
    "Taelo",
    "Patsi",
    "M",
    "24/09/2000",
    "Maseru",
    "Chief",
    56009090
  ),
  60,
].sort((a, b) => (a.calories < b.calories ? -1 : 1));

const grey = {
  50: "#F3F6F9",
  100: "#E5EAF2",
  200: "#DAE2ED",
  300: "#C7D0DD",
  400: "#B0B8C4",
  500: "#9DA8B7",
  600: "#6B7A90",
  700: "#434D5B",
  800: "#303740",
  900: "#1C2025",
};

const Root = styled("div")(
  ({ theme }) => `
  table {
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.875rem;
    border-collapse: collapse;
    width: 100%;
  }

  td,
  th {
    border: 1px solid ${theme.palette.mode === "dark" ? grey[800] : grey[200]};
    padding: 8px;
    weight : 400;
  }

  th {
    background-color: ${theme.palette.mode === "dark" ? grey[900] : "#fff"};
  }
  `
);

const CustomTablePagination = styled(TablePagination)`
  & .${classes.toolbar} {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;

    @media (min-width: 768px) {
      flex-direction: row;
      align-items: center;
    }
  }

  & .${classes.selectLabel} {
    margin: 0;
  }

  & .${classes.displayedRows} {
    margin: 0;

    @media (min-width: 768px) {
      margin-left: auto;
    }
  }

  & .${classes.spacer} {
    display: none;
  }

  & .${classes.actions} {
    display: flex;
    gap: 0.25rem;
  }
`;
