import React, { useState, useEffect } from "react";
import { Line, Bar, Pie, Doughnut, Radar, PolarArea } from "react-chartjs-2";
import axios from "axios";
import "./VisualizationStyle.css";

// Chart.js Registration
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  Filler,
  RadialLinearScale,
  PolarAreaController,  // Updated to PolarAreaController
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  Filler,
  RadialLinearScale,
  PolarAreaController // Registered PolarAreaController
);

const IYCFVisualizationForm = () => {
  const [indicators, setIndicators] = useState([]);
  const [selectedIndicator, setSelectedIndicator] = useState("");
  const [filterBy, setFilterBy] = useState("");
  const [selectedYear, setSelectedYear] = useState("");
  const [selectedDistrict, setSelectedDistrict] = useState("");
  const [chartData, setChartData] = useState([]);
  const [years] = useState([2018, 2019, 2020, 2021, 2022, 2023, 2024]);
  const [districts] = useState([
    "Berea",
    "Maseru",
    "Mafeteng",
    "Mohale's Hoek",
    "Quthing",
    "Qacha's Nek",
    "Leribe",
    "Mokhotlong",
    "Thaba-Tseka",
    "Botha-Bothe",
  ]);

  const fetchIndicators = async () => {
    try {
      const response = await axios.get(
        "http://localhost:1024/api/data-visualization/indicator-by-kra/IYCF",
        {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
        }
      );
      // Remove duplicate indicator names
      const uniqueIndicators = Array.from(
        new Set(response.data.map((indicator) => indicator.Indicator_Name))
      ).map((indicatorName) => {
        return response.data.find(
          (indicator) => indicator.Indicator_Name === indicatorName
        );
      });
      setIndicators(uniqueIndicators);
    } catch (error) {
      console.error("Error fetching indicators:", error.message);
    }
  };

  const fetchChartData = async () => {
    if (!selectedIndicator || !filterBy) return;

    const queryParams = [];
    if (filterBy === "Year" && selectedYear)
      queryParams.push(`year=${selectedYear}`);
    if (filterBy === "District" && selectedDistrict)
      queryParams.push(`district=${selectedDistrict}`);
    if (selectedIndicator) queryParams.push(`indicator=${selectedIndicator}`);

    const queryString = queryParams.length ? `?${queryParams.join("&")}` : "";

    try {
      const response = await axios.get(
        `http://localhost:1024/api/data-visualization/indicator-by-kra-district-year/IYCF${queryString}`,
        {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
        }
      );

      setChartData(response.data);
    } catch (error) {
      console.error("Error fetching chart data:", error.message);
    }
  };

  const prepareChartData = () => {
    if (!chartData.length) return { labels: [], datasets: [] };

    const labels =
      filterBy === "Year"
        ? chartData.map((item) => item.District)
        : chartData.map((item) => item.Year);

    const dataValues = chartData.map((item) => item.Value);

    // Function to generate random colors
    const generateRandomColors = (numColors) => {
      const colors = [];
      for (let i = 0; i < numColors; i++) {
        const randomColor = `rgba(${Math.floor(
          Math.random() * 256
        )}, ${Math.floor(Math.random() * 256)}, ${Math.floor(
          Math.random() * 256
        )}, 0.6)`;
        colors.push(randomColor);
      }
      return colors;
    };

    return {
      labels,
      datasets: [
        {
          label: `${filterBy === "Year" ? "Districts" : "Years"} for ${
            filterBy === "Year" ? selectedYear : selectedDistrict
          }`,
          data: dataValues,
          backgroundColor: generateRandomColors(dataValues.length), // Assign different colors to each data point
          borderColor: "rgba(0, 0, 0, 0)",
          borderWidth: 1,
        },
      ],
    };
  };

  useEffect(() => {
    fetchIndicators();
  }, []);

  useEffect(() => {
    fetchChartData();
  }, [selectedIndicator, filterBy, selectedYear, selectedDistrict]);

  return (
    <div className="container">
      <h2>Indicator Visualization</h2>

      <form className="form">
        <label>Select Indicator:</label>
        <select onChange={(e) => setSelectedIndicator(e.target.value)}>
          <option value="">--Select--</option>
          {indicators.map((indicator, index) => (
            <option key={index} value={indicator.Indicator_Name}>
              {indicator.Indicator_Name}
            </option>
          ))}
        </select>

        <label>Filter By:</label>
        <select onChange={(e) => setFilterBy(e.target.value)}>
          <option value="">--Select--</option>
          <option value="Year">Year</option>
          <option value="District">District</option>
        </select>

        {filterBy === "Year" && (
          <>
            <label>Select Year:</label>
            <select
              onChange={(e) => setSelectedYear(e.target.value)}
              disabled={!filterBy}
            >
              <option value="">--Select--</option>
              {years
                .sort((a, b) => a - b) 
                .map((year) => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
            </select>
          </>
        )}

        {filterBy === "District" && (
          <>
            <label>Select District:</label>
            <select
              onChange={(e) => setSelectedDistrict(e.target.value)}
              disabled={!filterBy}
            >
              <option value="">--Select--</option>
              {districts.map((district) => (
                <option key={district} value={district}>
                  {district}
                </option>
              ))}
            </select>
          </>
        )}
      </form>

      {(selectedIndicator && filterBy && (selectedYear || selectedDistrict)) && (
        <div className="chart-container row">
          <div className="col-12 col-md-4 mb-4">
            <div className="chart-box">
              <Bar
                data={prepareChartData()}
                options={{ responsive: true, maintainAspectRatio: false, height: 400, }}
              />
            </div>
          </div>
          <div className="col-12 col-md-4 mb-4">
            <div className="chart-box">
              <Line
                data={prepareChartData()}
                options={{ responsive: true, maintainAspectRatio: false, height: 400, }}
              />
            </div>
          </div>
          <div className="col-12 col-md-4 mb-4">
            <div className="chart-box">
              <Pie
                data={prepareChartData()}
                options={{ responsive: true, maintainAspectRatio: false, height: 400, }}
              />
            </div>
          </div>
          <div className="col-12 col-md-4 mb-4">
            <div className="chart-box">
              <Doughnut
                data={prepareChartData()}
                options={{ responsive: true, maintainAspectRatio: false, height: 400, }}
              />
            </div>
          </div>
          <div className="col-12 col-md-4 mb-4">
            <div className="chart-box">
              <Radar
                data={prepareChartData()}
                options={{ responsive: true, maintainAspectRatio: false, height: 400, }}
              />
            </div>
          </div>
          {/* New Polar Area Chart */}
          <div className="col-12 col-md-4 mb-4">
            <div className="chart-box">
              <PolarArea
                data={prepareChartData()}
                options={{ responsive: true, maintainAspectRatio: false, height: 400,}}
              />
            </div>
          </div>
        </div>
      )}

      {!selectedIndicator || !filterBy || (!selectedYear && !selectedDistrict) ? (
        <p>Select an indicator and filter option to display chart data.</p>
      ) : null}
    </div>
  );
};

export default IYCFVisualizationForm;
