import React from "react";
import "./Facilitator.css";
import "bootstrap/dist/css/bootstrap.min.css";

const Facilitator = () => {
  // Left column labels
  const labels = [
    "Name of Facilitator(s)",
    "Organizing Ministry",
    "Supporting Agency(ies)",
    "Activity",
    "Sub-activity",
    "Target Group",
    "Date",
    "District",
    "Community Council",
    "Village",
    "Venue",
  ];

  // Dummy data for the right column inputs (replace this with form data)
  const values = [
    "John Doe",
    "Ministry of Health",
    "WHO",
    "Health Awareness Program",
    "Vaccination Drive",
    "Children under 5",
    "23rd October 2024",
    "Maseru",
    "Teyateyaneng Council",
    "Maseru Village",
    "Conference Hall A",
  ];

  return (
    <div className="container data-entry-form mt-5">
      <div className="card">
        <div className="card-body">
          <label className="form-label">Facilitator Table</label>
          <table className="table table-bordered">
            <tbody>
              {labels.map((label, index) => (
                <tr key={index}>
                  {/* Left column: labels */}
                  <td className="table-label">{label}</td>

                  {/* Right column: unique values */}
                  <td>
                    <input
                      type="text"
                      value={values[index]} // unique value for each label
                      className="form-control"
                      readOnly // Make it non-editable (optional, remove if needed)
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Facilitator;
