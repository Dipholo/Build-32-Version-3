import React, { useState, useEffect, useRef } from "react";
import "./Tools.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Sidebar from "./Sidebar";
import Footer from "./Footer";
import Topbar from "./Topbar";
import {
  Button,
  InputGroup,
  FormControl,
  Dropdown,
  DropdownButton,
  ListGroup,
  Form,
  FormCheck,
  Table,
} from "react-bootstrap";
import { AiOutlinePlus, AiOutlineMinus } from "react-icons/ai";
import { MdOutlineSaveAlt } from "react-icons/md";
import { RiAiGenerate } from "react-icons/ri";

import IYCFVisualizationForm from "./IndicatorVisualization/IYCFVisualizationForm";
import CapacityBuildingVisualizationForm from "./IndicatorVisualization/CapacityBuildingVisualizationForm";
import EnablingEnvironmentVisualizationForm from "./IndicatorVisualization/EnablingEnvironmentVisualizationForm";
import FoodValueChainVisualizationForm from "./IndicatorVisualization/FoodValueChainVisualizationForm";
import GenderEqualityAndFemaleEmpowermentVisualizationForm from "./IndicatorVisualization/GenderEqualityAndFemaleEmpowermentVisualizationForm";
import MaternalandChildHealthChainVisualizationForm from "./IndicatorVisualization/MaternalAndChildHealthVisualizationForm";
import MicroNutrientSupplementationVisualizationForm from "./IndicatorVisualization/MicroNutrientSupplementationVisualizationForm";
import NutritionInEmergenciesVisualizationForm from "./IndicatorVisualization/NutritionInEmergenciesVisualizationForm";
import SocialProtectionVisualizationForm from "./IndicatorVisualization/SocialProtectionVisualizationForm";
import StrentheningClinicalServicesVisualizationForm from "./IndicatorVisualization/StrentheningClinicalServicesVisualizationForm";
import WASHVisualizationForm from "./IndicatorVisualization/WASHVisualizationForm";

const cardLabels = {
  education: "Education and Training (MoET)",
  water: "Water and Environment (MoWE)",
  agric: "Agriculture, Food Security & Nutrition",
  health: "Health (MoH)",
  social: "Social Development (MoSD)",
};

const Technologies = [
  "Histogram",
  "Donut Chart",
  "Waterfall Chart",
  "Area Chart",
  "Choropleth Map",
];

const DataVisualizer = () => {
  const educationData = [
    { keyResultArea: "Food Value Chain", percentage: 12 },
    { keyResultArea: "Water, Sanitation, and Hygiene (WASH)", percentage: 29 },
    { keyResultArea: "Social Protection", percentage: 6 },
  ];

  const waterData = [
    { keyResultArea: "Water, Sanitation, and Hygiene (WASH)", percentage: 29 },
  ];

  const agricData = [{ keyResultArea: "Food Value Chain", percentage: 12 }];

  const socialData = [
    { keyResultArea: "Social Protection", percentage: 6 },
    { keyResultArea: "Gender Equality and Female Empowerment", percentage: 9 },
  ];

  const healthData = [
    { keyResultArea: "Infant and Young Child Feeding (IYCF)", percentage: 34 },
    { keyResultArea: "Micronutrient Supplementation", percentage: 21 },
    { keyResultArea: "Maternal and Child Health", percentage: 17 },
    { keyResultArea: "Nutrition in Emergencies", percentage: 1 },
    { keyResultArea: "Strengthening Clinical Services", percentage: 1.7 },
  ];

  const fncoData = [
    { keyResultArea: "Capacity Building", percentage: 34 },
    { keyResultArea: "Enabling Environment", percentage: 21 },
  ];

  const [selectedStat, setSelectedStat] = useState("fnco");
  const [selectedData, setSelectedData] = useState(fncoData);
  const [selectedKra, setSelectedKra] = useState("");
  const [selectedTech, setSelectedTech] = useState([]);
  const [selectedItem, setSelectedItem] = useState("Ministry");
  const [selectedKeyItem, setSelectedKeyItem] = useState("Key Item");
  const [selectedFormat, setSelectedFormat] = useState("Format");
  const [includeAnalysis, setIncludeAnalysis] = useState(false);
  const [selectedKeyResult, setSelectedKeyResult] = useState(0);
  const [showIndicatorForm, setShowIndicatorForm] = useState(false);

  const dataMap = {
    education: educationData,
    water: waterData,
    agric: agricData,
    social: socialData,
    health: healthData,
    fnco: fncoData,
  };

  const handleCardClick = (statName) => {
    setSelectedStat(statName);
    setSelectedData(statName === "customCard" ? [] : dataMap[statName]); // Set empty data for the custom card
    setSelectedKra(""); // Reset KRA when changing stat card
  };

  const handleSelectkya = (index) => {
    setSelectedKra(selectedData[index].keyResultArea); // Update selected KRA
    setShowIndicatorForm(true);
  };

  useEffect(() => {
    setSelectedData(fncoData);
    setSelectedKra(""); // No KRA selected by default on load
  }, []);

  // Set default data on initial load or refresh
  useEffect(() => {
    setSelectedData(fncoData);
  }, []);

  const keyItems = ["Ministry", "KRA", "Ministry and KRA"];
  const formats = ["PDF", "PNG", "JPEG", "DOC", "XLS"];

  const handleAddTech = (tech) => {
    if (tech && !selectedTech.includes(tech)) {
      setSelectedTech([...selectedTech, tech]);
    }
  };

  // Remove Tech from the selected list
  const handleRemoveTech = (tech) => {
    setSelectedTech(selectedTech.filter((item) => item !== tech));
  };

  const handleSelect = (eventKey) => {
    setSelectedItem(eventKey);
  };

  const handleKeyItemSelect = (item) => {
    setSelectedKeyItem(item);
  };

  const handleFormatSelect = (format) => {
    setSelectedFormat(format);
  };

  const handleIncludeAnalysisChange = (e) =>
    setIncludeAnalysis(e.target.checked);

  const handleSaveReport = () => {
    console.log("Saving report...");
  };

  const handleGenerateReport = () => {
    console.log("Generating report...");
  };

  return (
    <div className="tools">
      <Sidebar />

      <div className="main-content">
        {/* topbar */}
        <Topbar />

        <div className="dashboard-content">
          <div className="stats-cards">
            <div
              className={`stat-card ${
                selectedStat === "education"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("education")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Ministry of</h8>
                </div>
                <div>
                  <label
                    className="stat-nutritional-value"
                    style={{ color: "#802319" }}
                  >
                    12%
                  </label>
                </div>
              </div>
              <h9>Education and Training (MoET)</h9>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "water"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("water")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Ministry of</h8>
                </div>
                <div>
                  <label
                    className="stat-nutritional-value"
                    style={{ color: "#0e773a" }}
                  >
                    0.2%
                  </label>
                </div>
              </div>
              <h9>Water and Environment (MoWE)</h9>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "agric"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("agric")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Ministry of</h8>
                </div>
                <div>
                  <label
                    className="stat-nutritional-value"
                    style={{ color: "#b15d15" }}
                  >
                    6%
                  </label>
                </div>
              </div>
              <h9>Agriculture, Food Security & Nutrition</h9>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "social"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("social")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Ministry of</h8>
                </div>
                <div>
                  <label
                    className="stat-nutritional-value"
                    style={{ color: "#076180" }}
                  >
                    13%
                  </label>
                </div>
              </div>
              <h9>Social Development (MoSD)</h9>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "health"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("health")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Ministry of</h8>
                </div>
                <div>
                  <label
                    className="stat-nutritional-value"
                    style={{ color: "#29b664" }}
                  >
                    9.5%
                  </label>
                </div>
              </div>
              <h9>Health (MoH)</h9>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "fnco"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("fnco")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Food and</h8>
                </div>
                <div>
                  <label
                    className="stat-nutritional-value"
                    style={{ color: "#0796c5" }}
                  >
                    9.5%
                  </label>
                </div>
              </div>
              <h9>Nutrition Coordinating Office</h9>
            </div>
          </div>

          <div className="dashboard-visuals"  >
            <div className="visuals-content" >
              <div className="goal-elements" >
                <div className="sidebar-section">
                  <span className="v-goal-elements-title">
                    {selectedStat === "fnco" ? (
                      "Food and Nutrition Coordination Office (FNCO)"
                    ) : (
                      <>
                        <span style={{ color: "#000", marginRight: "7px" }}>
                          Ministry of
                        </span>{" "}
                        {cardLabels[selectedStat]}
                      </>
                    )}
                    <span className="tagged-kra">
                      {selectedKra && ` (${selectedKra})`}
                    </span>
                  </span>

                  {/* Render the appropriate visualization form based on selected KRA */}

                  {showIndicatorForm &&
                    selectedKra === "Infant and Young Child Feeding (IYCF)" && (
                      <IYCFVisualizationForm selectedKra={selectedKra} />
                    )}
                  {showIndicatorForm &&
                    selectedKra === "Micronutrient Supplementation" && (
                      <MicroNutrientSupplementationVisualizationForm
                        selectedKra={selectedKra}
                      />
                    )}
                  {showIndicatorForm &&
                    selectedKra === "Maternal and Child Health" && (
                      <MaternalandChildHealthChainVisualizationForm
                        selectedKra={selectedKra}
                      />
                    )}
                  {showIndicatorForm &&
                    selectedKra === "Nutrition in Emergencies" && (
                      <NutritionInEmergenciesVisualizationForm
                        selectedKra={selectedKra}
                      />
                    )}
                  {showIndicatorForm &&
                    selectedKra === "Strengthening Clinical Services" && (
                      <StrentheningClinicalServicesVisualizationForm
                        selectedKra={selectedKra}
                      />
                    )}
                  {showIndicatorForm && 
                    selectedKra === "Food Value Chain" && (
                    <FoodValueChainVisualizationForm
                      selectedKra={selectedKra}
                    />
                  )}
                  {showIndicatorForm &&
                    selectedKra === "Water, Sanitation, and Hygiene (WASH)" && (
                      <WASHVisualizationForm selectedKra={selectedKra} />
                    )}
                  {showIndicatorForm && selectedKra === "Social Protection" && (
                    <SocialProtectionVisualizationForm
                      selectedKra={selectedKra}
                    />
                  )}
                  {showIndicatorForm &&
                    selectedKra ===
                      "Capacity Building" && (
                      <CapacityBuildingVisualizationForm
                        selectedKra={selectedKra}
                      />
                    )}
                    {showIndicatorForm &&
                    selectedKra ===
                      "Enabling Environment" && (
                      <EnablingEnvironmentVisualizationForm
                        selectedKra={selectedKra}
                      />
                    )}
                    {showIndicatorForm &&
                    selectedKra ===
                      "Gender Equality and Female Empowerment" && (
                      <GenderEqualityAndFemaleEmpowermentVisualizationForm
                        selectedKra={selectedKra}
                      />
                    )}
                </div>
              </div>
            </div>

            <div className="visualizer-sidebar">
              <div className="sidebar-section">
                <span className="visualizer-kra-title">Key Result Areas</span>
                <Table className="custom-table">
                  <tbody>
                    {selectedData.map((row, index) => (
                      <tr key={index}>
                        <td>
                          <FormCheck
                            type="radio"
                            checked={selectedKra === row.keyResultArea}
                            onChange={() => handleSelectkya(index)}
                          />
                        </td>
                        <td>{row.keyResultArea}</td>
                        <td>{row.percentage}%</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </div>

              <div className="visualizer-visuals-sidebar">
                <div className="v-analyse-section">
                  <div className="analyse-section-items">
                    <span>
                      ANALYZE RESULTS FOR <strong>:</strong>
                    </span>

                    <div className="dropdown-container">
                      <Dropdown onSelect={handleSelect}>
                        <Dropdown.Toggle variant="light" id="dropdown-basic">
                          {selectedItem}
                        </Dropdown.Toggle>

                        <Dropdown.Menu className="analyze-dropdown-menu">
                          <Dropdown.Item eventKey="Ministry">
                            Ministry
                          </Dropdown.Item>
                          <Dropdown.Item eventKey="KRA">KRA</Dropdown.Item>
                          <Dropdown.Item eventKey="Ministry and KRA">
                            Ministry and KRA
                          </Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                    </div>
                  </div>

                  <button className="analyzeBtn">Analyze</button>
                </div>

                <div className="sidebar-section">
                  <span>GENERATE REPORT</span>

                  <div className="report-options">
                    <Dropdown>
                      <Dropdown.Toggle variant="light" id="dropdown-key-item">
                        {selectedKeyItem}
                      </Dropdown.Toggle>

                      <Dropdown.Menu>
                        {keyItems.map((item, index) => (
                          <Dropdown.Item
                            key={index}
                            onClick={() => handleKeyItemSelect(item)}
                          >
                            {item}
                          </Dropdown.Item>
                        ))}
                      </Dropdown.Menu>
                    </Dropdown>

                    <Dropdown>
                      <Dropdown.Toggle variant="light" id="dropdown-format">
                        {selectedFormat}
                      </Dropdown.Toggle>

                      <Dropdown.Menu>
                        {formats.map((format, index) => (
                          <Dropdown.Item
                            key={index}
                            onClick={() => handleFormatSelect(format)}
                          >
                            {format}
                          </Dropdown.Item>
                        ))}
                      </Dropdown.Menu>
                    </Dropdown>
                  </div>

                  <div className="report-options">
                    <FormCheck
                      type="checkbox"
                      id="include-analysis"
                      label="Include Analysis"
                      checked={includeAnalysis}
                      onChange={handleIncludeAnalysisChange}
                    />
                  </div>

                  <div className="generate-options">
                    <Button
                      variant="outline-secondary"
                      onClick={handleSaveReport}
                    >
                      <MdOutlineSaveAlt /> Save
                    </Button>

                    <Button
                      variant="primary"
                      onClick={handleGenerateReport}
                      className="ml-2"
                    >
                      <RiAiGenerate /> Generate
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default DataVisualizer;
