import React, { useState, useRef } from "react";
import "./Tools.css";
import "./Documents.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { AiOutlineSearch } from "react-icons/ai";
import { MdDelete } from "react-icons/md";
import { MdOutlinePreview } from "react-icons/md";
import { BsDownload } from "react-icons/bs";
import { FaRegShareFromSquare } from "react-icons/fa6";
import { MdOutlineAdd } from "react-icons/md";

const FNCOTemplates = () => {
  const [files, setFiles] = useState([]); // State to store uploaded files
  const fileInputRef = useRef(null); // Ref for the file input

  const handleAddFile = (event) => {
    const newFile = event.target.files[0];
    if (newFile) {
      setFiles((prevFiles) => [...prevFiles, newFile]);
    }
  };

  const handleDeleteFile = (fileName) => {
    setFiles((prevFiles) => prevFiles.filter((file) => file.name !== fileName));
  };

  return (
    <div className="templates">
      <div className="templates-header">
        <span className="toolsTitle" style={{ color: "#14773d" }}>
          Templates
        </span>

        <div className="docs-search-input-group">
          <div className="search-wrapper">
            <span className="docs-search-input-icon">
              <AiOutlineSearch size={20} />
            </span>
            <input type="text" placeholder="Search files" />
          </div>
          <input
            type="file"
            ref={fileInputRef}
            style={{ display: "none" }}
            onChange={handleAddFile}
          />
        </div>

        <button
          className="add-document-btn"
          onClick={() => fileInputRef.current.click()} // Trigger file input
        >
          <MdOutlineAdd /> Add File
        </button>
      </div>

      <div className="templates-body">
        <table className="documents-table">
          <thead>
            <tr>
              <th>Food and Nutrition Template Files</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {files.map((file, index) => (
              <tr key={index}>
                <td>{file.name}</td>
                <td>
                  <MdDelete
                    size={20}
                    color="#b93527"
                    className="file-control-btn"
                    onClick={() => handleDeleteFile(file.name)}
                    title="Delete File"
                  />
                  <FaRegShareFromSquare
                    size={18}
                    color="#14773d"
                    className="file-control-btn"
                    title="Share File"
                  />
                  <BsDownload
                    size={18}
                    color="#b15d15"
                    className="file-control-btn"
                    title="Download File"
                  />
                  <MdOutlinePreview
                    size={20}
                    color="#516b8f"
                    className="file-control-btn"
                    title="Preview File"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default FNCOTemplates;
