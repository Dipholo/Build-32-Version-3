import React, { useState, useEffect, useRef } from "react";
import "./Tools.css";
import "bootstrap/dist/css/bootstrap.min.css";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import {
  Button,
  InputGroup,
  FormControl,
  Dropdown,
  DropdownButton,
  ListGroup,
  Form,
  FormCheck,
  Table,
} from "react-bootstrap";
import { GiArchiveRegister } from "react-icons/gi";
import { TbLayoutDistributeVertical } from "react-icons/tb";
import { MdModelTraining } from "react-icons/md";
import { CiExport } from "react-icons/ci";
import { MdOutlineSaveAlt } from "react-icons/md";
import visit from "./Images/placeholder.png";
import Sidebar from "./Sidebar";
import Footer from "./Footer";
import Topbar from "./Topbar";
import { IoMdDoneAll } from "react-icons/io";
import TableUnstyled from "./TableUnstyled";
import Facilitator from "./Facilitator";
import { IoCloseSharp } from "react-icons/io5";
import { MdOutlineFileUpload } from "react-icons/md";
import { CiCalendarDate } from "react-icons/ci";
import { MdClose } from "react-icons/md";
import AttendanceRegisterCommunity from "./Tools/community-attendance-registration-tool";
import AttendanceRegisterStaff from "./Tools/programme-staff-attendance-registration-tool";
import DistributionToolIndividuals from "./Tools/beneficiary-distribution-tool";
import DistributionToolInstitutions from "./Tools/institution-based-distribution-tool";
import TrainingRegisterCommunity from "./Tools/community-training-register";
import TrainingRegisterStaff from "./Tools/implementing-stakeholders-training-register";
import GroupRegistrationTool from "./Tools/group-registration-tool";
import MonitoringVisitTool from "./Tools/monitoring-visit-tool";

import CommunityAttendanceList from "./Saved-Data-Collection-Tools/community-attendance-list.js";
import StaffAttendaceList from "./Saved-Data-Collection-Tools/staff-attendance-list.js";
import CommunityTrainingList from "./Saved-Data-Collection-Tools/community-training-list.js";
import StaffTrainingList from "./Saved-Data-Collection-Tools/staff-training-list.js";
import IndividualDistributionList from "./Saved-Data-Collection-Tools/individual-distribution-list.js";
import InstitutionalDistributionList from "./Saved-Data-Collection-Tools/institutional-distribution-list.js";
import GroupRegistrationList from "./Saved-Data-Collection-Tools/group-registration-list.js";
import MonitoringVisitList from "./Saved-Data-Collection-Tools/monitoring-visit-list.js";

const Tools = () => {
  const [selectedStat, setSelectedStat] = useState("community-attendance");
  const [showTableFilterPopup, setShowTableFilterPopup] = useState(false);
  const fileInputRef = useRef(null);
  const [selectedFile, setSelectedFile] = useState([]);
  const [showTablePopup, setShowTablePopup] = useState(false);
  const [startDate, setStartDate] = useState(null);

  const [selectedFileDropdown, setSelectedFileDropdown] = useState("");

  // Handle "Open Recent" file selection
  const handleSelectFile = (file) => {
    if (!selectedFile.includes(file)) {
      setSelectedFile([...selectedFile, file]);
    }
  };

  // Display 'Submitted' file's table
  const toggleTablePopup = () => {
    setShowTablePopup(!showTablePopup);
  };

  useEffect(() => {
    setSelectedStat("community-attendance");
  }, []);

  const handleCardClick = (statName) => {
    setSelectedStat(statName);
  };

  // Function to render component based on selected card
  const renderSelectedComponent = () => {
    switch (selectedStat) {
      case "community-attendance":
        return <AttendanceRegisterCommunity className="tool-table" />;
      case "staff-attendance":
        return <AttendanceRegisterStaff className="tool-table" />;
      case "Beneficiary":
        return <DistributionToolIndividuals className="tool-table" />;
      case "Institution-based":
        return <DistributionToolInstitutions className="tool-table" />;
      case "Community-Training":
        return <TrainingRegisterCommunity className="tool-table" />;
      case "Stakeholders-Training":
        return <TrainingRegisterStaff className="tool-table" />;
      case "Group-Registration":
        return <GroupRegistrationTool className="tool-table" />;
      case "Monitoring-Visit":
        return <MonitoringVisitTool className="tool-table" />;
      default:
        return <AttendanceRegisterCommunity className="tool-table" />;
    }
  };

  // Function to render dropdown components
  const renderDropdownComponent = () => {
    switch (selectedFileDropdown) {
      case "community-attendance":
        return <CommunityAttendanceList />;
      case "staff-attendance":
        return <StaffAttendaceList />;
      case "community-training":
        return <CommunityTrainingList />;
      case "staff-training":
        return <StaffTrainingList />;
      case "individual-distribution":
        return <IndividualDistributionList />;
      case "institutional-distribution":
        return <InstitutionalDistributionList />;
      case "group-registration":
        return <GroupRegistrationList />;
      case "monitoring-visit":
        return <MonitoringVisitList />;
      default:
        return null;
    }
  };

  // Function to trigger the file input click
  const handleIconClick = () => {
    fileInputRef.current.click();
  };

  // Function to handle file selection
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  // Function to handle file cancellation (reset)
  const handleCancelFile = () => {
    setSelectedFile(null);
    fileInputRef.current.value = null;
  };

  // Function to handle file submission
  const handleSubmit = () => {
    if (selectedFile) {
      console.log("Submitting file:", selectedFile);
    }
  };

  // Function to handle clearing the selected date
  const handleClearDate = () => {
    setStartDate(null);
  };

  const toggleTableFilterPopup = () => {
    setShowTableFilterPopup(!showTableFilterPopup);
  };

  return (
    <div className="tools">
      <Sidebar />

      <div className="main-content">
        {/* topbar */}
        <Topbar />

        <div className="dashboard-content">
          <div className="toolsTitle-container">
            <span className="toolsTitle">
              Data Collection <span style={{ color: "#168645" }}>Tools</span>
            </span>
          </div>

          <div className="stats-cards">
            <div
              className={`stat-card ${
                selectedStat === "community-attendance"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("community-attendance")}
            >
              <div className="tools-stat-elements">
                <h6>Community Attendance</h6>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#e74c3c" }}
                >
                  <GiArchiveRegister size={28} />
                </div>
              </div>
              <p2>Registration Tool</p2>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "staff-attendance"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("staff-attendance")}
            >
              <div className="tools-stat-elements">
                <h6>Staff Attendance</h6>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#29b664" }}
                >
                  <GiArchiveRegister size={28} />
                </div>
              </div>
              <p2>Registration Tool</p2>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "Beneficiary"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("Beneficiary")}
            >
              <div className="tools-stat-elements">
                <h6>Beneficiary</h6>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#e67e22" }}
                >
                  <TbLayoutDistributeVertical size={28} />
                </div>
              </div>
              <p2>Distribution Tool</p2>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "Institution-based"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("Institution-based")}
            >
              <div className="tools-stat-elements">
                <h6>Institution - based</h6>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#019ed3" }}
                >
                  <TbLayoutDistributeVertical size={28} />
                </div>
              </div>
              <p2>Distribution Tool</p2>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "Community-Training"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("Community-Training")}
            >
              <div className="tools-stat-elements">
                <h6>Community</h6>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#802319" }}
                >
                  <MdModelTraining size={28} />
                </div>
              </div>
              <p2>Training Register</p2>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "Stakeholders-Training"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("Stakeholders-Training")}
            >
              <div className="tools-stat-elements">
                <h6>Implementing Stakeholders</h6>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#0e773a" }}
                >
                  <MdModelTraining size={28} />
                </div>
              </div>
              <p2>Training Register</p2>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "Group-Registration"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("Group-Registration")}
            >
              <div className="tools-stat-elements">
                <h6>Group</h6>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#b15d15" }}
                >
                  <GiArchiveRegister size={28} />
                </div>
              </div>
              <p2>Registration Tool</p2>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "Monitoring-Visit"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("Monitoring-Visit")}
            >
              <div className="tools-stat-elements">
                <h6>Monitoring</h6>
                <div
                  className="tools-stat-iconOne"
                  style={{ backgroundColor: "#076180" }}
                >
                  <img src={visit} alt="" style={{ width: "28px" }} />
                </div>
              </div>
              <p2>Visit Tool</p2>
            </div>
          </div>

          <div className="tools-details">
            <div className="upload-section">
              <div className="uploadFile">
                <label className="upload-label">Upload from Device</label>
                <MdOutlineFileUpload
                  size={25}
                  className="uploadfile-btn"
                  onClick={handleIconClick}
                />

                {/* Hidden file input */}
                <input
                  type="file"
                  ref={fileInputRef}
                  style={{ display: "none" }}
                  onChange={handleFileChange}
                />
              </div>

              {/* Display selected file */}
              {selectedFile && (
                <div className="file-container mt-3">
                  <p className="upload-label">
                    Selected File:{" "}
                    <span className="fileName">{selectedFile.name}</span>
                  </p>

                  <div className="file-actions">
                    <button className="submitFile-btn" onClick={handleSubmit}>
                      Submit
                    </button>
                    <button
                      className="cancelFile-btn"
                      onClick={handleCancelFile}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="tool-elements">
              {renderSelectedComponent()}

              {/* Dropdown to Open Recent Files */}
              <DropdownButton
                id="dropdown-basic-button"
                title="Open Recent"
                variant="outline-secondary"
                onSelect={(selectedKey) => setSelectedFileDropdown(selectedKey)}
              >
                <Dropdown.Item eventKey="community-attendance">
                  Community Attendance Registration
                </Dropdown.Item>
                <Dropdown.Item eventKey="staff-attendance">
                  Staff Attendance Registration
                </Dropdown.Item>
                <Dropdown.Item eventKey="community-training">
                  Community Training Registration
                </Dropdown.Item>
                <Dropdown.Item eventKey="staff-training">
                  Staff Training Registration
                </Dropdown.Item>
                <Dropdown.Item eventKey="individual-distribution">
                  Individual Distribution Tool
                </Dropdown.Item>
                <Dropdown.Item eventKey="institutional-distribution">
                  Institutional Distribution Tool
                </Dropdown.Item>
                <Dropdown.Item eventKey="group-registration">
                  Group Registration Tool
                </Dropdown.Item>
                <Dropdown.Item eventKey="monitoring-visit">
                  Monitoring Visit Tool
                </Dropdown.Item>
              </DropdownButton>

              {/* Render component based on dropdown selection */}
              {renderDropdownComponent()}
            </div>
          </div>
        </div>
        <Footer />
      </div>
    </div>
  );
};

export default Tools;
