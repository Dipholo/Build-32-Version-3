import React, { useState, useEffect, useRef } from "react";
import "./Tools.css";
import "bootstrap/dist/css/bootstrap.min.css";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Dropdown, DropdownButton } from "react-bootstrap";
import { CiExport } from "react-icons/ci";
import { MdOutlineSaveAlt } from "react-icons/md";
import Sidebar from "./Sidebar";
import Footer from "./Footer";
import Topbar from "./Topbar";
import { LiaChalkboardTeacherSolid } from "react-icons/lia";
import { FaHandHoldingWater } from "react-icons/fa";
import { FaSunPlantWilt } from "react-icons/fa6";
import { MdHealthAndSafety } from "react-icons/md";
import { PiHandshakeFill } from "react-icons/pi";
import TableUnstyled from "./TableUnstyled";
import Facilitator from "./Facilitator";
import { IoCloseSharp } from "react-icons/io5";
import { MdOutlineFileUpload } from "react-icons/md";
import GenderEqualityDataEntryForm from "./DataEntryForms/GenderEqualityDataEntryForm";
import IYCFDataEntryForm from "./DataEntryForms/IYCF";
import MaternalChildHealthForm from "./DataEntryForms/MaternalChildHealthForm";
import MicronutrientDataEntryForm from "./DataEntryForms/MicronutrientDataEntryForm";
import SocialProtectionDataEntryForm from "./DataEntryForms/SocialProtectionDataEntryForm";
import WASHDataEntryForm from "./DataEntryForms/WASHDataEntryForm";
import NutritioninEmergenciesDataEntryForm from "./DataEntryForms/NutritionInEmergencies";
import FoodValueChainDataEntryForm from "./DataEntryForms/FoodValueChain";
import ClinicalServicesDataEntryForm from "./DataEntryForms/StrengtheningClinicalServices";
import FNCOicon from "./Images/nutrition.png";
import CapacityBuildingDataEntryForm from './DataEntryForms/CapacityBuildingDataEntryForm';
import EnablingEnronmentDataEntryForm from './DataEntryForms/EnablingEnvironment';
import ImpactLevelIndicators from './DataEntryForms/ImpactLevelIndicators';

const DataEntry = () => {
  const [selectedStat, setSelectedStat] = useState("fnco-dataEntry");
  const [showTableFilterPopup, setShowTableFilterPopup] = useState(false);
  const [showTablePopup, setShowTablePopup] = useState(false);
  const fileInputRef = useRef(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [startDate, setStartDate] = useState(null);
  const [selectedOption, setSelectedOption] = useState("");

  // Map cards to their respective select options
  const selectOptionsByCard = {
    "community-attendance": ["Key Result Area"],
    "staff-attendance": ["Water, Sanitation, and Hygiene (WASH)"],
    Beneficiary: ["Food Value Chain"],
    "Institution-based": [
      "Infant and Young Child Feeding (IYCF)",
      "Micronutrient Supplementation",
      "Maternal and Child Health",
      "Nutrition in Emergencies",
      "Strengthening Clinical Services",
      "Impact Level Indicators",
    ],
    "Community-Training": [
      "Social Protection",
      "Gender Equality and Female Empowerment",
    ],
    "fnco-dataEntry": ["Capacity Building", "Enabling Environment"]
  };

  // Map options to their corresponding components
  const optionComponents = {
    "Food Value Chain": <FoodValueChainDataEntryForm />,
    "Water, Sanitation, and Hygiene (WASH)": <WASHDataEntryForm />,
    "Infant and Young Child Feeding (IYCF)": <IYCFDataEntryForm />,
    "Micronutrient Supplementation": <MicronutrientDataEntryForm />,
    "Maternal and Child Health": <MaternalChildHealthForm />,
    "Nutrition in Emergencies": <NutritioninEmergenciesDataEntryForm />,
    "Strengthening Clinical Services": <ClinicalServicesDataEntryForm />,
    "Impact Level Indicators": <ImpactLevelIndicators />,
    "Social Protection": <SocialProtectionDataEntryForm />,
    "Gender Equality and Female Empowerment": <GenderEqualityDataEntryForm />,
    "Capacity Building": <CapacityBuildingDataEntryForm />,
    "Enabling Environment": <EnablingEnronmentDataEntryForm/>
  };

  // Handle card click
  const handleCardClick = (statName) => {
    setSelectedStat(statName);
    // Automatically set the first option for the selected card
    const firstOption = selectOptionsByCard[statName]?.[0] || "";
    setSelectedOption(firstOption);
  };

  // Handle select option change
  const handleSelectChange = (event) => {
    setSelectedOption(event.target.value);
  };

  // Recently submitted and saved files
  const submittedFiles = ["Community Attendance Registration"];

  const savedFiles = ["Staff Attendance Registration"];

  // Function to trigger the file input click
  const handleIconClick = () => {
    fileInputRef.current.click();
  };

  // Function to handle file selection
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  // Function to handle file cancellation (reset)
  const handleCancelFile = () => {
    setSelectedFile(null);
    fileInputRef.current.value = null;
  };

  // Function to handle file submission
  const handleSubmit = () => {
    if (selectedFile) {
      console.log("Submitting file:", selectedFile);
      // Logic for file submission
    }
  };

  const toggleTableFilterPopup = () => {
    setShowTableFilterPopup(!showTableFilterPopup);
  };

  const toggleTablePopup = () => {
    setShowTablePopup(!showTablePopup);
  };

  return (
    <div className="tools">
      <Sidebar />

      <div className="main-content">
        {/* topbar */}
        <Topbar />

        <div className="dashboard-content">
          <div className="stats-cards">
            <div
              className={`stat-card ${
                selectedStat === "community-attendance"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("community-attendance")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Ministry of</h8>
                </div>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#802319" }}
                >
                  <LiaChalkboardTeacherSolid size={28} />
                </div>
              </div>
              <h9>Education and Training (MoET)</h9>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "staff-attendance"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("staff-attendance")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Ministry of</h8>
                </div>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#0e773a" }}
                >
                  <FaHandHoldingWater size={28} />
                </div>
              </div>
              <h9>Water and Environment (MoWE)</h9>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "Beneficiary"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("Beneficiary")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Ministry of</h8>
                </div>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#b15d15" }}
                >
                  <FaSunPlantWilt size={28} />
                </div>
              </div>
              <h9>Agriculture, Food Security & Nutrition</h9>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "Institution-based"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("Institution-based")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Ministry of</h8>
                </div>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#076180" }}
                >
                  <MdHealthAndSafety size={28} />
                </div>
              </div>
              <h9>Health (MoH)</h9>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "Community-Training"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("Community-Training")}
            >
              <div className="tools-stat-elements">
                <div className="startTitle-container">
                  <h8>Ministry of</h8>
                </div>
                <div
                  className="tools-stat-icon"
                  style={{ backgroundColor: "#019ed3" }}
                >
                  <PiHandshakeFill size={28} />
                </div>
              </div>
              <h9>Social Development (MoSD)</h9>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "fnco-dataEntry"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("fnco-dataEntry")}
            >
              <div className="tools-stat-fncoIcon">
                <img src={FNCOicon} alt="" style={{ width: "60px" }} />
              </div>
              <h10>Food and Nutrition Coordinating office</h10>
            </div>
          </div>

          <div className="tools-details">
            <div className="upload-section">
              <div className="uploadFile">
                <label className="upload-label">Upload from Device</label>
                <MdOutlineFileUpload
                  size={25}
                  className="uploadfile-btn"
                  onClick={handleIconClick}
                />

                {/* Hidden file input */}
                <input
                  type="file"
                  ref={fileInputRef}
                  style={{ display: "none" }}
                  onChange={handleFileChange}
                />
              </div>

              {/* Display selected file */}
              {selectedFile && (
                <div className="file-container mt-3">
                  <p className="upload-label">
                    Selected File:{" "}
                    <span className="fileName">{selectedFile.name}</span>
                  </p>

                  <div className="file-actions">
                    <button className="submitFile-btn" onClick={handleSubmit}>
                      Submit
                    </button>
                    <button
                      className="cancelFile-btn"
                      onClick={handleCancelFile}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              {/* Render select dropdown based on selected card */}
              {selectedStat && (
                <div className="upload-section">
                  <select
                    className="dataEntry-kra"
                    onChange={handleSelectChange}
                    value={selectedOption}
                  >
                    {selectOptionsByCard[selectedStat]?.map((option, index) => (
                      <option key={index} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            <div className="tool-elements">
              {optionComponents[selectedOption]}
            </div>

            {/* Popup for selected files */}
            {showTablePopup && (
              <div className="tablepopup">
                <div className="close-icon-container">
                  <IoCloseSharp
                    size={30}
                    className="close-tablepopup"
                    onClick={toggleTablePopup} // Close the popup
                  />
                  <span className="tooltip-text">Close File</span>
                </div>

                <div className="tables-container">
                  <div className="facilitator-container">
                    <Facilitator />
                  </div>
                  <TableUnstyled />
                </div>
              </div>
            )}
          </div>

          <Footer />
        </div>
      </div>
    </div>
  );
};

export default DataEntry;
