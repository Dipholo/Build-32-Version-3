import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './Login';
import Dashboard from './Dashboard';
import Tools from './Tools';
import DataEntry from './DataEntry';
import DataVisualizer from './DataVisualizer';
import Users from './Users';
import Reports from './Reports';
import Documents from './Documents';
import ProblemManagement from './ProblemManagement';
import Otp from './Otp';

function App() {

  const handleGetEmail = (email) => {
    console.log('Email received:', email);
  };
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login getEmailCallback={handleGetEmail} />} />
        <Route path="/otp" element={<Otp />} />
        <Route path="/dashboard" index element={<Dashboard />} />
        <Route path="/tools" element={<Tools />} />
        <Route path="/dataentry" element={<DataEntry />} />
        <Route path="/datavisualizer" element={<DataVisualizer />} />
        <Route path="/users" element={<Users />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/documents" element={<Documents />} />
        <Route path="/problems" element={<ProblemManagement />} />
      </Routes>
    </Router>
   
  );
}

export default App;
