import React, { useState, useRef, useEffect } from "react";
import "./Tools.css";
import "./Documents.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import Footer from "./Footer";
import { IoDocumentTextSharp } from "react-icons/io5";
import { TbTemplate } from "react-icons/tb";
import FNCOTemplates from './FNCOTemplates';
import FNCODocuments from './FNCODocuments';

const Documents = () => {
  const [selectedStat, setSelectedStat] = useState("fnco-templates");

  const handleCardClick = (statName) => {
    setSelectedStat(statName);
  };

  useEffect(() => {
    setSelectedStat("fnco-templates");
  }, []);

  return (
    <div className="tools">
      <Sidebar />
      <div className="main-content">
        <Topbar />

        <div className="dashboard-content">
          <div className="stats-cards">
            <div
              className={`stat-card ${
                selectedStat === "fnco-documents"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("fnco-documents")}
            >
              <div className="tools-stat-elements">
                <h6>National Food and Nutrition</h6>
                <div className="tools-stat-icon">
                  <IoDocumentTextSharp size={35} color="#b15d15" />
                </div>
              </div>
              <p3>Important Documents</p3>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "fnco-templates"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("fnco-templates")}
            >
              <div className="tools-stat-elements">
                <h6>Data Collection Tools</h6>
                <div className="tools-stat-iconOne">
                  <TbTemplate size={35} color="#076180" />
                </div>
              </div>
              <p3>(Templates)</p3>
            </div>
          </div>

          {/* Conditional Rendering of Components */}
          <div className="stat-content">
            {selectedStat === "fnco-templates" && <FNCOTemplates />}
            {selectedStat === "fnco-documents" && <FNCODocuments />}
          </div>
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default Documents;
