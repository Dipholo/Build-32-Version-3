import React, { useState } from "react";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import "./forms.css";
import "../styling/common.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export const AttendanceRegisterStaff = () => {
  const navigate = useNavigate();
  const [facilitatorName, setFacilitatorName] = useState("");
  const [organizingMinistry, setOrganizingMinistry] = useState("");
  const [supportingAgencies, setSupportingAgencies] = useState("");
  const [activity, setActivity] = useState("");
  const [subActivity, setSubActivity] = useState("");
  const [targetGroup, setTargetGroup] = useState("");
  const [date, setDate] = useState("");
  const [district, setDistrict] = useState("");
  const [communityCouncil, setCommunityCouncil] = useState("");
  const [village, setVillage] = useState("");
  const [venue, setVenue] = useState("");
  const [participants, setParticipants] = useState([
    {
      name: "",
      surname: "",
      gender: "",
      agency: "",
      role: "",
      email: "",
      contactNo: "",
    },
  ]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  const handleParticipantChange = (index, event) => {
    const { name, value } = event.target;
    const newParticipants = [...participants];
    newParticipants[index][name] = value;
    setParticipants(newParticipants);
  };

  const addParticipant = () => {
    const currentParticipant = participants[participants.length - 1];
    if (isParticipantDataValid(currentParticipant))
      setParticipants([
        ...participants,
        {
          name: "",
          surname: "",
          gender: "",
          agency: "",
          role: "",
          email: "",
          contactNo: "",
        },
      ]);
  };

  const isParticipantDataValid = (participant) => {
    return (
      participant.name &&
      participant.surname &&
      participant.gender &&
      participant.agency &&
      participant.role &&
      participant.email &&
      participant.contactNo
    );
  };

  const isAllParticipantsValid = participants.every(isParticipantDataValid);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!isAllParticipantsValid) {
      setModalMessage(
        "Please fill out all participant fields before submitting."
      );
      setIsSuccess(false);
      setIsModalOpen(true);
      return;
    }

    const formData = {
      facilitatorName,
      organizingMinistry,
      supportingAgencies,
      activity,
      subActivity,
      targetGroup,
      date,
      district,
      communityCouncil,
      village,
      venue,
      participants,
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-collection/staff-attendance",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(formData),
        }
      );
      const data = await response.json();
      setIsSuccess(true);
      setModalMessage(data.message);

      console.log(data);

      if (data.status === 401) {
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
          sessionStorage.setItem(
            "refreshToken",
            refreshResponse.data.refreshToken
          );
          //  console.log('token refreshed...' + sessionStorage.getItem('refreshToken'));
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem("accessToken", response.data.accessToken);
              sessionStorage.setItem(
                "refreshToken",
                response.data.refreshToken
              );
            })
            .catch((error) => {
              alert("Session expired. Please log in again.");
              sessionStorage.removeItem("accessToken");
              sessionStorage.removeItem("refreshToken");
              navigate("/");
            });
        }

        const retryResponse = await fetch(
          "http://localhost:1024/api/data-collection/staff-attendance",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
            },
            body: JSON.stringify(formData),
          }
        );

        const data = retryResponse.json();
        setIsSuccess(true);
        setModalMessage(data.message);
      }
    } catch (error) {
      setIsSuccess(false);
      setModalMessage("Something Happend. Please try submitting again");
    } finally {
      setIsModalOpen(true);
      //setModalMessage('Community attendance data successfully saved');
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="container" style={{ maxWidth: "1250px" }}>
      <header>
        <h2>Programme Staff Attendance Registration Tool</h2>
        <p className="description">
          (forums, meetings, dialogues, reviews, discussions)
        </p>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="facilitator-section form-aligned">
          <h4 className="facilitator">
            For Facilitator Use: refer to workplan for consistency
          </h4>
          <div className="form-group">
            <label>Facilitator Name</label>
            <input
              type="text"
              className="form-control-underline"
              value={facilitatorName}
              onChange={(e) => setFacilitatorName(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Organizing Ministry</label>
            <input
              type="text"
              className="form-control-underline"
              value={organizingMinistry}
              onChange={(e) => setOrganizingMinistry(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Supporting Agencies</label>
            <input
              type="text"
              className="form-control-underline"
              value={supportingAgencies}
              onChange={(e) => setSupportingAgencies(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Activity</label>
            <input
              type="text"
              className="form-control-underline"
              value={activity}
              onChange={(e) => setActivity(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Sub Activity</label>
            <input
              type="text"
              className="form-control-underline"
              value={subActivity}
              onChange={(e) => setSubActivity(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Target Group</label>
            <input
              type="text"
              className="form-control-underline"
              value={targetGroup}
              onChange={(e) => setTargetGroup(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Date</label>
            <input
              type="date"
              className="form-control-underline"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>District</label>
            <input
              type="text"
              className="form-control-underline"
              value={district}
              onChange={(e) => setDistrict(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Community Council</label>
            <input
              type="text"
              className="form-control-underline"
              value={communityCouncil}
              onChange={(e) => setCommunityCouncil(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Village</label>
            <input
              type="text"
              className="form-control-underline"
              value={village}
              onChange={(e) => setVillage(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Venue</label>
            <input
              type="text"
              className="form-control-underline"
              value={venue}
              onChange={(e) => setVenue(e.target.value)}
              required
            />
          </div>
        </div>

        <h4 className="participants-heading">Participants</h4>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>S/N</th>
              <th>Name</th>
              <th>Surname</th>
              <th>Gender </th>
              <th>Agency</th>
              <th>Role</th>
              <th>Email</th>
              <th>Contact No</th>
            </tr>
          </thead>
          <tbody>
            {participants.map((participant, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>
                  <input
                    type="text"
                    name="name"
                    className="underline-input"
                    value={participant.name}
                    onChange={(event) => handleParticipantChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <input
                    type="text"
                    name="surname"
                    className="underline-input"
                    value={participant.surname}
                    onChange={(event) => handleParticipantChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <select
                    name="gender"
                    className="underline-input"
                    value={participant.gender}
                    onChange={(event) => handleParticipantChange(index, event)}
                    required
                  >
                    <option value="">Select</option>
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                    <option value="O">Other</option>
                  </select>
                </td>
                <td>
                  <input
                    type="text"
                    name="agency"
                    className="underline-input"
                    value={participant.agency}
                    onChange={(event) => handleParticipantChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <input
                    type="text"
                    name="role"
                    className="underline-input"
                    value={participant.role}
                    onChange={(event) => handleParticipantChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <input
                    type="email"
                    name="email"
                    placeholder="name@gmail.com"
                    className="underline-input"
                    value={participant.email}
                    onChange={(event) => handleParticipantChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <input
                    type="tel"
                    name="contactNo"
                    placeholder="(+266)"
                    className="underline-input"
                    value={participant.contactNo}
                    onChange={(event) => handleParticipantChange(index, event)}
                    required
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="buttons">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={addParticipant}
          >
            Add Participant
          </button>
          <div className="spacer"></div>
          <button type="submit" className="btn btn-success">
            Submit
          </button>
        </div>
      </form>

      {/* Modal for Success/Error Message */}
      <Modal show={isModalOpen} onHide={closeModal}>
        <Modal.Header closeButton>
          <Modal.Title>{isSuccess ? "Success" : "Error"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{modalMessage}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default AttendanceRegisterStaff;
