import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "./forms.css";
import "../styling/common.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export const GroupRegistrationTool = () => {
  const navigate = useNavigate();

  const [groupName, setGroupName] = useState("");
  const [groupStatus, setGroupStatus] = useState("");
  const [groupType, setGroupType] = useState("");
  const [otherGroupType, setOtherGroupType] = useState("");
  const [district, setDistrict] = useState("");
  const [communityCouncil, setCommunityCouncil] = useState("");
  const [village, setVillage] = useState("");
  const [establishmentDate, setEstablishmentDate] = useState("");
  const [totalMembers, setTotalMembers] = useState({
    female: 0,
    male: 0,
    other: 0,
  });
  const [participants, setParticipants] = useState([
    {
      name: "",
      surname: "",
      gender: "",
      age: "",
      village: "",
      role: "",
      contact: "",
    },
  ]);

  // Modal state
  const [isModalOpen, setModalIsOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  const openModal = (message, success) => {
    setModalMessage(message);
    setIsSuccess(success);
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  const handleGroupTypeChange = (event) => {
    setGroupType(event.target.value);
    if (event.target.value !== "Other") {
      setOtherGroupType(""); // Clear the 'Other' input when a predefined option is selected
    }
  };

  const handleTotalMembersChange = (e) => {
    setTotalMembers({
      ...totalMembers,
      [e.target.name]: e.target.value,
    });
  };

  const addParticipant = () => {
    const lastParticipant = participants[participants.length - 1];

    // Check if the last participant's fields are filled
    if (
      lastParticipant.name &&
      lastParticipant.surname &&
      lastParticipant.gender &&
      lastParticipant.age >= 0 &&
      lastParticipant.village &&
      lastParticipant.role &&
      lastParticipant.contact
    ) {
      setParticipants([
        ...participants,
        {
          name: "",
          surname: "",
          gender: "",
          age: "",
          village: "",
          role: "",
          contact: "",
        },
      ]);
    } else {
      openModal(
        "Please fill in all fields for the last participant before adding a new one.",
        false
      );
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const groupData = {
      groupName,
      groupStatus,
      groupType: groupType === "Other" ? otherGroupType : groupType, // Use 'otherGroupType' if 'Other' is selected
      district,
      communityCouncil,
      village,
      establishmentDate,
      totalMembers,
      participants,
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-collection/group-registration",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(groupData),
        }
      );

      const data = await response.json();
      setIsSuccess(true);
      setModalMessage(data.message);
      console.log(data.status);

      if (data.status === 401) {
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
          sessionStorage.setItem(
            "refreshToken",
            refreshResponse.data.refreshToken
          );
          //  console.log('token refreshed...' + sessionStorage.getItem('refreshToken'));
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem("accessToken", response.data.accessToken);
              sessionStorage.setItem(
                "refreshToken",
                response.data.refreshToken
              );
            })
            .catch(() => {
              alert("Session expired. Please log in again.");
              sessionStorage.removeItem("accessToken");
              sessionStorage.removeItem("refreshToken");
              navigate("/");
            });
        }

        const retryResponse = await fetch(
          "http://localhost:1024/api/data-collection/group-registration",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
            },
            body: JSON.stringify(groupData),
          }
        );

        const data = retryResponse.json();
        setIsSuccess(true);
        setModalMessage(data.message);
      }
    } catch (error) {
      setModalMessage("Something Happend. Please try submitting again");
      openModal(`Error submitting form: ${error.message}`, false);
    }
  };

  return (
    <div className="container" style={{ maxWidth: "1250px" }}>
      <header>
        <h2>Group Registration Tool</h2>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="facilitator-section form-aligned">
          <div className="form-group">
            <label>Name of Group</label>
            <input
              type="text"
              className="form-control-underline"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>New, Revival, or Existing</label>
            <select
              className="form-control-underline"
              value={groupStatus}
              onChange={(e) => setGroupStatus(e.target.value)}
              required
            >
              <option value="">Select Status</option>
              <option value="New">New</option>
              <option value="Revival">Revival</option>
              <option value="Existing">Existing</option>
            </select>
          </div>

          <div className="form-group">
            <label>Type of Group</label>
            <select
              className="form-control-underline"
              value={groupType}
              onChange={handleGroupTypeChange}
              required
            >
              <option value="">Select Group Type</option>
              <option value="Breastfeeding Group">Breastfeeding Group</option>
              <option value="Mother Support Group">Mother Support Group</option>
              <option value="Father Support Group">Father Support Group</option>
              <option value="Farmers Group">Farmers Group</option>
              <option value="Cooperatives Group">Cooperatives Group</option>
              <option value="Nutrition Group">Nutrition Group</option>
              <option value="Youth Group">Youth Group</option>
              <option value="Other">Other</option>
            </select>
          </div>

          {groupType === "Other" && (
            <div className="form-group">
              <label>Specify Other Group Type</label>
              <input
                type="text"
                className="form-control-underline"
                value={otherGroupType}
                onChange={(e) => setOtherGroupType(e.target.value)}
                required
              />
            </div>
          )}

          <div className="form-group">
            <label>District</label>
            <input
              type="text"
              value={district}
              className="form-control-underline"
              onChange={(e) => setDistrict(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Community Council</label>
            <input
              type="text"
              value={communityCouncil}
              className="form-control-underline"
              onChange={(e) => setCommunityCouncil(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Village</label>
            <input
              type="text"
              value={village}
              className="form-control-underline"
              onChange={(e) => setVillage(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Group Establishment Date</label>
            <input
              type="date"
              value={establishmentDate}
              className="form-control-underline"
              onChange={(e) => setEstablishmentDate(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Total Number of Members</label>
            <br></br>
            <br></br>
            <label>Female</label>
            <input
              type="number"
              name="female"
              value={totalMembers.female}
              className="form-control-underline"
              onChange={handleTotalMembersChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Male</label>
            <input
              type="number"
              name="male"
              value={totalMembers.male}
              className="form-control-underline"
              onChange={handleTotalMembersChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Other</label>
            <input
              type="number"
              name="other"
              value={totalMembers.other}
              className="form-control-underline"
              onChange={handleTotalMembersChange}
            />
          </div>
        </div>

        <h3 className="brief-description">
          <h4 className="group-participants-heading">Group Participants </h4>
          (a group's structure includes Chairperson, Secretary, Treasurer, other
          committee members, & members)
        </h3>
        <div className="table-container">
          <table className="table table-striped">
            <thead>
              <tr>
                <th>S/N</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Gender</th>
                <th>Age</th>
                <th>Village</th>
                <th>Role/Designation</th>
                <th>Contact No.</th>
              </tr>
            </thead>
            <tbody>
              {participants.map((participant, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>
                    <input
                      className="underline-input"
                      type="text"
                      value={participant.name}
                      onChange={(e) => {
                        const updatedParticipants = [...participants];
                        updatedParticipants[index].name = e.target.value;
                        setParticipants(updatedParticipants);
                      }}
                      required
                    />
                  </td>
                  <td>
                    <input
                      className="underline-input"
                      type="text"
                      value={participant.surname}
                      onChange={(e) => {
                        const updatedParticipants = [...participants];
                        updatedParticipants[index].surname = e.target.value;
                        setParticipants(updatedParticipants);
                      }}
                      required
                    />
                  </td>
                  <td>
                    <select
                      className="underline-input"
                      value={participant.gender}
                      onChange={(e) => {
                        const updatedParticipants = [...participants];
                        updatedParticipants[index].gender = e.target.value;
                        setParticipants(updatedParticipants);
                      }}
                      required
                    >
                      <option value="">Select Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </td>
                  <td>
                    <input
                      className="underline-input"
                      type="number"
                      value={participant.age}
                      onChange={(e) => {
                        const updatedParticipants = [...participants];
                        updatedParticipants[index].age = e.target.value;
                        setParticipants(updatedParticipants);
                      }}
                      required
                    />
                  </td>
                  <td>
                    <input
                      className="underline-input"
                      type="text"
                      value={participant.village}
                      onChange={(e) => {
                        const updatedParticipants = [...participants];
                        updatedParticipants[index].village = e.target.value;
                        setParticipants(updatedParticipants);
                      }}
                      required
                    />
                  </td>
                  <td>
                    <input
                      className="underline-input"
                      type="text"
                      value={participant.role}
                      onChange={(e) => {
                        const updatedParticipants = [...participants];
                        updatedParticipants[index].role = e.target.value;
                        setParticipants(updatedParticipants);
                      }}
                      required
                    />
                  </td>
                  <td>
                    <input
                      className="underline-input"
                      type="tel"
                      placeholder="(+266)"
                      value={participant.contact}
                      onChange={(e) => {
                        const updatedParticipants = [...participants];
                        updatedParticipants[index].contact = e.target.value;
                        setParticipants(updatedParticipants);
                      }}
                      required
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="buttons">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={addParticipant}
          >
            Add Participant
          </button>
          <div className="spacer"></div>
          <button type="submit" className="btn btn-success">
            Submit
          </button>
        </div>
        <br />

        <h5 className="n-b">
          NB: Please have the group use attendance registers to track meeting
          attendance, and use the meeting minutes tool to document meetings{" "}
        </h5>
      </form>

      <Modal show={isModalOpen} onHide={closeModal}>
        <Modal.Header closeButton>
          <Modal.Title>{isSuccess ? "Success!" : "Error!"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{modalMessage}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default GroupRegistrationTool;
