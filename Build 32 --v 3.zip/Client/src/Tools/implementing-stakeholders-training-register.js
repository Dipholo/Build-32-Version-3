import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "./forms.css";
import "../styling/common.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export const TrainingRegisterStaff = () => {
  const navigate = useNavigate();
  const [facilitatorName, setFacilitatorName] = useState("");
  const [organizingMinistry, setOrganizingMinistry] = useState("");
  const [supportingAgencies, setSupportingAgencies] = useState("");
  const [activity, setActivity] = useState("");
  const [subActivity, setSubActivity] = useState("");
  const [targetGroup, setTargetGroup] = useState("");
  const [date, setDate] = useState("");
  const [district, setDistrict] = useState("");
  const [communityCouncil, setCommunityCouncil] = useState("");
  const [village, setVillage] = useState("");
  const [venue, setVenue] = useState("");
  const [participants, setParticipants] = useState([
    {
      name: "",
      surname: "",
      gender: "",
      agency: "",
      role: "",
      email: "",
      contactNo: "",
      presence: Array(5).fill("Absent"),
    },
  ]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  const handleParticipantChange = (index, event) => {
    const { name, value } = event.target;
    const newParticipants = [...participants];
    newParticipants[index][name] = value;
    setParticipants(newParticipants);
  };

  const handlePresenceChange = (index, day, value) => {
    const newParticipants = [...participants];
    newParticipants[index].presence[day] = value;
    setParticipants(newParticipants);
  };

  const isParticipantDataValid = (participant) => {
    return (
      participant.name &&
      participant.surname &&
      participant.gender &&
      participant.agency &&
      participant.role &&
      participant.email &&
      participant.contactNo
    );
  };

  const addParticipant = () => {
    const currentParticipant = participants[participants.length - 1];
    if (isParticipantDataValid(currentParticipant)) {
      setParticipants([
        ...participants,
        {
          name: "",
          surname: "",
          gender: "",
          agency: "",
          role: "",
          email: "",
          contactNo: "",
          presence: Array(5).fill("Absent"),
        },
      ]);
    } else {
      setModalMessage(
        "Please fill in all fields for the current participant before adding another."
      );
      setIsSuccess(false);
      setIsModalOpen(true);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    // Prepare participants data
    const transformedParticipants = participants.map((participant) => ({
      ...participant,
      presenceDay1: participant.presence[0],
      presenceDay2: participant.presence[1],
      presenceDay3: participant.presence[2],
      presenceDay4: participant.presence[3],
      presenceDay5: participant.presence[4],
    }));

    const formData = {
      facilitatorName,
      organizingMinistry,
      supportingAgencies,
      activity,
      subActivity,
      targetGroup,
      date,
      district,
      communityCouncil,
      village,
      venue,
      participants: transformedParticipants,
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-collection/staff-training",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(formData),
        }
      );

      const data = await response.json();
      setIsSuccess(true);
      setModalMessage(data.message);

      if (data.status === 401) {
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
          sessionStorage.setItem(
            "refreshToken",
            refreshResponse.data.refreshToken
          );
          //  console.log('token refreshed...' + sessionStorage.getItem('refreshToken'));
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem("accessToken", response.data.accessToken);
              sessionStorage.setItem(
                "refreshToken",
                response.data.refreshToken
              );
            })
            .catch(() => {
              alert("Session expired. Please log in again.");
              sessionStorage.removeItem("accessToken");
              sessionStorage.removeItem("refreshToken");
              navigate("/");
            });
        }

        const retryResponse = await fetch(
          "http://localhost:1024/api/data-collection/staff-training",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
            },
            body: JSON.stringify(formData),
          }
        );

        const data = retryResponse.json();
        setIsSuccess(true);
        setModalMessage(data.message);
      }
    } catch (error) {
      setIsSuccess(false);
      setModalMessage("Something Happend. Please try submitting again");
    } finally {
      setIsModalOpen(true);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="container" style={{ maxWidth: "1250px" }}>
      <header>
        <h2>Implementing Stakeholders Training Register</h2>
      </header>

      <form onSubmit={handleSubmit}>
        <h4 className="facilitator">
          For Facilitator Use: refer to workplan for consistency
        </h4>
        <div className="form-group">
          <label>Name of Facilitator(s):</label>
          <input
            type="text"
            value={facilitatorName}
            onChange={(e) => setFacilitatorName(e.target.value)}
            className="form-control-underline"
            required
          />
        </div>

        <div className="form-group">
          <label>Organizing Ministry:</label>
          <input
            type="text"
            className="form-control-underline"
            value={organizingMinistry}
            onChange={(e) => setOrganizingMinistry(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Supporting Agency(ies):</label>
          <input
            type="text"
            value={supportingAgencies}
            onChange={(e) => setSupportingAgencies(e.target.value)}
            className="form-control-underline"
            required
          />
        </div>

        <div className="form-group">
          <label>Activity:</label>
          <input
            type="text"
            value={activity}
            onChange={(e) => setActivity(e.target.value)}
            className="form-control-underline"
            required
          />
        </div>

        <div className="form-group">
          <label>Sub-activity:</label>
          <input
            type="text"
            value={subActivity}
            onChange={(e) => setSubActivity(e.target.value)}
            className="form-control-underline"
            required
          />
        </div>

        <div className="form-group">
          <label>Target Group:</label>
          <input
            type="text"
            value={targetGroup}
            onChange={(e) => setTargetGroup(e.target.value)}
            className="form-control-underline"
            required
          />
        </div>

        <div className="form-group">
          <label>Date:</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="form-control-underline"
            required
          />
        </div>

        <div className="form-group">
          <label>District:</label>
          <input
            type="text"
            value={district}
            onChange={(e) => setDistrict(e.target.value)}
            className="form-control-underline"
            required
          />
        </div>

        <div className="form-group">
          <label>Community Council:</label>
          <input
            type="text"
            value={communityCouncil}
            onChange={(e) => setCommunityCouncil(e.target.value)}
            className="form-control-underline"
            required
          />
        </div>

        <div className="form-group">
          <label>Village:</label>
          <input
            type="text"
            value={village}
            onChange={(e) => setVillage(e.target.value)}
            className="form-control-underline"
            required
          />
        </div>

        <div className="form-group">
          <label>Venue:</label>
          <input
            type="text"
            value={venue}
            onChange={(e) => setVenue(e.target.value)}
            className="form-control-underline"
            required
          />
        </div>

        <h3 className="participants-heading">Participants</h3>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>S/N</th>
              <th>Name</th>
              <th>Surname</th>
              <th>Gender </th>
              <th>Agency</th>
              <th>Role</th>
              <th>Email</th>
              <th>Contact No</th>
              <th>Day 1</th>
              <th>Day 2</th>
              <th>Day 3</th>
              <th>Day 4</th>
              <th>Day 5</th>
            </tr>
          </thead>
          <tbody>
            {participants.map((participant, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>
                  <input
                    type="text"
                    name="name"
                    value={participant.name}
                    onChange={(event) => handleParticipantChange(index, event)}
                    className="underline-input"
                    required
                  />
                </td>
                <td>
                  <input
                    type="text"
                    name="surname"
                    value={participant.surname}
                    onChange={(event) => handleParticipantChange(index, event)}
                    className="underline-input"
                    required
                  />
                </td>
                <td>
                  <select
                    name="gender"
                    value={participant.gender}
                    onChange={(event) => handleParticipantChange(index, event)}
                    className="underline-input"
                    required
                  >
                    <option value="">Select</option>
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                    <option value="O">Other</option>
                  </select>
                </td>
                <td>
                  <input
                    type="text"
                    name="agency"
                    value={participant.agency}
                    onChange={(event) => handleParticipantChange(index, event)}
                    className="underline-input"
                    required
                  />
                </td>
                <td>
                  <input
                    type="text"
                    name="role"
                    value={participant.role}
                    onChange={(event) => handleParticipantChange(index, event)}
                    className="underline-input"
                    required
                  />
                </td>
                <td>
                  <input
                    type="email"
                    name="email"
                    placeholder="name@gmail.com"
                    value={participant.email}
                    onChange={(event) => handleParticipantChange(index, event)}
                    className="underline-input"
                    required
                  />
                </td>
                <td>
                  <input
                    type="tel"
                    name="contactNo"
                    placeholder="(+266)"
                    value={participant.contactNo}
                    onChange={(event) => handleParticipantChange(index, event)}
                    className="underline-input"
                    required
                  />
                </td>
                {[0, 1, 2, 3, 4].map((dayIndex) => (
                  <td key={dayIndex}>
                    <select
                      value={participant.presence[dayIndex]}
                      onChange={(e) =>
                        handlePresenceChange(index, dayIndex, e.target.value)
                      }
                      className="underline-input"
                      required
                    >
                      <option value="Absent">Absent</option>
                      <option value="Present">Present</option>
                    </select>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        <div className="buttons">
          <button
            type="button"
            onClick={addParticipant}
            className="btn btn-secondary"
          >
            Add Participant
          </button>
          <div className="spacer"></div>

          <button type="submit" className="btn btn-success">
            Submit
          </button>
        </div>
      </form>

      <Modal show={isModalOpen} onHide={closeModal}>
        <Modal.Header closeButton>
          <Modal.Title>{isSuccess ? "Success" : "Error"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{modalMessage}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default TrainingRegisterStaff;
