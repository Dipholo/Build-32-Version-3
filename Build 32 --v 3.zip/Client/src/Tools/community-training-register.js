import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "./forms.css";
import "../styling/common.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export const TrainingRegisterCommunity = () => {
  const navigate = useNavigate();

  const [facilitatorName, setFacilitatorName] = useState("");
  const [organizingMinistry, setOrganizingMinistry] = useState("");
  const [supportingAgencies, setSupportingAgencies] = useState("");
  const [activity, setActivity] = useState("");
  const [subActivity, setSubActivity] = useState("");
  const [targetGroup, setTargetGroup] = useState("");
  const [date, setDate] = useState("");
  const [district, setDistrict] = useState("");
  const [communityCouncil, setCommunityCouncil] = useState("");
  const [village, setVillage] = useState("");
  const [venue, setVenue] = useState("");
  const [participants, setParticipants] = useState([
    {
      name: "",
      surname: "",
      gender: "",
      dob: "",
      age: "",
      village: "",
      role: "",
      contactNo: "",
      presence: Array(5).fill("Absent"),
    },
  ]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  const handleParticipantChange = (index, event) => {
    const { name, value } = event.target;
    const newParticipants = [...participants];
    newParticipants[index][name] = value;

    if (name === "dob") {
      const dob = new Date(value);
      const today = new Date();
      const age = today.getFullYear() - dob.getFullYear();
      const monthDifference = today.getMonth() - dob.getMonth();
      if (
        monthDifference < 0 ||
        (monthDifference === 0 && today.getDate() < dob.getDate())
      ) {
        newParticipants[index].age = age - 1;
      } else {
        newParticipants[index].age = age;
      }
    }

    setParticipants(newParticipants);
  };

  const handlePresenceChange = (index, dayIndex, value) => {
    const newParticipants = [...participants];
    newParticipants[index].presence[dayIndex] = value;
    setParticipants(newParticipants);
  };

  const canAddParticipant = () => {
    const lastParticipant = participants[participants.length - 1];
    return isParticipantDataValid(lastParticipant);
  };

  const addParticipant = () => {
    if (canAddParticipant()) {
      setParticipants([
        ...participants,
        {
          name: "",
          surname: "",
          gender: "",
          dob: "",
          age: "",
          village: "",
          role: "",
          contactNo: "",
          presence: Array(5).fill("Absent"),
        },
      ]);
    }
  };

  const isParticipantDataValid = (participant) => {
    return (
      participant.name &&
      participant.surname &&
      participant.gender &&
      participant.dob &&
      participant.age >= 0 &&
      participant.village &&
      participant.role &&
      participant.contactNo
    );
  };

  const isAllParticipantsValid = () => {
    return participants.every(isParticipantDataValid);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    // Prepare participants data
    const transformedParticipants = participants.map((participant) => ({
      ...participant,
      presenceDay1: participant.presence[0],
      presenceDay2: participant.presence[1],
      presenceDay3: participant.presence[2],
      presenceDay4: participant.presence[3],
      presenceDay5: participant.presence[4],
    }));

    const formData = {
      facilitatorName,
      organizingMinistry,
      supportingAgencies,
      activity,
      subActivity,
      targetGroup,
      date,
      district,
      communityCouncil,
      village,
      venue,
      participants: transformedParticipants, // Use transformed data
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-collection/community-training",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(formData),
        }
      );

      const data = await response.json();
      setIsSuccess(true);
      setModalMessage(data.message);

      if (data.status === 401) {
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
          sessionStorage.setItem(
            "refreshToken",
            refreshResponse.data.refreshToken
          );
          //  console.log('token refreshed...' + sessionStorage.getItem('refreshToken'));
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem("accessToken", response.data.accessToken);
              sessionStorage.setItem(
                "refreshToken",
                response.data.refreshToken
              );
            })
            .catch(() => {
              alert("Session expired. Please log in again.");
              sessionStorage.removeItem("accessToken");
              sessionStorage.removeItem("refreshToken");
              navigate("/");
            });
        }

        const retryResponse = await fetch(
          "http://localhost:1024/api/data-collection/community-training",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
            },
            body: JSON.stringify(formData),
          }
        );

        const data = retryResponse.json();
        setIsSuccess(true);
        setModalMessage(data.message);

        // Reset form fields
        setFacilitatorName("");
        setOrganizingMinistry("");
        setSupportingAgencies("");
        setActivity("");
        setSubActivity("");
        setTargetGroup("");
        setDate("");
        setDistrict("");
        setCommunityCouncil("");
        setVillage("");
        setVenue("");
        setParticipants([
          {
            name: "",
            surname: "",
            gender: "",
            dob: "",
            age: "",
            village: "",
            role: "",
            contactNo: "",
            presence: Array(5).fill("Absent"),
          },
        ]);
      }
    } catch (error) {
      setIsSuccess(false);
      setModalMessage("Something Happend. Please try submitting again");
    } finally {
      setIsModalOpen(true);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="container" style={{ maxWidth: "1250px" }}>
      <header>
        <h2>Community Training Register</h2>
      </header>
      <h4 className="facilitator">
        For Facilitator Use: refer to workplan for consistency
      </h4>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Facilitator Name(s)</label>
          <input
            type="text"
            className="underline-input"
            value={facilitatorName}
            onChange={(e) => setFacilitatorName(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Organizing Ministry</label>
          <input
            type="text"
            className="underline-input"
            value={organizingMinistry}
            onChange={(e) => setOrganizingMinistry(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Supporting Agency(ies)</label>
          <input
            type="text"
            className="underline-input"
            value={supportingAgencies}
            onChange={(e) => setSupportingAgencies(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Activity</label>
          <input
            type="text"
            className="underline-input"
            value={activity}
            onChange={(e) => setActivity(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Sub-Activity</label>
          <input
            type="text"
            className="underline-input"
            value={subActivity}
            onChange={(e) => setSubActivity(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Target Group</label>
          <input
            type="text"
            className="underline-input"
            value={targetGroup}
            onChange={(e) => setTargetGroup(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Date</label>
          <input
            type="date"
            className="underline-input"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>District</label>
          <input
            type="text"
            className="underline-input"
            value={district}
            onChange={(e) => setDistrict(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Community Council</label>
          <input
            type="text"
            className="underline-input"
            value={communityCouncil}
            onChange={(e) => setCommunityCouncil(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Village</label>
          <input
            type="text"
            className="underline-input"
            value={village}
            onChange={(e) => setVillage(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Venue</label>
          <input
            type="text"
            className="underline-input"
            value={venue}
            onChange={(e) => setVenue(e.target.value)}
            required
          />
        </div>

        <h3 className="participants-heading">Participants</h3>
        <div className="table-container">
          <table className="table table-striped">
            <thead>
              <tr>
                <th>S/N</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>Age</th>
                <th>Village</th>
                <th>Role</th>
                <th>Contact No</th>
                <th>Presence Day 1</th>
                <th>Presence Day 2</th>
                <th>Presence Day 3</th>
                <th>Presence Day 4</th>
                <th>Presence Day 5</th>
              </tr>
            </thead>
            <tbody>
              {participants.map((participant, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>
                    <input
                      type="text"
                      className="form-control-underline"
                      name="name"
                      value={participant.name}
                      onChange={(event) =>
                        handleParticipantChange(index, event)
                      }
                      required
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      className="form-control-underline"
                      name="surname"
                      value={participant.surname}
                      onChange={(event) =>
                        handleParticipantChange(index, event)
                      }
                      required
                    />
                  </td>
                  <td>
                    <select
                      name="gender"
                      value={participant.gender}
                      onChange={(event) =>
                        handleParticipantChange(index, event)
                      }
                      className="form-control-underline"
                      required
                    >
                      <option value="">Select Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </td>
                  <td>
                    <input
                      type="date"
                      className="form-control-underline"
                      name="dob"
                      value={participant.dob}
                      onChange={(event) =>
                        handleParticipantChange(index, event)
                      }
                      required
                    />
                  </td>
                  <td>{participant.age}</td>
                  <td>
                    <input
                      type="text"
                      className="form-control-underline"
                      name="village"
                      value={participant.village}
                      onChange={(event) =>
                        handleParticipantChange(index, event)
                      }
                      required
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      className="form-control-underline"
                      name="role"
                      value={participant.role}
                      onChange={(event) =>
                        handleParticipantChange(index, event)
                      }
                      required
                    />
                  </td>
                  <td>
                    <input
                      type="tel"
                      className="form-control-underline"
                      name="contactNo"
                      placeholder="(+266)"
                      value={participant.contactNo}
                      onChange={(event) =>
                        handleParticipantChange(index, event)
                      }
                      required
                    />
                  </td>
                  {[0, 1, 2, 3, 4].map((dayIndex) => (
                    <td key={dayIndex}>
                      <select
                        value={participant.presence[dayIndex]}
                        onChange={(e) =>
                          handlePresenceChange(index, dayIndex, e.target.value)
                        }
                        className="form-control-underline"
                        required
                      >
                        <option value="Absent">Absent</option>
                        <option value="Present">Present</option>
                      </select>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="buttons">
          <Button
            type="button"
            className="btn btn-secondary"
            onClick={addParticipant}
            disabled={!canAddParticipant()}
          >
            Add Participant
          </Button>
          <div className="spacer"></div>
          <Button
            type="submit"
            className="btn btn-success"
            disabled={!isAllParticipantsValid()}
          >
            Submit
          </Button>
        </div>
      </form>

      <Modal show={isModalOpen} onHide={closeModal}>
        <Modal.Header closeButton>
          <Modal.Title>{isSuccess ? "Success" : "Error"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{modalMessage}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default TrainingRegisterCommunity;
