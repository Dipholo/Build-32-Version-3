import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "./forms.css";
import "../styling/common.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export const DistributionToolInstitutions = () => {
  const navigate = useNavigate();

  const [facilitatorName, setFacilitatorName] = useState("");
  const [organizingMinistry, setOrganizingMinistry] = useState("");
  const [supportingAgencies, setSupportingAgencies] = useState("");
  const [activity, setActivity] = useState("");
  const [subActivity, setSubActivity] = useState("");
  const [targetGroup, setTargetGroup] = useState("");
  const [date, setDate] = useState("");
  const [district, setDistrict] = useState("");
  const [communityCouncil, setCommunityCouncil] = useState("");
  const [village, setVillage] = useState("");
  const [venue, setLocation] = useState("");
  const [recipients, setRecipients] = useState([
    {
      name: "",
      surname: "",
      gender: "",
      recipientVillage: "",
      institutionName: "",
      role: "",
      items: "",
      quantity: "",
      contactNo: "",
    },
  ]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  const handleRecipientChange = (index, event) => {
    const { name, value } = event.target;
    const updatedRecipients = [...recipients];
    updatedRecipients[index][name] = value;
    setRecipients(updatedRecipients);
  };

  const addRecipient = () => {
    const currentRecipient = recipients[recipients.length - 1];
    if (isRecipientDataValid(currentRecipient))
      setRecipients([
        ...recipients,
        {
          name: "",
          surname: "",
          gender: "",
          recipientVillage: "",
          institutionName: "",
          role: "",
          items: "",
          quantity: "",
          contactNo: "",
        },
      ]);
  };

  const isRecipientDataValid = (recipient) => {
    return Object.values(recipient).every((value) => value);
  };

  const isAllRecipientsValid = recipients.every(isRecipientDataValid);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!isAllRecipientsValid) {
      setModalMessage(
        "Please fill out all recipient fields before submitting."
      );
      setIsSuccess(false);
      setIsModalOpen(true);
      return;
    }

    const formData = {
      facilitatorName,
      organizingMinistry,
      supportingAgencies,
      activity,
      subActivity,
      targetGroup,
      date,
      district,
      communityCouncil,
      village,
      venue,
      recipients,
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-collection/distribution-institutions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(formData),
        }
      );

      const data = await response.json();
      setIsSuccess(true);
      setModalMessage(data.message);

      if (data.status === 401) {
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
          sessionStorage.setItem(
            "refreshToken",
            refreshResponse.data.refreshToken
          );
          //  console.log('token refreshed...' + sessionStorage.getItem('refreshToken'));
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem("accessToken", response.data.accessToken);
              sessionStorage.setItem(
                "refreshToken",
                response.data.refreshToken
              );
            })
            .catch(() => {
              alert("Session expired. Please log in again.");
              sessionStorage.removeItem("accessToken");
              sessionStorage.removeItem("refreshToken");
              navigate("/");
            });
        }

        const retryResponse = await fetch(
          "http://localhost:1024/api/data-collection/distribution-individuals",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
            },
            body: JSON.stringify(formData),
          }
        );

        const data = retryResponse.json();
        setIsSuccess(true);
        setModalMessage(data.message);
      }
    } catch (error) {
      setIsSuccess(false);
      setModalMessage("Something Happend. Please try submitting again");
    } finally {
      setIsModalOpen(true);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="container" style={{ maxWidth: "1250px" }}>
      <header>
        <h2>Institution-based Distribution Tool</h2>
        <p className="description">
          (seeds, livestock, food items, hygiene kits, testing kits, etc.)
        </p>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="facilitator-section form-aligned">
          <h4 className="facilitator">For Facilitator Use</h4>
          <div className="form-group">
            <label>Facilitator Name</label>
            <input
              type="text"
              className="form-control-underline"
              value={facilitatorName}
              onChange={(e) => setFacilitatorName(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Organizing Ministry</label>
            <input
              type="text"
              className="form-control-underline"
              value={organizingMinistry}
              onChange={(e) => setOrganizingMinistry(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Supporting Agencies</label>
            <input
              type="text"
              className="form-control-underline"
              value={supportingAgencies}
              onChange={(e) => setSupportingAgencies(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Activity</label>
            <input
              type="text"
              className="form-control-underline"
              value={activity}
              onChange={(e) => setActivity(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Sub Activity</label>
            <input
              type="text"
              className="form-control-underline"
              value={subActivity}
              onChange={(e) => setSubActivity(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Target Group</label>
            <input
              type="text"
              className="form-control-underline"
              value={targetGroup}
              onChange={(e) => setTargetGroup(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Date</label>
            <input
              type="date"
              className="form-control-underline"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>District</label>
            <input
              type="text"
              className="form-control-underline"
              value={district}
              onChange={(e) => setDistrict(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Community Council</label>
            <input
              type="text"
              className="form-control-underline"
              value={communityCouncil}
              onChange={(e) => setCommunityCouncil(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Village</label>
            <input
              type="text"
              className="form-control-underline"
              value={village}
              onChange={(e) => setVillage(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Location</label>
            <input
              type="text"
              className="form-control-underline"
              value={venue}
              onChange={(e) => setLocation(e.target.value)}
              required
            />
          </div>
        </div>

        <h3 className="participants-heading">
          <h4 className="group-participants-heading">Recipients</h4>
          (the names of people receiving items on behalf of community, school,
          health facility)
        </h3>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>S/N</th>
              <th>Name</th>
              <th>Surname</th>
              <th>Gender </th>
              <th>Village</th>
              <th>Name of Institution</th>
              <th>Role</th>
              <th>Items Received</th>
              <th>Quantity</th>
              <th>Contact No</th>
            </tr>
          </thead>
          <tbody>
            {recipients.map((recipient, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>
                  <input
                    type="text"
                    name="name"
                    className="underline-input"
                    value={recipient.name}
                    onChange={(event) => handleRecipientChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <input
                    type="text"
                    name="surname"
                    className="underline-input"
                    value={recipient.surname}
                    onChange={(event) => handleRecipientChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <select
                    type="text"
                    name="gender"
                    className="underline-input"
                    value={recipient.gender}
                    onChange={(event) => handleRecipientChange(index, event)}
                    required
                  >
                    <option value="">Select</option>
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                    <option value="O">Other</option>
                  </select>
                </td>
                <td>
                  <input
                    type="text"
                    name="recipientVillage"
                    className="underline-input"
                    value={recipient.recipientVillage}
                    onChange={(event) => handleRecipientChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <input
                    type="text"
                    name="institutionName"
                    className="underline-input"
                    value={recipient.institutionName}
                    onChange={(event) => handleRecipientChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <input
                    type="text"
                    name="role"
                    className="underline-input"
                    value={recipient.role}
                    onChange={(event) => handleRecipientChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <input
                    type="text"
                    name="items"
                    className="underline-input"
                    value={recipient.items}
                    onChange={(event) => handleRecipientChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <input
                    type="number"
                    name="quantity"
                    className="underline-input"
                    value={recipient.quantity}
                    onChange={(event) => handleRecipientChange(index, event)}
                    required
                  />
                </td>
                <td>
                  <input
                    type="tel"
                    name="contactNo"
                    placeholder="(+266)"
                    className="underline-input"
                    value={recipient.contactNo}
                    onChange={(event) => handleRecipientChange(index, event)}
                    required
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="buttons">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={addRecipient}
          >
            Add Recipient
          </button>
          <div className="spacer"></div>
          <button type="submit" className="btn btn-success">
            Submit
          </button>
        </div>
      </form>

      <Modal show={isModalOpen} onHide={closeModal}>
        <Modal.Header closeButton>
          <Modal.Title>{isSuccess ? "Success" : "Error"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{modalMessage}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default DistributionToolInstitutions;
