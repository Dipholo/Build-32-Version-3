import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "./forms.css";
import "../styling/common.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export const MonitoringVisitTool = () => {
  const navigate = useNavigate();
  const [visitBy, setVisitBy] = useState("");
  const [ministry, setMinistry] = useState("");
  const [district, setDistrict] = useState("");
  const [location, setLocation] = useState("");
  const [date, setDate] = useState("");
  const [objectives, setObjectives] = useState([
    "To assess if necessary documentation is present during distributions",
  ]);
  const [activities, setActivities] = useState([[]]); // Start with one empty array for activities
  const [challenges, setChallenges] = useState("");
  const [mitigations, setMitigations] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  const handleObjectiveChange = (index, event) => {
    const newObjectives = [...objectives];
    newObjectives[index] = event.target.value;
    setObjectives(newObjectives);
  };

  const handleActivityChange = (objectiveIndex, activityIndex, event) => {
    const { name, value } = event.target;
    const newActivities = [...activities];
    newActivities[objectiveIndex][activityIndex][name] = value;
    setActivities(newActivities);
  };

  const addActivity = (objectiveIndex) => {
    const newActivities = [...activities];
    newActivities[objectiveIndex] = [
      ...newActivities[objectiveIndex],
      { activity: "", requirement: "", findings: "" },
    ];
    setActivities(newActivities);
  };

  const addObjective = () => {
    setObjectives([...objectives, ""]); // Add an empty objective
    setActivities([...activities, []]); // Add a new empty array for activities for the new objective
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const formData = {
      visitBy,
      ministry,
      district,
      location,
      date,
      objectives,
      activities,
      challenges,
      mitigations,
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-collection/monitoring-visit",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(formData),
        }
      );

      const data = await response.json();
      setIsSuccess(true);
      setModalMessage(data.message);

      if (data.status === 401) {
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
          sessionStorage.setItem(
            "refreshToken",
            refreshResponse.data.refreshToken
          );
          //  console.log('token refreshed...' + sessionStorage.getItem('refreshToken'));
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem("accessToken", response.data.accessToken);
              sessionStorage.setItem(
                "refreshToken",
                response.data.refreshToken
              );
            })
            .catch(() => {
              alert("Session expired. Please log in again.");
              sessionStorage.removeItem("accessToken");
              sessionStorage.removeItem("refreshToken");
              navigate("/");
            });
        }

        const retryResponse = await fetch(
          "http://localhost:1024/api/data-collection/monitoring-visit",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
            },
            body: JSON.stringify(formData),
          }
        );

        const data = retryResponse.json();
        setIsSuccess(true);
        setModalMessage(data.message);
      }
    } catch (error) {
      setIsSuccess(false);
      setModalMessage("Something Happend. Please try submitting again");
    } finally {
      setIsModalOpen(true);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setVisitBy("");
    setMinistry("");
    setDistrict("");
    setLocation("");
    setDate("");
    setObjectives([
      "To assess if necessary documentation is present during distributions",
    ]);
    setActivities([[]]);
    setChallenges("");
    setMitigations("");
  };

  return (
    <div className="container" style={{ maxWidth: "1250px" }}>
      <header>
        <h2>Monitoring Visit Tool</h2>
      </header>
      <h4 className="facilitator">For Facilitator Use</h4>
      <form className="form-group" onSubmit={handleSubmit}>
        {/* Visit Conducted By */}
        <div className="form-group">
          <label htmlFor="visitBy">Visit Conducted By</label>
          <input
            id="visitBy"
            type="text"
            className="form-control-underline"
            value={visitBy}
            onChange={(e) => setVisitBy(e.target.value)}
            required
          />
        </div>

        {/* Relevant Ministry/Agency */}
        <div className="form-group">
          <label htmlFor="ministry">Relevant Ministry/Agency</label>
          <input
            id="ministry"
            type="text"
            className="form-control-underline"
            value={ministry}
            onChange={(e) => setMinistry(e.target.value)}
            required
          />
        </div>

        {/* District */}
        <div className="form-group">
          <label htmlFor="district">District</label>
          <input
            id="district"
            type="text"
            className="form-control-underline"
            value={district}
            onChange={(e) => setDistrict(e.target.value)}
            required
          />
        </div>

        {/* Location/Sites */}
        <div className="form-group">
          <label htmlFor="location">Location/Sites</label>
          <input
            id="location"
            type="text"
            className="form-control-underline"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            required
          />
        </div>

        {/* Date */}
        <div className="form-group">
          <label htmlFor="date">Date</label>
          <input
            id="date"
            type="date"
            className="form-control-underline"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />
        </div>

        {/* Monitoring Visit Objectives */}
        <h3>Monitoring Visit Objectives</h3>
        {objectives.map((objective, index) => (
          <div key={index} className="form-group">
            <label htmlFor={`objective-${index}`}>Objective {index + 1}</label>
            <input
              id={`objective-${index}`}
              type="text"
              className="form-control-underline"
              value={objective}
              onChange={(e) => handleObjectiveChange(index, e)}
              required={index === 0} // Make the first objective required
            />

            {/* Monitoring Activities for Each Objective */}
            <h4>Monitoring Activities for Objective {index + 1}</h4>
            <table className="table table-striped activity-table">
              <thead>
                <tr>
                  <th>Activity/Item/Process</th>
                  <th>Requirement (Per Programme Standards)</th>
                  <th>Findings</th>
                </tr>
              </thead>
              <tbody>
                {activities[index]?.map((activity, activityIndex) => (
                  <tr key={activityIndex}>
                    <td>
                      <input
                        type="text"
                        name="activity"
                        className="underline-input"
                        value={activity.activity}
                        onChange={(event) =>
                          handleActivityChange(index, activityIndex, event)
                        }
                        required
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        name="requirement"
                        className="underline-input"
                        value={activity.requirement}
                        onChange={(event) =>
                          handleActivityChange(index, activityIndex, event)
                        }
                        required
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        name="findings"
                        className="underline-input"
                        value={activity.findings}
                        onChange={(event) =>
                          handleActivityChange(index, activityIndex, event)
                        }
                        required
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => addActivity(index)}
            >
              Add Activity for Objective {index + 1}
            </button>
          </div>
        ))}

        <button
          type="button"
          className="btn btn-secondary"
          onClick={addObjective}
        >
          Add Objective
        </button>

        {/* Field Challenges */}
        <h3>Field Challenges</h3>
        <div className="form-group">
          <textarea
            className="form-textarea"
            value={challenges}
            onChange={(e) => setChallenges(e.target.value)}
            required
            rows="4"
            placeholder="Describe field challenges encountered..."
          ></textarea>
        </div>

        {/* Mitigations */}
        <h3>Mitigations</h3>
        <div className="form-group">
          <textarea
            className="form-textarea"
            value={mitigations}
            onChange={(e) => setMitigations(e.target.value)}
            required
            rows="4"
            placeholder="Outline any mitigation strategies..."
          ></textarea>
        </div>

        {/* Submit Button */}
        <div className="form-group">
          <button type="submit" className="btn btn-success">
            Submit
          </button>
        </div>
      </form>

      <Modal show={isModalOpen} onHide={closeModal}>
        <Modal.Header closeButton>
          <Modal.Title>{isSuccess ? "Success" : "Error"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{modalMessage}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default MonitoringVisitTool;
