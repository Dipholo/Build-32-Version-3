import React, { useRef, useEffect } from "react";
import "./Notifications.css";
import { BsFillCheckCircleFill } from "react-icons/bs";
import { LuCalendarRange } from "react-icons/lu";
import { FaUserCircle } from "react-icons/fa";

const NotificationsPopup = ({ isOpen, onClose }) => {
  const popupRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (popupRef.current && !popupRef.current.contains(event.target)) {
        onClose();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [onClose]);

  return (
    isOpen && (
      <div className="notifications-popup" ref={popupRef}>
        <h4 className="notifications-title">Notifications</h4>
        <ul className="notifications-list">
          <li className="notification-item">
            <BsFillCheckCircleFill className="notif-icon" size={25} />
            <span>
              <strong>Invitation accepted</strong> You have been invited...
            </span>
          </li>
          <li className="notification-item-two">
            <FaUserCircle className="notif-icon" size={35} />
            <span>
              <strong>FNCO District</strong> I just updated the Atttendance tool
              from Leribe
            </span>
          </li>
          <li className="notification-item">
            <LuCalendarRange className="notif-icon" size={25} />
            <span>
              <strong>To Do</strong> Meeting with Nathan on Friday 8 AM...
            </span>
          </li>
        </ul>
        <div className="see-all-activity">
          <a href="#">See all activity</a>
        </div>
      </div>
    )
  );
};

export default NotificationsPopup;
