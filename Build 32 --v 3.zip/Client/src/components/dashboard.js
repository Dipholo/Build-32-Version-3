import React from "react";
import { Link } from "react-router-dom";
import "../styling/styles.css";

const Dashboard = () => {
  return (
    <div className="dashboard">
      <h1>Data Collection Tools Dashboard</h1>
      <ul>
        <li>
          <Link to="/attendance-register-community">
            Community Attendance Registration Tool (forums, meetings, dialogues,
            discussion, reviews)
          </Link>
        </li>
        <li>
          <Link to="/attendance-register-staff">
            Programme Staff Attendance Registration Tool (forums, meetings,
            dialogues, reviews, discussions)
          </Link>
        </li>
        <li>
          <Link to="/distribution-tool-individuals">
            Beneficiary Distribution Tool (seeds, livestock, food items, hygiene
            kits, testing kits, etc.)
          </Link>
        </li>
        <li>
          <Link to="/distribution-tool-institution">
            Institution-based Distribution Tool (seeds, livestock, food items,
            hygiene kits, testing kits, etc.)
          </Link>
        </li>
        <li>
          <Link to="/training-register-community">
            Community Training Register
          </Link>
        </li>
        <li>
          <Link to="/training-register-staff">
            Implementing Stakeholders Training Register
          </Link>
        </li>
        <li>
          <Link to="/group-registration-tool">Group Registration Tool</Link>
        </li>
        <li>
          <Link to="/monitoring-visit-tool">Monitoring Visit Tool</Link>
        </li>
      </ul>
    </div>
  );
};

export default Dashboard;
