import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css"; // Ensure this is imported
import "./maternalChildHealth.css"; 
import axios from "axios";
import { useNavigate } from "react-router-dom";

const MaternalChildHealthForm = () => {
  const navigate = useNavigate();
  const initialIndicators = {
    "Proportion of women who received post-natal check/visit within 2 days after delivery":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of children 12-23 months of age, who have received age appropriate immunizations according to national standards":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of women whose last delivery was attended by a skilled health personnel":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of women who received Ante Natal Care (ANC) within the first trimester from a skilled birth provider, in their most recent birth":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of women who received at least 8 Ante Natal Care (ANC) visits from a skilled birth provider in their most recent birth":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of women 15-49 years of age who are currently using a modern method of contraception":
      {
        date: "",
        district: "",
        value: "",
      },
    "HIV prevalence among women 15-49 years of age": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Campaigns held on Pre ANC, ANC, Post Natal Care (PNC) and family planning":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of Women of child bearing age (15-49 years) reached through campaigns on Pre ANC, PNC, and family planning":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of Fathers reached through campaigns on Pre ANC, PNC and family planning":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of Community leaders reached through campaigns on Pre ANC, PNC, and family planning":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of Campaigns held on the importance of immunization for under 5s": {
      date: "",
      district: "",
      value: "",
    },
    "Number of People reached during campaigns on the importance of immunizations for under 5s":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of People who received IEC materials on immunization": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Mobile clinics organized and providing maternal and child care services":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of Women reached through mobile clinics": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Health facility staff trained on growth monitoring methods and referral systems":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of VHWs trained on growth monitoring methods and referral systems":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of People successfully referred for health services (by service type; identification, treatment, counselling, etc.)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of Revived mother support groups": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Newly established Mother support groups": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Children enrolled in community-based growth monitoring": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Adolescents and young people (10-24 years) reached with life skills sessions":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of SADC laws on child marriage domesticated in Lesotho": {
      date: "",
      district: "",
      value: "",
    },
    "Status of Maternal and Child Health Programs (Not Started, Underway, Complete)":
      {
        date: "",
        district: "",
        value: "",
      },
  };

  const [formData, setFormData] = useState(initialIndicators);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  const handleChange = (e, indicator) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [indicator]: {
        ...formData[indicator],
        [name]: value,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Filter form data to include only those indicators with filled data
    const filteredData = Object.entries(formData)
      .filter(([key, { date, district, value }]) => date && district && value) // Only include filled data
      .reduce((acc, [key, { date, district, value }]) => {
        acc[key] = { date, district, value };
        return acc;
      }, {});

    if (Object.keys(filteredData).length === 0) {
      setModalMessage("Please fill in data for at least one indicator.");
      setModalIsOpen(true); // Open modal
      return;
    }

    const requestData = {
      formData: filteredData,
      KRA: "Maternal and Child Health", // Add the KRA field here
      Ministry: "Ministry of Health",
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-entry/add-indicator-data",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(requestData), 
        }
      );

      const data = await response.json();
      if (data.status === 403) {
     
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem('accessToken', response.data.accessToken);
              sessionStorage.setItem('refreshToken', response.data.refreshToken);
            })
            .catch((error) => {
              alert("Session expired. Please log in again.");
              navigate("/");
            });
        }
      } 

      if (response.ok) {
        setModalMessage("Data added successfully!");
        setModalIsOpen(true); 
        setFormData(initialIndicators); 
      } else {
        setModalMessage(`Error: ${data.error}`);
        setModalIsOpen(true); 
      }
    } catch (error) {
      console.error("Error submitting data:", error);
      setModalMessage("Failed to submit data. Please try again.");
      setModalIsOpen(true); 
    }
  };

  const districts = [
    "Berea",
    "Butha-Buthe",
    "Leribe",
    "Mafeteng",
    "Maseru",
    "Mohale’s Hoek",
    "Qacha’s Nek",
    "Quthing",
    "Thaba-Tseka",
    "Mokhotlong",
  ];

  return (
    <div className="container">
      <header>
        <h2>Maternal and Child Health Data Entry Form</h2>
        <p className="description">
          Please fill in the data for the following indicators:
        </p>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="form-aligned">
          {Object.entries(formData).map(([key, { date, district, value }]) => (
            <div className="form-group" key={key}>
              <label>{key}:</label>
              <input
                type={key.startsWith("Proportion") ? "number" : "text"}
                step={key.startsWith("Proportion") ? "0.01" : ""}
                name="value"
                value={value}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
                placeholder={`Enter value for ${key}`}
                style={{ display: key.startsWith("Status") ? "none" : "block" }}
              />
              {key.startsWith("Status") && (
                <select
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select Status</option>
                  {["Not Started", "Underway", "Complete"].map(
                    (statusOption) => (
                      <option key={statusOption} value={statusOption}>
                        {statusOption}
                      </option>
                    )
                  )}
                </select>
              )}
              <input
                type="date"
                name="date"
                value={date}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              />
              <select
                name="district"
                value={district}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              >
                <option value="">Select District</option>
                {districts.map((districtName) => (
                  <option key={districtName} value={districtName}>
                    {districtName}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
        <Button type="submit" className="submit-button">
          Submit
        </Button>
      </form>

      {/* Modal for Alerts */}
      <Modal show={modalIsOpen} onHide={() => setModalIsOpen(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Alert</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>{modalMessage}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setModalIsOpen(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default MaternalChildHealthForm;
