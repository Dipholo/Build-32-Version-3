import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css"; // Ensure this is imported
import "./socialProtectionData.css"; 
import axios from "axios";
import { useNavigate } from 'react-router-dom';

const SocialProtectionDataEntryForm = () => {
  const navigate = useNavigate();
  const initialIndicators = {
    "Proportion of pregnant women, nursing mothers, and children have access to health and nutrition services":
      { date: "", district: "", value: "" },
    "Proportion of children from poor and ultra-poor households covered by complementary health and nutrition services":
      { date: "", district: "", value: "" },
    "Proportion of pregnant mothers/mothers of infants from poor and ultra-poor households covered by complementary health and nutrition services":
      { date: "", district: "", value: "" },
    "Proportion of mothers of children 0-6 months of age receiving infant grant who are practicing exclusive breastfeeding":
      { date: "", district: "", value: "" },
    "Proportion of households receiving social assistance who have a moderate to high dietary diversity (minimum is 8% and moderate is 27%, and 66% is high)":
      { date: "", district: "", value: "" },
    "Proportion of learners receiving a nutritious meal, disaggregated by gender (school feeding)":
      { date: "", district: "", value: "" },
    "Expansion rate of social protection programmes in Lesotho": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of identified individuals successfully enrolled into social assistance":
      { date: "", district: "", value: "" },
    "Proportion of beneficiaries eligible for graduation from social assistance":
      { date: "", district: "", value: "" },
    "Existence of multi-sector Task team TORs": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Members of multi-stakeholder task team": {
      date: "",
      district: "",
      value: "",
    },
    "Status of infant grants programme (not started, underway, completed)": {
      date: "",
      district: "",
      value: "",
    },
    "Status of NISSA modules (not started, underway, operational)": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Campaigns held on infant grant sensitization": {
      date: "",
      district: "",
      value: "",
    },
    "Number of People reached through campaigns on infant grant sensitization":
      { date: "", district: "", value: "" },
    "Number of Beneficiaries enrolled into social assistance, by type": {
      date: "",
      district: "",
      value: "",
    },
    "Amount of Cash transfers distributed, by type": {
      date: "",
      district: "",
      value: "",
    },
    "Status of a Nutrition mainstreaming plan (not started, underway, complete)":
      { date: "", district: "", value: "" },
    "Number of TV slots on nutrition education": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Radio slots on nutrition education": {
      date: "",
      district: "",
      value: "",
    },
    "Number of People reached with nutrition education": {
      date: "",
      district: "",
      value: "",
    },
    "Status of Social protection multi-sectoral M&E framework (not started, underway, complete)":
      { date: "", district: "", value: "" },
    "Number of food and spending support visits conducted, by community council":
      { date: "", district: "", value: "" },
    "Number of Community committee members trained on good feeding practices": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Nutrition community committees established": {
      date: "",
      district: "",
      value: "",
    },
    "Status of multi-sectoral information system (not started, underway, complete)":
      { date: "", district: "", value: "" },
    "Number of Pregnant women reached during breastfeeding campaigns": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Mothers of under 2s reached during breastfeeding campaigns": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Stakeholder meetings held on establishing and/or strengthening referral mechanisms":
      { date: "", district: "", value: "" },
    "Number of Stakeholders who attended meetings on establishing and/or strengthening referral mechanisms, by cadre":
      { date: "", district: "", value: "" },
  };

  const [formData, setFormData] = useState(initialIndicators);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  const handleChange = (e, indicator) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [indicator]: {
        ...formData[indicator],
        [name]: value,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const filteredData = Object.entries(formData)
      .filter(([key, { date, district, value }]) => date && district && value)
      .reduce((acc, [key, { date, district, value }]) => {
        acc[key] = { date, district, value };
        return acc;
      }, {});

    if (Object.keys(filteredData).length === 0) {
      setModalMessage("Please fill in data for at least one indicator.");
      setModalIsOpen(true);
      return;
    }

    const requestData = {
      formData: filteredData,
      KRA: "Social Protection", // Add the KRA field here
      Ministry: "Ministry of Gender, Youth, and Social Development",
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-entry/add-indicator-data",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            AuthAuthorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(requestData), // Include the KRA in the request
        }
      );

      const data = await response.json();
      if (data.status === 403) {
     
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem('accessToken', response.data.accessToken);
              sessionStorage.setItem('refreshToken', response.data.refreshToken);
            })
            .catch((error) => {
              alert("Session expired. Please log in again.");
              navigate("/");
            });
        }
      } 

      if (response.ok) {
        setModalMessage("Data added successfully!");
        setModalIsOpen(true);
        setFormData(initialIndicators);
      } else {
        setModalMessage(`Error: ${data.error}`);
        setModalIsOpen(true);
      }
    } catch (error) {
      console.error("Error submitting data:", error);
      setModalMessage("Failed to submit data. Please try again.");
      setModalIsOpen(true);
    }
  };

  const districts = [
    "Berea",
    "Butha-Buthe",
    "Leribe",
    "Mafeteng",
    "Maseru",
    "Mohale’s Hoek",
    "Qacha’s Nek",
    "Quthing",
    "Thaba-Tseka",
    "Mokhotlong",
  ];

  return (
    <div className="container">
      <header>
        <h2>Social Protection Data Entry Form</h2>
        <p className="description">
          Please fill in the data for the following indicators:
        </p>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="form-aligned">
          {Object.entries(formData).map(([key, { date, district, value }]) => (
            <div className="form-group" key={key}>
              <label>
                {key
                  .replace(/([A-Z])/g, " $1")
                  .replace(/^./, (str) => str.toUpperCase())}
                :
              </label>
              <input
                type="date"
                name="date"
                value={date}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              />

              {key.includes("Proportion") ? (
                <input
                  type="number"
                  step="0.01"
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                  placeholder={`Enter value for ${key.toLowerCase()}`}
                />
              ) : key.includes("Number") ? (
                <input
                  type="number"
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                  placeholder={`Enter value for ${key.toLowerCase()}`}
                />
              ) : key.includes("Status") ? (
                <select
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select Status</option>
                  <option value="Not Started">Not Started</option>
                  <option value="Underway">Underway</option>
                  <option value="Complete">Complete</option>
                </select>
              ) : (
                <input
                  type="text"
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                  placeholder={`Enter value for ${key.toLowerCase()}`}
                />
              )}

              <select
                name="district"
                value={district}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              >
                <option value="">Select District</option>
                {districts.map((districtName) => (
                  <option key={districtName} value={districtName}>
                    {districtName}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
        <Button type="submit" className="submit-button">
          Submit
        </Button>
      </form>

      {/* Modal for Alerts */}
      <Modal show={modalIsOpen} onHide={() => setModalIsOpen(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Alert</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>{modalMessage}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setModalIsOpen(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default SocialProtectionDataEntryForm;
