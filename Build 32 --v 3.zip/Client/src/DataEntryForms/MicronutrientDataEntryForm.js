import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css"; 
import "./micronutrient.css";
import axios from "axios";
import { useNavigate } from 'react-router-dom';

const MicronutrientDataEntryForm = () => {
  const navigate = useNavigate();
  const initialIndicators = {
    "Proportion of children under 5 years of age with vitamin A deficiency": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of anaemic children 6-59 months of age": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of iron-deficiency anaemia in women aged 15-49 years of age (by sex)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of households with iodated salt": {
      date: "",
      district: "",
      value: "",
    },
    "Prevalence of iron-deficiency anaemia in children": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of children 6-23 months consuming foods rich in Vitamin A": {
      date: "",
      district: "",
      value: "",
    },
    "Vitamin A coverage in children 6-11 months/Proportion of children 6-11 months of age given Vitamin A supplementation":
      {
        date: "",
        district: "",
        value: "",
      },
    "Vitamin A coverage in children 6-59 months/Proportion of children 6-59 months of age given vitamin A supplementation":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of children 6-23 months of age who receive micro-nutrient powders supplementation in the last 6 months":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of children 6-59 months of age who received 1 iron pill (sometimes sprinkles or syrup) in the past 6 months":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of Children 12-59 months of age who receive 1 deworming treatment (tablets) in the past 6 months":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of women who took iron folate during the most recent pregnancy (everyday of pregnancy and 3 months post-partum)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of children who attend monthly growth monitoring": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Health workers and community members trained on fortification": {
      date: "",
      district: "",
      value: "",
    },
    "Number of health facilities with adequate Micronutrient Powders (MNPs) supplies":
      {
        date: "",
        district: "",
        value: "",
      },
    "Status of pilot study on Micronutrient Powders (MNPs), (not started, underway, complete)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of Lactating mothers and caregivers trained on Micronutrient Powders (MNPs)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of Children who received routine supplementation of vitamin A, iron folate, and deworming tablets":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of Homestead gardens constructed": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Homestead gardens using bio-fortified seeds": {
      date: "",
      district: "",
      value: "",
    },
    "Number of routine food inspection visits": {
      date: "",
      district: "",
      value: "",
    },
    "Status of Legal framework": { date: "", district: "", value: "" },
  };

  const [formData, setFormData] = useState(initialIndicators);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  const handleChange = (e, indicator) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [indicator]: {
        ...formData[indicator],
        [name]: value,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Filter form data to include only those indicators with filled data
    const filteredData = Object.entries(formData)
      .filter(([key, { date, district, value }]) => date && district && value) // Only include filled data
      .reduce((acc, [key, { date, district, value }]) => {
        acc[key] = { date, district, value };
        return acc;
      }, {});

    if (Object.keys(filteredData).length === 0) {
      setModalMessage("Please fill in data for at least one indicator.");
      setModalIsOpen(true); // Open modal
      return;
    }

    const requestData = {
      formData: filteredData,
      KRA: "Micronutrient Supplementation", // Add the KRA field here
      Ministry: "Ministry of Health",
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-entry/add-indicator-data",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(requestData), // Include the KRA in the request
        }
      );

      const data = await response.json();
      if (data.status === 403) {
     
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem('accessToken', response.data.accessToken);
              sessionStorage.setItem('refreshToken', response.data.refreshToken);
            })
            .catch((error) => {
              alert("Session expired. Please log in again.");
              navigate("/");
            });
        }
      } 

      if (response.ok) {
        setModalMessage("Data added successfully!");
        setModalIsOpen(true); // Open modal
        setFormData(initialIndicators); // Reset the form
      } else {
        setModalMessage(`Error: ${data.error}`);
        setModalIsOpen(true); // Open modal
      }
    } catch (error) {
      console.error("Error submitting data:", error);
      setModalMessage("Failed to submit data. Please try again.");
      setModalIsOpen(true); // Open modal
    }
  };

  const districts = [
    "Berea",
    "Butha-Buthe",
    "Leribe",
    "Mafeteng",
    "Maseru",
    "Mohale’s Hoek",
    "Qacha’s Nek",
    "Quthing",
    "Thaba-Tseka",
    "Mokhotlong",
  ];

  return (
    <div className="container">
      <header>
        <h2>Micronutrient Data Entry Form</h2>
        <p className="description">
          Please fill in the data for the following indicators:
        </p>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="form-aligned">
          {Object.entries(formData).map(([key, { date, district, value }]) => (
            <div className="form-group" key={key}>
              <label>{key}:</label>
              <input
                type={key.startsWith("Proportion") ? "number" : "text"}
                step={key.startsWith("Proportion") ? "0.01" : ""}
                name="value"
                value={value}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
                placeholder={`Enter value for ${key}`}
                style={{ display: key.startsWith("Status") ? "none" : "block" }}
              />
              {key.startsWith("Status") && (
                <select
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select Status</option>
                  {["Not started", "Underway", "Complete"].map(
                    (statusOption) => (
                      <option key={statusOption} value={statusOption}>
                        {statusOption}
                      </option>
                    )
                  )}
                </select>
              )}
              <input
                type="date"
                name="date"
                value={date}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              />
              <select
                name="district"
                value={district}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              >
                <option value="">Select District</option>
                {districts.map((districtName) => (
                  <option key={districtName} value={districtName}>
                    {districtName}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
        <Button type="submit" className="submit-button">
          Submit
        </Button>
      </form>

      {/* Modal for Alerts */}
      <Modal show={modalIsOpen} onHide={() => setModalIsOpen(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Alert</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>{modalMessage}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setModalIsOpen(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default MicronutrientDataEntryForm;
