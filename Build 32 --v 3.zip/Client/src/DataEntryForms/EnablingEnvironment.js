import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const EnablingEnronmentDataEntryForm = () => {
  const navigate = useNavigate();
  const initialIndicators = {
    "Proportion of national budget allocated to nutrition": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of funds from donors allocated for food and nutrition programming":
      {
        date: "",
        district: "",
        value: "",
      },
    "Operational status of food and nutrition information in the country and against global standards":
      { date: "", district: "", value: "" },
    "Operational status of food and nutrition legal frameworks, guidelines and standards endorsed by parliament and  cabinet (not started, underway, endorsed)":
      { date: "", district: "", value: "" },
    "Number of  Dialogues held with multi-sectoral stakeholders on nutrition budgeting":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of  Dialogues held with high level authorities (ministers, parlimentarians) on nutrition budgeting":
      { date: "", district: "", value: "" },
    "Number of meetings held with development partners on nutrition mainstreaming and budgeting":
      { date: "", district: "", value: "" },
    "Number of Development partners who participated in meetings on nutrition mainstreaming and budgeting":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of Meetings held with legal practitioners on nutrition mainstreaming":
      {
        date: "",
        district: "",
        value: "",
      },
    "Status of M&E results framework for food and nutrition services (not started, underway, complete)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of  Meetings held by FNCO for nutrition stakeholders": {
      date: "",
      district: "",
      value: "",
    },
    "Status of food and nutrition bill (not started, underway adopted)": {
      date: "",
      district: "",
      value: "",
    },
    "Status of Regulations and standards on food and nutrition standards (not started, underway, complete)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of  Food and nutrition policy reviews held": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Participants who participated in the food and nutrition policy reviews, by cadre":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of  Curriculum reviews": {
      date: "",
      district: "",
      value: "",
    },
    "Existence of Terms of reference (TORs) for overseeing bodies (committees, society)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of  Members of the surveillance team": {
      date: "",
      district: "",
      value: "",
    },
    "Number of food and nutrition surveillance results/findings dissemination meetings held":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of  Nutrition research papers published/ case studies": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  People trained on the surveillance system": {
      date: "",
      district: "",
      value: "",
    },
    "Status of SUN system in (active, inactive)": {
      date: "",
      district: "",
      value: "",
    },
  };

  const [formData, setFormData] = useState(initialIndicators);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  const handleChange = (e, indicator) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [indicator]: {
        ...formData[indicator],
        [name]: value,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Filter form data to include only those indicators with filled data
    const filteredData = Object.entries(formData)
      .filter(
        ([key, { date, district, value }]) =>
          date && district && (value || key.startsWith("Status"))
      )
      .reduce((acc, [key, { date, district, value }]) => {
        acc[key] = { date, district, value };
        return acc;
      }, {});

    if (Object.keys(filteredData).length === 0) {
      setModalMessage("Please fill in data for at least one indicator.");
      setModalIsOpen(true); // Open modal
      return;
    }

    const requestData = {
      formData: filteredData,
      KRA: "Enabling Environment", // Add the KRA field here
      Ministry: "FNCO",
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-entry/add-indicator-data",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(requestData), 
        }
      );

      const data = await response.json();
      if (data.status === 403) {
     
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem('accessToken', response.data.accessToken);
              sessionStorage.setItem('refreshToken', response.data.refreshToken);
            })
            .catch((error) => {
              alert("Session expired. Please log in again.");
              navigate("/");
            });
        }
      }

      if (response.ok) {
        setModalMessage("Data added successfully!");
        setModalIsOpen(true); // Open modal
        setFormData(initialIndicators); // Reset the form
      } else {
        setModalMessage(`Error: ${data.error}`);
        setModalIsOpen(true); // Open modal
      }
    } catch (error) {
      console.error("Error submitting data:", error);
      setModalMessage("Failed to submit data. Please try again.");
      setModalIsOpen(true); // Open modal
    }
  };

  const districts = [
    "Berea",
    "Butha-Buthe",
    "Leribe",
    "Mafeteng",
    "Maseru",
    "Mohale’s Hoek",
    "Qacha’s Nek",
    "Quthing",
    "Thaba-Tseka",
    "Mokhotlong",
  ];

  return (
    <div className="container">
      <header>
        <h2>Enabling Environment Data Entry Form</h2>
        <p className="description">
          Please fill in the data for the following indicators:
        </p>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="form-aligned">
          {Object.entries(formData).map(([key, { date, district, value }]) => (
            <div className="form-group" key={key}>
              <label>{key}:</label>
              <input
                type={
                  key.startsWith("Proportion")
                    ? "number"
                    : key.startsWith("Number")
                    ? "text"
                    : null
                }
                step={key.startsWith("Proportion") ? "0.01" : ""}
                name="value"
                value={value}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
                placeholder={`Enter value for ${key}`}
                style={{ display: key.startsWith("Status") ? "none" : "block" }}
              />
              {key.startsWith("Status") && (
                <select
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select Status</option>
                  {["Not started", "Underway", "Complete"].map(
                    (statusOption) => (
                      <option key={statusOption} value={statusOption}>
                        {statusOption}
                      </option>
                    )
                  )}
                </select>
              )}

              {key.startsWith("Operational status") && (
                <select
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select Status</option>
                  {["Not started", "Underway", "Endorsed"].map(
                    (statusOption) => (
                      <option key={statusOption} value={statusOption}>
                        {statusOption}
                      </option>
                    )
                  )}
                </select>
              )}

              <input
                type="date"
                name="date"
                value={date}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              />
              <select
                name="district"
                value={district}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              >
                <option value="">Select District</option>
                {districts.map((districtName) => (
                  <option key={districtName} value={districtName}>
                    {districtName}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
        <Button type="submit" className="submit-button">
          Submit
        </Button>
      </form>

      {/* Modal for Alerts */}
      <Modal show={modalIsOpen} onHide={() => setModalIsOpen(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Alert</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>{modalMessage}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setModalIsOpen(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default EnablingEnronmentDataEntryForm;
