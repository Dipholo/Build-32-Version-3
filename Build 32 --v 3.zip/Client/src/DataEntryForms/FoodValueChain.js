import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import "./iycf.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const FoodValueChainDataEntryForm = () => {
  const navigate = useNavigate();
  const initialIndicators = {
    "Proportion of the population that is food insecure": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of the population consuming foods rich in iron, zinc, and Vitamin A":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of the population living under the national poverty line": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of households with a moderate to high dietary diversity (low is 8% and moderate is 27% and high is 66%)":
      { date: "", district: "", value: "" },
    "Post-harvest loss rate for staple crops": {
      date: "",
      district: "",
      value: "",
    },
    "National cereal food deficit": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of farmers using organic farming methods": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion children 6-23 months of age who consumed foods and beverages from at least 5 out of 10 defined food groups during the previous day":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of households consuming biofortified food products": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of households with diversified homestead production (productive fruit tree, productive vegetable plots and short-cycled animals)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of households using post-harvest technologies (food preservations strategies)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of households using climate smart agriculture": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion Households using advanced storage technologies": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Farmers sensitised on bio-fortified seeds use": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Indigenous species identified for use, by type": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Trained participants on dietary diversity (disaggregated by cadre)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Number of  Partnerships formed (disaggregated by entity)": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Individuals trained on climate smart agriculture approaches": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Households/individuals who received small livestock breeds": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Farmers trained on animal husbandry practices": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Veterinary staff trained": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Community participants reached with nutrition education": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Nutrition education activities conducted": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Farmers who received post-harvest storage  technology items": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Vegetable market stores constructed": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Smallholder farmer initiatives commercialized": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Local products substituting imports, by type": {
      date: "",
      district: "",
      value: "",
    },
    "Number of  Individuals capacitated to undertake businesses of cottage industries (disaggregated by gender)":
      {
        date: "",
        district: "",
        value: "",
      },
  };

  const [formData, setFormData] = useState(initialIndicators);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  const handleChange = (e, indicator) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [indicator]: {
        ...formData[indicator],
        [name]: value,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Filter form data to include only those indicators with filled data
    const filteredData = Object.entries(formData)
      .filter(
        ([key, { date, district, value }]) =>
          date && district && (value || key.startsWith("Status"))
      )
      .reduce((acc, [key, { date, district, value }]) => {
        acc[key] = { date, district, value };
        return acc;
      }, {});

    if (Object.keys(filteredData).length === 0) {
      setModalMessage("Please fill in data for at least one indicator.");
      setModalIsOpen(true); // Open modal
      return;
    }

    const requestData = {
      formData: filteredData,
      KRA: "Food Value Chain", // Add the KRA field here
      Ministry: "Ministry of Agriculture, Food Security and Nutrition",
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-entry/add-indicator-data",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(requestData),
        }
      );

      const data = await response.json();
      if (data.status === 403) {
     
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem('accessToken', response.data.accessToken);
              sessionStorage.setItem('refreshToken', response.data.refreshToken);
            })
            .catch((error) => {
              alert("Session expired. Please log in again.");
              navigate("/");
            });
        }
      }

      if (response.ok) {
        setModalMessage("Data added successfully!");
        setModalIsOpen(true); // Open modal
        setFormData(initialIndicators); // Reset the form
      } else {
        setModalMessage(`Error: ${data.error}`);
        setModalIsOpen(true); // Open modal
      }
    } catch (error) {
      console.error("Error submitting data:", error);
      setModalMessage("Failed to submit data. Please try again.");
      setModalIsOpen(true); // Open modal
    }
  };

  const districts = [
    "Berea",
    "Butha-Buthe",
    "Leribe",
    "Mafeteng",
    "Maseru",
    "Mohale’s Hoek",
    "Qacha’s Nek",
    "Quthing",
    "Thaba-Tseka",
    "Mokhotlong",
  ];

  return (
    <div className="container">
      <header>
        <h2>Food Value Chain Data Entry Form</h2>
        <p className="description">
          Please fill in the data for the following indicators:
        </p>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="form-aligned">
          {Object.entries(formData).map(([key, { date, district, value }]) => (
            <div className="form-group" key={key}>
              <label>{key}:</label>
              <input
                type={
                  key.startsWith("Proportion")
                    ? "number"
                    : key.startsWith("Number")
                    ? "text"
                    : null
                }
                step={key.startsWith("Proportion") ? "0.01" : ""}
                name="value"
                value={value}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
                placeholder={`Enter value for ${key}`}
                style={{ display: key.startsWith("Status") ? "none" : "block" }}
              />
              {key.startsWith("Status") && (
                <select
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select Status</option>
                  {["Not started", "Underway", "Complete"].map(
                    (statusOption) => (
                      <option key={statusOption} value={statusOption}>
                        {statusOption}
                      </option>
                    )
                  )}
                </select>
              )}

              {key.startsWith("Operational status") && (
                <select
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select Status</option>
                  {["Not started", "Underway", "Endorsed"].map(
                    (statusOption) => (
                      <option key={statusOption} value={statusOption}>
                        {statusOption}
                      </option>
                    )
                  )}
                </select>
              )}

              <input
                type="date"
                name="date"
                value={date}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              />
              <select
                name="district"
                value={district}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              >
                <option value="">Select District</option>
                {districts.map((districtName) => (
                  <option key={districtName} value={districtName}>
                    {districtName}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
        <Button type="submit" className="submit-button">
          Submit
        </Button>
      </form>

      {/* Modal for Alerts */}
      <Modal show={modalIsOpen} onHide={() => setModalIsOpen(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Alert</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>{modalMessage}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setModalIsOpen(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default FoodValueChainDataEntryForm;
