import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css"; // Ensure this is imported
import "./washData.css"; 
import axios from "axios";
import { useNavigate } from 'react-router-dom';

const WASHDataEntryForm = () => {

  const navigate = useNavigate();
  const initialIndicators = {
    "Proportion of the population with access to improved source of drinking water, disaggregated by geographic location":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of households with access to basic hygiene services (water and soap present and available)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of the population with access to an improved sanitation facility":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of children under 5 that had diarrhoea in the 2 weeks preceding the survey who received ORS/treatment":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of households with access to basic hygiene services (water and soap present and available)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of adolescents who practice good hygiene behavior, by sex": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of schools with basic water and sanitation services": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of schools with inclusive sanitation facilities (learners with special needs)":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of schools with adequate menstrual hygiene facilities in place":
      {
        date: "",
        district: "",
        value: "",
      },
    "Proportion of schools with access to a basic drinking water source": {
      date: "",
      district: "",
      value: "",
    },
    "Proportion of schools with access to a basic handwashing facility": {
      date: "",
      district: "",
      value: "",
    },
    "Number of People Reached with Messaging on WaterStorage and treatment": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Handwashing Facilities Constructed, by geographic setting": {
      date: "",
      district: "",
      value: "",
    },
    "Number of People Reached on Menstrual on Health Messaging (MHM)": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Female Learners Provided with MHM Materials in schools": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Water Systems Constructed": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Sanitation Facilities Constructed": {
      date: "",
      district: "",
      value: "",
    },
  };

  const [formData, setFormData] = useState(initialIndicators);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  const handleChange = (e, indicator) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [indicator]: {
        ...formData[indicator],
        [name]: value,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Filter form data to include only those indicators with filled data
    const filteredData = Object.entries(formData)
      .filter(([key, { date, district, value }]) => date && district && value) // Only include filled data
      .reduce((acc, [key, { date, district, value }]) => {
        acc[key] = { date, district, value };
        return acc;
      }, {});

    if (Object.keys(filteredData).length === 0) {
      setModalMessage("Please fill in data for at least one indicator.");
      setModalIsOpen(true); // Open modal
      return;
    }

    const requestData = {
      formData: filteredData,
      KRA: "WASH", // Add the KRA field here
      Ministry: "Ministry of Water and Environment",
    };

   


    try {
      const response = await fetch(
        "http://localhost:1024/api/data-entry/add-indicator-data",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(requestData),
        }
      );

      const data = await response.json();
     
      if (data.status === 403) {
     
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem('accessToken', response.data.accessToken);
              sessionStorage.setItem('refreshToken', response.data.refreshToken);
            })
            .catch((error) => {
              alert("Session expired. Please log in again.");
              navigate("/");
            });
        }
      } 
      
      if (response.ok) {
        setModalMessage("Data added successfully!");
        setModalIsOpen(true); // Open modal
        setFormData(initialIndicators); // Reset the form
      } else {
        setModalMessage(`Error: ${data.error}`);
        setModalIsOpen(true); // Open modal
      }
    } catch (error) {
      
      console.log('executed')
      console.error("Error submitting data:", error);
      setModalMessage("Failed to submit data. Please try again.");
      setModalIsOpen(true); // Open modal
    }
  };

  const districts = [
    "Berea",
    "Butha-Buthe",
    "Leribe",
    "Mafeteng",
    "Maseru",
    "Mohale’s Hoek",
    "Qacha’s Nek",
    "Quthing",
    "Thaba-Tseka",
    "Mokhotlong",
  ];

  return (
    <div className="container">
      <header>
        <h2>WASH Data Entry Form</h2>
        <p className="description">
          Please fill in the data for the following indicators:
        </p>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="form-aligned">
          {Object.entries(formData).map(([key, { date, district, value }]) => (
            <div className="form-group" key={key}>
              <label>
                {key
                  .replace(/([A-Z])/g, " $1")
                  .replace(/^./, (str) => str.toUpperCase())}
                :
              </label>
              <input
                type="date"
                name="date"
                value={date}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              />
              <input
                type={key.startsWith("proportion") ? "number" : "text"}
                step={key.startsWith("proportion") ? "0.01" : ""}
                name="value"
                value={value}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
                placeholder={`Enter value for ${key
                  .replace(/([A-Z])/g, " $1")
                  .toLowerCase()}`}
              />
              <select
                name="district"
                value={district}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              >
                <option value="">Select District</option>
                {districts.map((districtName) => (
                  <option key={districtName} value={districtName}>
                    {districtName}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
        <Button type="submit" className="submit-button">
          Submit
        </Button>
      </form>

      {/* Modal for Alerts */}
      <Modal show={modalIsOpen} onHide={() => setModalIsOpen(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Alert</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>{modalMessage}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setModalIsOpen(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default WASHDataEntryForm;
