import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css"; 
import "./genderEqualityData.css"; 
import axios from "axios";
import { useNavigate } from "react-router-dom";

const GenderEqualityDataEntryForm = () => {
  const navigate = useNavigate();
  
  const initialIndicators = {
    "Proportion of teen females married before the age of 18 years": {
      date: "",
      district: "",
      value: "",
      gender: "Female",
    },
    "Proportion of women who were married before the age of 18 years": {
      date: "",
      district: "",
      value: "",
      gender: "Female",
    },
    "Proportion of mothers and caregivers of children 0-23 months whose spouses are involved in optimal child feeding":
      { date: "", district: "", value: "" },
    "Proportion of mothers and caregivers of children 0-23 months whose spouses are involved in hygiene":
      { date: "", district: "", value: "" },
    "Proportion of mothers and caregivers of children 0-23 months whose spouses are involved in health care":
      { date: "", district: "", value: "" },
    "Proportion of women of child-bearing age and caregivers of under fives with access to appropriate labour-saving technologies for food production, processing, preservation, and preparation":
      { date: "", district: "", value: "", gender: "" },
    "Proportion of women who participate in their own decisions on their own healthcare, major household purchases and visits to family or relatives":
      { date: "", district: "", value: "", gender: "" },
    "Number of Public gatherings held on the importance of sharing responsibilities":
      { date: "", district: "", value: "" },
    "Number of IEC/BCC materials developed and translated on sharing responsibilities":
      { date: "", district: "", value: "" },
    "Number of IEC/BCC materials printed and distributed in communities on sharing responsibilities":
      { date: "", district: "", value: "" },
    "Number of People reached who received IEC/BCC materials on sharing responsibilities":
      { date: "", district: "", value: "" },
    "Number of Life skills trainings held for women": {
      date: "",
      district: "",
      value: "",
      gender: "Female",
    },
    "Number of Women trained on life skills": {
      date: "",
      district: "",
      value: "",
      gender: "Female",
    },
    "Number of individuals who received IYCF manuals (fathers, grandmothers, and mothers-in-law)":
      { date: "", district: "", value: "" },
    "Number of Individuals trained on the usage of the father support manual": {
      date: "",
      district: "",
      value: "",
    },
    "Number of IYCF father-led groups established": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Forums held on the importance of male involvement in child care":
      { date: "", district: "", value: "" },
    "Number of Participants reached through forums on male involvement in child care":
      { date: "", district: "", value: "" },
    "Number of Male champions selected": {
      date: "",
      district: "",
      value: "",
      gender: "Male",
    },
    "Number of Fun walks held": { date: "", district: "", value: "" },
    "Number of Participants who attended the fun walk": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Public gatherings held on labour-saving technologies": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Women reached during the public gatherings": {
      date: "",
      district: "",
      value: "",
      gender: "Female",
    },
    "Number of Artisans trained on labour-saving technologies": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Labour-saving technologies developed": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Water systems installed for household and home farming, by geographic setting":
      { date: "", district: "", value: "" },
    "Number of Dialogues held on ANC, PNC, PMTCT attendance by couples": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Participants who attended dialogues on ANC, PNC, and PMTCT attendance by couples, by cadre":
      { date: "", district: "", value: "" },
    "Status of compulsory ANC, PNC, and PMTCT couple attendance ‘standard/practice’ (not started, underway, complete)":
      { date: "", district: "", value: "" },
    "Number of Women of child-bearing age (15-49 years) who received IEC materials on female empowerment strategies":
      { date: "", district: "", value: "", gender: "Female" },
  };

  const [formData, setFormData] = useState(initialIndicators);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  const handleChange = (e, indicator) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [indicator]: {
        ...formData[indicator],
        [name]: value,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const filteredData = Object.entries(formData)
      .filter(([key, { date, district, value }]) => date && district && value)
      .reduce((acc, [key, { date, district, value }]) => {
        acc[key] = { date, district, value };
        return acc;
      }, {});

    if (Object.keys(filteredData).length === 0) {
      setModalMessage("Please fill in data for at least one indicator.");
      setModalIsOpen(true);
      return;
    }

    const requestData = {
      formData: filteredData,
      KRA: "Gender Equality and Female Empowerment", 
      Ministry: "Ministry of Gender, Youth, and Social Development",
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-entry/add-indicator-data",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(requestData), 
        }
      );

      const data = await response.json();
      if (data.status === 403) {
     
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem('accessToken', response.data.accessToken);
              sessionStorage.setItem('refreshToken', response.data.refreshToken);
            })
            .catch((error) => {
              alert("Session expired. Please log in again.");
              navigate("/");
            });
        }
      }

      if (response.ok) {
        setModalMessage("Data added successfully!");
        setModalIsOpen(true);
        setFormData(initialIndicators);
      } else {
        setModalMessage(`Error: ${data.error}`);
        setModalIsOpen(true);
      }
    } catch (error) {
      console.error("Error submitting data:", error);
      setModalMessage("Failed to submit data. Please try again.");
      setModalIsOpen(true);
    }
  };

  const districts = [
    "Berea",
    "Butha-Buthe",
    "Leribe",
    "Mafeteng",
    "Maseru",
    "Mohale’s Hoek",
    "Qacha’s Nek",
    "Quthing",
    "Thaba-Tseka",
    "Mokhotlong",
  ];

  return (
    <div className="container">
      <header>
        <h2>Gender Equality and Female Empowerment Data Entry Form</h2>
        <p className="description">
          Please fill in the data for the following indicators:
        </p>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="form-aligned">
          {Object.entries(formData).map(([key, { date, district, value }]) => {
            let inputElement = null;

            // Determine input type based on the indicator's key
            if (key.toLowerCase().includes("proportion")) {
              inputElement = (
                <input
                  type="number"
                  step="0.01"
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                  placeholder={`Enter value for ${key.toLowerCase()}`}
                />
              );
            } else if (key.toLowerCase().includes("number")) {
              inputElement = (
                <input
                  type="number"
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                  placeholder={`Enter value for ${key.toLowerCase()}`}
                />
              );
            } else if (key.toLowerCase().includes("status")) {
              inputElement = (
                <select
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select Status</option>
                  <option value="Not Started">Not Started</option>
                  <option value="Underway">Underway</option>
                  <option value="Complete">Complete</option>
                </select>
              );
            } else {
              inputElement = (
                <input
                  type="text"
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                  placeholder={`Enter value for ${key.toLowerCase()}`}
                />
              );
            }

            return (
              <div className="form-group" key={key}>
                <label>
                  {key
                    .replace(/([A-Z])/g, " $1")
                    .replace(/^./, (str) => str.toUpperCase())}
                  :
                </label>
                <input
                  type="date"
                  name="date"
                  value={date}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                />
                {inputElement}
                <select
                  name="district"
                  value={district}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select District</option>
                  {districts.map((districtName) => (
                    <option key={districtName} value={districtName}>
                      {districtName}
                    </option>
                  ))}
                </select>
              </div>
            );
          })}
        </div>
        <Button type="submit" className="submit-button">
          Submit
        </Button>
      </form>

      {/* Modal for Alerts */}
      <Modal show={modalIsOpen} onHide={() => setModalIsOpen(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Alert</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>{modalMessage}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setModalIsOpen(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default GenderEqualityDataEntryForm;
