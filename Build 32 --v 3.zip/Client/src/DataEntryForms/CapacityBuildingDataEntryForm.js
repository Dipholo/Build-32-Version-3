import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const CapacityBuildingDataEntryForm = () => {
  const navigate = useNavigate();
  
  const initialIndicators = {
    "Operational status food and nutrition coordinating framework implemented at community, district and national levels":
      { date: "", district: "", value: "" },
    "Operational status of the Lesotho Food and nutrition society": {
      date: "",
      district: "",
      value: "",
    },
    "Percentage Sectors with nutrition integrated into the sector plans and being implemented":
      { date: "", district: "", value: "" },
    "Percentage Partners with improved capacity to implement food and nutrition interventions":
      { date: "", district: "", value: "" },
    "Number of Nutritionists reached with in-service training": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Programme support staff (including field cadre) who are involved in nutrition service delivery and completed basic nutrition in-service training (TOTs, short courses, or external consultant-led trainings)":
      { date: "", district: "", value: "" },
    "Status of Stakeholder mapping analysis (not started, underway, complete)":
      { date: "", district: "", value: "" },
    "Status of National advocacy plan (not started, underway, complete)": {
      date: "",
      district: "",
      value: "",
    },
    "Number of food and nutrition Legal frameworks produced and approved": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Sector policies revised to mainstream nutrition": {
      date: "",
      district: "",
      value: "",
    },
    "Number of Nutrition coordination meetings (with reports on progress made in implementation and resolutions)":
      { date: "", district: "", value: "" },
    "Number of SUN networks established": { date: "", district: "", value: "" },
    "Number of Sun focal point meetings held per year": {
      date: "",
      district: "",
      value: "",
    },
  };

  const [formData, setFormData] = useState(initialIndicators);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  const handleChange = (e, indicator) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [indicator]: {
        ...formData[indicator],
        [name]: value,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Filter form data to include only those indicators with filled data
    const filteredData = Object.entries(formData)
      .filter(
        ([key, { date, district, value }]) =>
          date && district && (value || key.startsWith("Status"))
      )
      .reduce((acc, [key, { date, district, value }]) => {
        acc[key] = { date, district, value };
        return acc;
      }, {});

    if (Object.keys(filteredData).length === 0) {
      setModalMessage("Please fill in data for at least one indicator.");
      setModalIsOpen(true); // Open modal
      return;
    }

    const requestData = {
      formData: filteredData,
      KRA: "Capacity Building", // Add the KRA field here
      Ministry: "FNCO",
    };

    try {
      const response = await fetch(
        "http://localhost:1024/api/data-entry/add-indicator-data",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionStorage.getItem("accessToken")}`,
          },
          body: JSON.stringify(requestData),
        }
      );

      const data = await response.json();
      if (data.status === 403) {
     
        try {
          const refreshResponse = await axios.post(
            "http://localhost:1024/users/token",
            {
              refreshToken: sessionStorage.getItem("refreshToken"),
            }
          );

          const newAccessToken = refreshResponse.data.accessToken;
          sessionStorage.setItem("accessToken", newAccessToken);
        } catch (refreshError) {
          console.error(
            "Error during token refresh:",
            refreshError.response?.data || refreshError.message
          );

          alert("Session expired. Please log in again.");

          const refreshToken = sessionStorage.getItem("refreshToken");

          axios
            .post("http://localhost:1024/users/token", { refreshToken })
            .then((response) => {
              sessionStorage.setItem('accessToken', response.data.accessToken);
              sessionStorage.setItem('refreshToken', response.data.refreshToken);
            })
            .catch((error) => {
              alert("Session expired. Please log in again.");
              navigate("/");
            });
        }
      }

      if (response.ok) {
        setModalMessage("Data added successfully!");
        setModalIsOpen(true); // Open modal
        setFormData(initialIndicators); // Reset the form
      } else {
        setModalMessage(`Error: ${data.error}`);
        setModalIsOpen(true); // Open modal
      }
    } catch (error) {
      console.error("Error submitting data:", error);
      setModalMessage("Failed to submit data. Please try again.");
      setModalIsOpen(true); // Open modal
    }
  };

  const districts = [
    "Berea",
    "Butha-Buthe",
    "Leribe",
    "Mafeteng",
    "Maseru",
    "Mohale’s Hoek",
    "Qacha’s Nek",
    "Quthing",
    "Thaba-Tseka",
    "Mokhotlong",
  ];

  return (
    <div className="container">
      <header>
        <h2>Capacity Building Data Entry Form</h2>
        <p className="description">
          Please fill in the data for the following indicators:
        </p>
      </header>

      <form onSubmit={handleSubmit}>
        <div className="form-aligned">
          {Object.entries(formData).map(([key, { date, district, value }]) => (
            <div className="form-group" key={key}>
              <label>{key}:</label>
              <input
                type={
                  key.startsWith("Proportion")
                    ? "number"
                    : key.startsWith("Number")
                    ? "text"
                    : null
                }
                step={key.startsWith("Proportion") ? "0.01" : ""}
                name="value"
                value={value}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
                placeholder={`Enter value for ${key}`}
                style={{ display: key.startsWith("Status") ? "none" : "block" }}
              />
              {key.startsWith("Status") && (
                <select
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select Status</option>
                  {["Not started", "Underway", "Complete"].map(
                    (statusOption) => (
                      <option key={statusOption} value={statusOption}>
                        {statusOption}
                      </option>
                    )
                  )}
                </select>
              )}

              {key.startsWith("Operational status") && (
                <select
                  name="value"
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                  className="underline-input"
                >
                  <option value="">Select Status</option>
                  {["Not started", "Underway", "Endorsed"].map(
                    (statusOption) => (
                      <option key={statusOption} value={statusOption}>
                        {statusOption}
                      </option>
                    )
                  )}
                </select>
              )}

              <input
                type="date"
                name="date"
                value={date}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              />
              <select
                name="district"
                value={district}
                onChange={(e) => handleChange(e, key)}
                className="underline-input"
              >
                <option value="">Select District</option>
                {districts.map((districtName) => (
                  <option key={districtName} value={districtName}>
                    {districtName}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
        <Button type="submit" className="submit-button">
          Submit
        </Button>
      </form>

      {/* Modal for Alerts */}
      <Modal show={modalIsOpen} onHide={() => setModalIsOpen(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Alert</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>{modalMessage}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setModalIsOpen(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default CapacityBuildingDataEntryForm;
