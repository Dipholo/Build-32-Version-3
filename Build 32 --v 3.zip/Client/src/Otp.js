import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Form, Button, Container, Row, Col, InputGroup, FormControl } from 'react-bootstrap';
import './Login.css';
import { MdEmail } from "react-icons/md";
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';

function Otp() {
  const location = useLocation();
  const navigate = useNavigate();

  // Retrieve email from React Router state
  const email = location.state?.email || 'unknown@example.com';

  const [otp, setOtp] = useState('');
  const [otpMsg, setOtpMsg] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();

    if (!otp || !email) {
      setOtpMsg('OTP and email are required.');
      return;
    }

    console.log('Submitting:', { otp, email });

    axios.post('http://localhost:1024/users/validate-otp', { otp, email })
      .then(response => {
        if (response.data.status) {
          sessionStorage.setItem('accessToken', response.data.accessToken);
          sessionStorage.setItem('refreshToken', response.data.refreshToken);
          console.log(`Access => ${sessionStorage.getItem('accessToken')}\n Ref => ${sessionStorage.getItem('refreshToken')}`);
          navigate('/dashboard');
          setOtpMsg(response.data.message);
        } else {
          setOtpMsg(response.data.message || 'Login failed.');
        }
      })
      .catch(error => {
        console.error('Error during login:', error.response?.data || error.message);
        setOtpMsg(error.response?.data?.message || 'An error occurred. Please try again.');
      });
  };

  return (
    <div className="login-background">
      <Container className="login-container">
        <Row className="form-container">
          <Col md={4} className="form">
            <h2 className="form-title">
              Food and Nutrition <span style={{ color: "#6c757d", fontSize: "22px", fontWeight: "450" }}>M&E</span>
            </h2>
            <Form>
              <Form.Group controlId="formBasicOtp">
                <InputGroup className="mb-3" style={{width: '24vw'}} >
                  <InputGroup.Text id="basic-addon1">
                    <MdEmail color='#6c757d' />
                  </InputGroup.Text>
                  <FormControl
                    type="text"
                    placeholder="Enter OTP"
                    aria-describedby="basic-addon1"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    className='login-inputs'
                  />
                </InputGroup>
              </Form.Group>
              <span>{`OTP has been sent to this email address ${email}`}</span><br></br> 
              
              <Button variant="success" type="submit"  style={{width: '24vw'}} onClick={handleLogin}> 
                Log In
              </Button>
              {otpMsg && <span className="text-danger mt-2 d-block">{otpMsg}</span>}
            </Form>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default Otp;
