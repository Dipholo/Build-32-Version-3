import React from "react";
import "./Dashboard.css";

const StatCard = ({ statName, title, subtitle, value, progress, progressColor, isSelected, onClick }) => (
  <div
    className={`stat-card ${isSelected ? `selected-card ${statName}-border` : ""}`}
    onClick={() => onClick(statName)}
  >
    <div className="stat-card-title">
      <h6>{title}</h6>
      <p1>{subtitle}</p1>
    </div>
    <h3>{value}%</h3>
    <p>{progress}% higher than last month</p>
    <div className="progress progress-sm">
      <div
        className={`progress-bar ${statName}`}
        style={{ width: `${progress}%`, backgroundColor: progressColor }}
      ></div>
    </div>
  </div>
);

export default StatCard;
