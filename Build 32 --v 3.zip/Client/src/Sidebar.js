import React from "react";
import { FiToggleLeft } from "react-icons/fi";
import "./Sidebar.css";
import { VscCompassActive } from "react-icons/vsc";
import { MdOutlineDashboardCustomize, MdDataExploration } from "react-icons/md";
import {
  TbTemplate,
  TbReport,
  TbProgressHelp,
  TbMessageChatbot,
} from "react-icons/tb";
import { BsDatabaseAdd } from "react-icons/bs";
import { useNavigate, useLocation } from "react-router-dom";
import { FcCollect } from "react-icons/fc";
import { FaUserCog } from "react-icons/fa";
import { CgDanger } from "react-icons/cg";
import { HiOutlineClipboardDocumentList } from "react-icons/hi2";

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavigation = (path) => {
    navigate(path);
  };

  const isActiveLink = (path) => location.pathname === path;

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <span className="sidebar-title">
          National National Food and Nutrition M&E
        </span>
        <button className="toggle-btn">
          <FiToggleLeft size={22} />
        </button>
      </div>

      <div className="sidebar-nav-section">
        <h5 className="sidebar-heading">Navigation</h5>

        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/dashboard") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/dashboard")}
        >
          <MdOutlineDashboardCustomize /> Dashboard
        </a>
        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/documents") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/documents")}
        >
          <TbTemplate /> Documents & Templates
        </a>

        <h5 className="sidebar-heading">Tools</h5>
        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/dataentry") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/dataentry")}
        >
          <BsDatabaseAdd /> Data Entry
        </a>
        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/tools") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/tools")}
        >
          <FcCollect /> Collection Tools
        </a>
        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/datavisualizer") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/datavisualizer")}
        >
          <MdDataExploration /> Data Visualization
        </a>
        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/users") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/users")}
        >
          <FaUserCog /> User Management
        </a>
        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/reports") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/reports")}
        >
          <TbReport /> Reports
        </a>

        <h5 className="sidebar-heading">Critical Alerts</h5>
        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/problems") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/problems")}
        >
          <CgDanger /> Problem Areas
        </a>

        <h5 className="sidebar-heading">Support</h5>
        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/documentation") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/documentation")}
        >
          <HiOutlineClipboardDocumentList /> Documentation
        </a>
        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/help") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/help")}
        >
          <TbProgressHelp /> Help & Support
        </a>
        <a
          href="#"
          className={`sidebar-nav-link ${
            isActiveLink("/chatbot") ? "active-link" : ""
          }`}
          onClick={() => handleNavigation("/chatbot")}
        >
          <TbMessageChatbot /> Chatbot
        </a>
      </div>
    </div>
  );
};

export default Sidebar;
