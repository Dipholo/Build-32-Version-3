import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Form, Button, Container, Row, Col, InputGroup, FormControl } from 'react-bootstrap';
import './Login.css';
import { MdEmail } from "react-icons/md";
import { FaLock } from "react-icons/fa";
import { AiFillEye, AiFillEyeInvisible } from "react-icons/ai"; 
import { useNavigate } from 'react-router-dom';
import axios from 'axios';


function Login({getEmailCallback}) {

  const [email, setEmail] = useState('');
  const [error, setError] = useState({ email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false); 
  const [otpMsg, setOtpMsg] = useState('');

  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    let valid = true;
    let errorMsg = { email: ''};

    if (email === '') {
      valid = false;
      errorMsg.email = 'Email is required';
    }

    if (!valid) {
      setError(errorMsg);
    } else {
      setError({ email: ''});
    }

    axios.post('http://localhost:1024/users/login', { email })
    .then(response => {
        setOtpMsg(response.data.message);
        if(response.data.status){
          getEmailCallback(email);
          navigate('/otp', { state: { email } });
        }
    })
    .catch(error => {
        console.error('Error during login:', error.response?.data || error.message);
        // Handle errors (e.g., show error messages)
    });

  };

  return (
    <div className="login-background">
      <Container className="login-container">
        <Row className="form-container" >
          <Col md={4} className="form">
            <h2 className="form-title">Food and Nutrition <span style={{color: "#6c757d", fontSize: "22px", fontWeight: "450"}}>M&E</span></h2>
            <Form>
              <Form.Group controlId="formBasicEmail">
                <InputGroup className="mb-3"  style={{width: '24vw'}}>
                  <InputGroup.Text id="basic-addon1">
                    <MdEmail color='#6c757d'/>
                  </InputGroup.Text>
                  <FormControl
                    type="email"
                    placeholder="Email"
                    aria-label="Email"
                    aria-describedby="basic-addon1"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className='login-inputs'
                  />
                </InputGroup>
                {error.email && <p className="email-error-message">{error.email}</p>}
              </Form.Group>

              <span>{otpMsg}</span>

              <Button variant="success" type="submit"  style={{width: '24vw'}} onClick={handleLogin} >
                Request OTP
              </Button>
            </Form>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default Login;
