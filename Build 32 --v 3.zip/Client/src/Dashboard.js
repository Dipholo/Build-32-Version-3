import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  Button,
  InputGroup,
  FormControl,
  Dropdown,
  DropdownButton,
  ListGroup,
  Form,
  FormCheck,
  Table,
} from "react-bootstrap";
import { AiOutlinePlus, AiOutlineMinus } from "react-icons/ai";
import { MdOutlineSaveAlt } from "react-icons/md";
import { RiAiGenerate } from "react-icons/ri";
import "./Dashboard.css";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import Footer from "./Footer";
import MapVisualizer from "./Maps/MapVisualizer";
import StatCard from "./StatCard";

const cardLabels = {
  stunting: "Prevalence of stunting in children under 5 years of age",
  wasting: "Prevalence of wasting in children under 5 years of age",
  underweight: "Prevalence of underweight in children under 5 years of age",
  overweight:
    "Proportion of children under 5 years of age who are overweight/obese",
};

const Locations = [
  "Butha-Buthe",
  "Berea",
  "Leribe",
  "Maseru",
  "Mafeteng",
  "Mohales Hoek",
  "Quthing",
  "Qachas Nek",
  "Mokhotlong",
  "Thaba-Tseka",
];
const Time = [
  "2017",
  "2018",
  "2019",
  "2020",
  "2021",
  "2022",
  "2023",
  "2024",
  "Last Month",
  "Last Quarter",
];
const Ministries = [
  "Ministry of Health (MoH)",
  "Ministry of Social Development (MoSD)",
  "Ministry of Education and Training (MoET)",
  "Ministry of Water and Environment (MWE)",
  "Ministry of Agriculture, Food Security & Nutrition (MAFSN)",
];
const Technologies = ["Map", "Histogram", "Donut Chart"];

function Dashboard() {
  const [isMinimized, setIsMinimized] = useState(false);
  const [selectedStat, setSelectedStat] = useState("stunting");
  const [selectedItem, setSelectedItem] = useState("ALL");
  const [isOpen, setIsOpen] = useState(false);
  const [isSmallScreen, setIsSmallScreen] = useState(window.innerWidth < 768);
  const [typedLocation, setTypedLocation] = useState("");
  const [typedTime, setTypedTime] = useState("");
  const [selectedFilter, setSelectedFilter] = useState([]);
  const [selectedMinistry, setSelectedMinistry] = useState("Ministry");
  const [typedTech, setTypedTech] = useState("");
  const [selectedTech, setSelectedTech] = useState([]);
  const [selectedKeyItem, setSelectedKeyItem] = useState("Key Item");
  const [selectedFormat, setSelectedFormat] = useState("Format");
  const [includeAnalysis, setIncludeAnalysis] = useState(false);
  const [statusRange, setStatusRange] = useState("Last Month");
  const [selectedKeyResult, setSelectedKeyResult] = useState(0);
  const defaultKRA = "Infant and Young Child Feeding (IYCF)";

  const cardKeys = Object.keys(cardLabels);

  const statCardsData = [
    {
      statName: "stunting",
      title: "Prevalence of Stunting",
      subtitle: "(In children under 5 years of age)",
      value: 67,
      progress: 6,
      progressColor: "#dc3545",
    },
    {
      statName: "wasting",
      title: "Prevalence of Wasting",
      subtitle: "(In children under 5 years of age)",
      value: 81,
      progress: 61,
      progressColor: "29b664",
    },
    {
      statName: "underweight",
      title: "Prevalence of Underweight",
      subtitle: "(In children under 5 years of age)",
      value: 72,
      progress: 15,
      progressColor: "#e67e22",
    },
    {
      statName: "overweight",
      title: "Proportion of children",
      subtitle: "under 5 years of age who are overweight/obese",
      value: 56,
      progress: 17,
      progressColor: "#019ed3",
    },
  ];

  const formats = ["PDF", "DOC"];

  const handleCardClick = (statName) => {
    setSelectedStat(statName);
  };

  const handleSelect = (eventKey) => {
    setSelectedItem(eventKey);
  };

  const handleMinistry = (eventKey) => {
    setSelectedMinistry(eventKey);
  };

  useEffect(() => {
    const handleResize = () => {
      setIsSmallScreen(window.innerWidth < 768);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const handleSearchChange = (e) => {
    setTypedLocation(e.target.value);
  };

  const handleAddCustomLocation = () => {
    if (
      typedLocation &&
      !selectedFilter.includes(typedLocation) &&
      !Locations.includes(typedLocation)
    ) {
      setSelectedFilter([...selectedFilter, typedLocation]);
      setTypedLocation("");
    }
  };

  const handleSelectLocation = (location) => {
    if (!selectedFilter.includes(location)) {
      setSelectedFilter([...selectedFilter, location]);
    }
  };

  const handleSelectTime = (time) => {
    if (!selectedFilter.includes(time)) {
      setSelectedFilter([...selectedFilter, time]);
    }
  };

  const handleRemoveItem = (item) => {
    setSelectedFilter(
      selectedFilter.filter((selectedItem) => selectedItem !== item)
    );
  };

  const handleSelectMinistry = (ministry) => {
    if (!selectedFilter.includes(ministry)) {
      setSelectedFilter([...selectedFilter, ministry]);
    }
    // setSelectedMinistry(ministry);  Update dropdown label
  };

  const handleAddTech = (tech) => {
    if (tech && !selectedTech.includes(tech)) {
      setSelectedTech([...selectedTech, tech]);
    }
  };

  // Remove Tech from the selected list
  const handleRemoveTech = (tech) => {
    setSelectedTech(selectedTech.filter((item) => item !== tech));
  };

  const handleIncludeAnalysisChange = (e) =>
    setIncludeAnalysis(e.target.checked);

  const handleKeyItemSelect = (item) => {
    setSelectedKeyItem(item);
  };

  const handleFormatSelect = (format) => {
    setSelectedFormat(format);
  };

  const handleSaveReport = () => {
    console.log("Saving report...");
  };

  const handleGenerateReport = () => {
    console.log("Generating report...");
  };

  const handleStatusRangeChange = (range) => {
    setStatusRange(range);
  };

  const data = [
    {
      keyResultArea: "Infant and Young Child Feeding (IYCF)",
      percentage: 34,
      status: "-0.5%",
    },
    {
      keyResultArea: "Micronutrient Supplementation",
      percentage: 21,
      status: "+2.1%",
    },
    {
      keyResultArea: "Maternal and Child Health",
      percentage: 17,
      status: "-1.3%",
    },
    { keyResultArea: "Food Value Chain", percentage: 12, status: "+1.3%" },
    {
      keyResultArea: "Water, Sanitation, and Hygiene (WASH)",
      percentage: 29,
      status: "+3%",
    },
    { keyResultArea: "Social Protection", percentage: 6, status: "+2%" },
    {
      keyResultArea: "Gender Equality and Female Empowerment",
      percentage: 9,
      status: "+1%",
    },
    {
      keyResultArea: "Nutrition in Emergencies",
      percentage: 1,
      status: "+0.2%",
    },
    {
      keyResultArea: "Strengthening Clinical Services",
      percentage: 1.7,
      status: "-0.3%",
    },
    { keyResultArea: "Capacity Building", percentage: 2, status: "-0.2%" },
    { keyResultArea: "Enabling Environment", percentage: 1.5, status: "+0.3%" },
  ];

  const handleSelectkya = (index) => {
    setSelectedKeyResult(index); // Set the selected row index
  };

  const selectedKRA = data[selectedKeyResult]?.keyResultArea || defaultKRA;

  const statusOptions = ["Last Month", "Last Quarter", "Last Year"];

  const indicatorLabel = cardLabels[selectedStat];

  console.log(indicatorLabel);
  return (
    <div className={`dashboard ${isMinimized ? "sidebar-minimized" : ""}`}>
      {/* Sidebar */}
      <Sidebar />

      <div className="main-content">
        <Topbar />

        {/* Dashboard */}
        <div className="dashboard-content">
          <div className="toolsTitle-container">
            <span className="toolsTitle">
              Nutritional <span style={{ color: "#168645" }}>Status</span>
            </span>
          </div>

          {/* Impact Level Indicators stat-cards */}
          <div className="stats-cards">
            {statCardsData.map((card) => (
              <StatCard
                key={card.statName}
                {...card}
                isSelected={selectedStat === card.statName}
                onClick={handleCardClick}
              />
            ))}
          </div>

          <div className="dashboard-visuals">
            <div className="visuals-content">
              <div className="goal-elements">
                <div className="sidebar-section">
                  <span className="goal-elements-title">
                    {cardLabels[selectedStat] || "Select a statistic"}
                    <span style={{ color: "#168645", marginLeft: "5px" }}>
                      in Lesotho
                    </span>
                  </span>

                  <MapVisualizer selectedStat={cardLabels[selectedStat]} />
                </div>
              </div>
            </div>

            <div className="visuals-sidebar">
              <div className="sidebar-section">
                <span>FILTER</span>

                {selectedFilter.length > 0 && (
                  <div className="filter-choices">
                    <h5>Selected Items:</h5>

                    <ListGroup>
                      {selectedFilter.map((item, index) => (
                        <ListGroup.Item
                          key={index}
                          className="filter-choice-container"
                        >
                          {item}
                          <div
                            variant="outline-danger"
                            onClick={() => handleRemoveItem(item)}
                            className="filter-choice-btn"
                          >
                            <AiOutlineMinus
                              className="tech-item-minus-icon"
                              size={16}
                            />
                          </div>
                        </ListGroup.Item>
                      ))}
                    </ListGroup>
                  </div>
                )}

                <div className="filter-sectionOne">
                  <DropdownButton
                    id="dropdown-basic-button"
                    title="Location"
                    className="filter-dropdown"
                  >
                    {Locations.map((loc, index) => (
                      <Dropdown.Item
                        key={index}
                        onClick={() => handleSelectLocation(loc)}
                      >
                        {loc}
                      </Dropdown.Item>
                    ))}
                  </DropdownButton>

                  <DropdownButton
                    id="dropdown-basic-button"
                    title="Time"
                    className="filter-dropdown"
                  >
                    {Time.map((time, index) => (
                      <Dropdown.Item
                        key={index}
                        onClick={() => handleSelectTime(time)}
                      >
                        {time}
                      </Dropdown.Item>
                    ))}
                  </DropdownButton>
                </div>

                <button className="filterBtn">Filter</button>
              </div>

              <div className="sidebar-section">
                <span>VISUALIZATION TECHNIQUES</span>

                <div className="tech-sectionOne">
                  <div className="tech-item">
                    <span className="tech-item-add-text">Bar chart</span>

                    <div
                      className="tech-item-add"
                      onClick={() => handleAddTech("Bar chart")}
                    >
                      <AiOutlinePlus className="tech-item-add-icon" size={16} />
                    </div>
                  </div>

                  <div className="tech-item">
                    <span className="tech-item-add-text">Pie chart</span>

                    <div
                      className="tech-item-add"
                      onClick={() => handleAddTech("Pie chart")}
                    >
                      <AiOutlinePlus className="tech-item-add-icon" size={16} />
                    </div>
                  </div>
                </div>

                <div className="tech-sectionOne">
                  <div className="tech-item">
                    <span className="tech-item-add-text">Line graph</span>

                    <span
                      className="tech-item-add"
                      variant="outline-secondary"
                      onClick={() => handleAddTech("Choropleth map")}
                    >
                      <AiOutlinePlus className="tech-item-add-icon" size={16} />
                    </span>
                  </div>

                  <div className="dropdown-container">
                    <Dropdown onSelect={handleAddTech}>
                      <Dropdown.Toggle variant="light" id="dropdown-basic">
                        {selectedTech.length > 0
                          ? selectedTech[selectedTech.length - 1]
                          : "More.."}
                      </Dropdown.Toggle>

                      <Dropdown.Menu className="custom-dropdown-menu">
                        {Technologies.map((technology, index) => (
                          <Dropdown.Item key={index} eventKey={technology}>
                            {technology}
                          </Dropdown.Item>
                        ))}
                      </Dropdown.Menu>
                    </Dropdown>
                  </div>
                </div>

                {selectedTech.length > 0 && (
                  <div className="filter-choices">
                    <h5>Selected Items:</h5>

                    <ListGroup>
                      {selectedTech.map((item, index) => (
                        <ListGroup.Item
                          key={index}
                          className="filter-choice-container"
                        >
                          {item}

                          <div
                            variant="outline-danger"
                            onClick={() => handleRemoveTech(item)}
                            className="filter-choice-btn"
                          >
                            <AiOutlineMinus
                              className="tech-item-minus-icon"
                              size={16}
                            />
                          </div>
                        </ListGroup.Item>
                      ))}
                    </ListGroup>
                  </div>
                )}

                <button className="filterBtn">Visualize</button>
              </div>

              <div className="analyse-section">
                <div className="analyse-section-items">
                  <span>ANALYZE RESULTS</span>
                </div>

                <button className="analyzeBtn">Analyze</button>
              </div>

              <div className="sidebar-section">
                <span>GENERATE REPORT</span>

                <div className="report-options">
                  <Dropdown>
                    <Dropdown.Toggle variant="light" id="dropdown-format">
                      {selectedFormat}
                    </Dropdown.Toggle>

                    <Dropdown.Menu>
                      {formats.map((format, index) => (
                        <Dropdown.Item
                          key={index}
                          onClick={() => handleFormatSelect(format)}
                        >
                          {format}
                        </Dropdown.Item>
                      ))}
                    </Dropdown.Menu>
                  </Dropdown>

                  <div className="report-options">
                    <FormCheck
                      type="checkbox"
                      id="include-analysis"
                      label="Include Analysis"
                      checked={includeAnalysis}
                      onChange={handleIncludeAnalysisChange}
                    />
                  </div>
                </div>

                <div className="generate-options">
                  <Button
                    variant="outline-secondary"
                    onClick={handleSaveReport}
                  >
                    <MdOutlineSaveAlt /> Save
                  </Button>

                  <Button
                    variant="primary"
                    onClick={handleGenerateReport}
                    className="ml-2"
                  >
                    <RiAiGenerate /> Generate
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </div>
  );
}

export default Dashboard;
