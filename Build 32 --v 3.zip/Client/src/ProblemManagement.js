import React, { useState, useRef, useEffect } from "react";
import "./Tools.css";
import "./Documents.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import Footer from "./Footer";

const ProblemManagement = () => {
  const [selectedStat, setSelectedStat] = useState("fnco-templates");

  const handleCardClick = (statName) => {
    setSelectedStat(statName);
  };

  useEffect(() => {
    setSelectedStat("fnco-templates");
  }, []);

  return (
    <div className="tools">
      <Sidebar />
      <div className="main-content">
        <Topbar />

        <div className="dashboard-content">
          <div className="stats-cards">
            <div
              className={`stat-card ${
                selectedStat === "fnco-documents"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("fnco-documents")}
            >
              <div className="tools-stat-elements">
                <h6>Old, Unsolved Problems</h6>
                <label
                  className="stat-nutritional-value"
                  style={{ color: "#802319" }}
                >
                  12
                </label>
              </div>
            </div>

            <div
              className={`stat-card ${
                selectedStat === "fnco-templates"
                  ? "selected-card nutritionalStatus-border"
                  : ""
              }`}
              onClick={() => handleCardClick("fnco-templates")}
            >
              <div className="tools-stat-elements">
                <h6>New Problems</h6>
                <label
                  className="stat-nutritional-value"
                  style={{ color: "#b15d15" }}
                >
                  3
                </label>
              </div>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default ProblemManagement;
