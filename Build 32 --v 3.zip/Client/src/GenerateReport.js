import React, { useState, useRef } from "react";
import "./Tools.css";
import "./Documents.css";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  Button,
  InputGroup,
  FormControl,
  Dropdown,
  DropdownButton,
  ListGroup,
  Form,
  FormCheck,
  Table,
} from "react-bootstrap";
import { AiOutlineSearch } from "react-icons/ai";
import { AiOutlinePlus, AiOutlineMinus } from "react-icons/ai";
import { MdOutlineSaveAlt } from "react-icons/md";
import { FaRegEye } from "react-icons/fa";
import { FaDownload } from "react-icons/fa6";

const GenerateReport = () => {
  const [files, setFiles] = useState([]); // State to store uploaded files
  const fileInputRef = useRef(null); // Ref for the file input
  const [selectedFilter, setSelectedFilter] = useState([]);
  const [selectedTech, setSelectedTech] = useState([]);
  const [selectedItem, setSelectedItem] = useState("ALL");
  const [selectedKeyItem, setSelectedKeyItem] = useState("Report Type");
  const [selectedFormat, setSelectedFormat] = useState("Format");
  const [includeAnalysis, setIncludeAnalysis] = useState(false);
  const [selectedData, setSelectedData] = useState();
  const [selectedKra, setSelectedKra] = useState("");
  const [selectedIndicator, setSelectedIndicator] = useState("");

  const indicators = [
    "Prevalence of stunting in children under 5 years of age",
    "Prevalence of wasting in children under 5 years of age",
    "Prevalence of underweight in children under 5 years of age",
    "Proportion of children under 5 years of age who are overweight/obese",
  ];

  const kra = [
    "Infant and Young Child Feeding (IYCF)",
    "Micronutrient Supplementation",
    "Maternal and Child Health",
    "Food Value Chain",
    "Water, Sanitation, and Hygiene (WASH)",
    "Social Protection",
    "Gender Equality and Female Empowerment",
    "Nutrition in Emergencies",
    "Strengthening Clinical Services",
    "Capacity Building",
    "Enabling Environment",
  ];

  const kraOptions = {
    "Infant and Young Child Feeding (IYCF)": [
      "Proportion of children 0-6 months exclusively breastfed",
      "Proportion of children 6-23 months that are receiving continuing breastfeeding and adequate complementary feeding",
      "Proportion of children who breastfed within 1 hour of birth",
      "Proportion of children 6-23 months of age who receive a minimum acceptable diet (apart from breast milk)",
      "Proportion of children 6-23 months of age who consumed foods and beverages from at least 5 out of 10 defined food groups during the previous day",
      "Status of Nutritional assessment report (not started, underway, complete)",
      "Number of trainings conducted on nutritional preparation",
      "Number of participants trained on nutritional food preparation",
      "Number of sessions held for pregnant and/or lactating mothers",
      "Number of pregnant and lactating mothers who were reached through nutrition informative sessions",
      "Number of IYCF IEC materials distributed",
      "Number of  nutrition supplies distributed, by type (therapuetic foods, micronutrient powders (MNPs), calcium, deworming tablets, folate, iron, etc.)",
      "Number Fathers trained on the importance of IYCF",
      "Number of breastfeeding groups formed",
      "Number of nutrition clubs formed",
      "Status of Maternal, infant and young child Implementation plan (incomplete, underway, complete)",
      "Status of Lesotho Breastfeeding Promotion Network (inactive, underway, revived)",
      "Status of IYCF curriculumn (not started, underway, updated)",
      "Status of the Lesotho Code of Marketing of breastmilk substitutes, pacifiers and teats (not started, underway, developed)",
      "Status of the Baby firendly hospital initiative (not established, underway, established)",
    ],
    "Micronutrient Supplementation": [
      "Proportion of children under 5 years of age with vitamin A deficiency",
      "Proportion of anaemic children 6-59 months of age",
      "Proportion of iron-deficiency anaemia in women aged 15-49 years of age (by sex)",
      "Proportion of households with iodated salt",
      "Prevalence of iron-deficiency anaemia in children",
      "Proportion of children 6-23 months consuming foods rich in Vitamin A",
      "Vitamin A coverage in children 6-11 months/Proportion of children 6-11 months of age given Vitamin A supplementation",
      "Vitamin A coverage in children 6-59 months /Proportion of children 6-59 months of age given vitamin A supplementation",
      "Proportion of children 6-23 months of age who receive micro-nutrient powders supplementation in the last 6 months",
      "Proportion of children 6-59 months of age who received 1 iron pill (sometimes sprinkles or syrup) in the past 6 months",
      "Proportion of Children 12-59 months of age who receive 1 deworming treatment (tablets) in the past 6 months",
      "Proportion of women who took iron folate during the most recent pregnancy (everyday of pregnancy and 3 months post-partum)",
      "Proportion of children who attend monthly growth monitoring",
      "Number of Health workers and community members trained on fortification",
      "Number of health facilities with adequate Micronutrient Powders (MNPs) supplies",
      "Status of pilot study on Micronutrient Powders (MNPs), (not started, underway, complete)",
      "Number of Lactating mothers and caregivers trained on Micronutrient Powders (MNPs)",
      "Number of Children who received routine supplementation of vitamin A, iron folate, and deworming tablets",
      "Number of Homestead gardens constructed",
      "Number of Homestead gardens using bio-fortified seeds",
      "Number of routine food inspection visits",
      "Status of Legal framework on the regulation of food fortification and salt iodisation (not approved, underway, approved)",
    ],
    "Maternal and Child Health": [
      "Proportion of women who received post-natal check/visit within 2 days after delivery",
      "Proportion of children 12-23 months of age, who have received age appropriate immunizations according to national standards",
      "Proportion of women whose last delivery was attended by a skilled health personnel",
      "Proportion of women who received Ante Natal Care (ANC) within the first trimester from a skilled birth provider, in their most recent birth",
      "Proportion of women who received at least 8 Ante Natal Care (ANC) visits from a skilled birth provider in their most recent birth",
      "Proportion of women 15-49 years of age who are currently using a modern method of contraception",
      "HIV prevalence among women 15-49 years of age",
      "Number of  Campaigns held on Pre ANC, ANC, Post Natal Care (PNC) and family planning",
      "Number of  Women of child bearing age (15-49 years) reached through campaigns on Pre ANC, PNC, and family planning",
      "Number of  Women of child bearing age (15-49 years) reached through campaigns on Pre ANC, PNC, and family planning",
      "Number of  Fathers reached through campaigns on Pre ANC, PNC and family planning",
      "Number of  Community leaders reached through campaigns on Pre ANC, PNC, and family planning",
      "Number of  Community leaders reached through campaigns on Pre ANC, PNC, and family planning",
      "Number of  Campaigns held on the importance of immunization for under 5s",
      "Number of  People reached during campaigns on the importance of immunizations for under 5s",
      "Number of  People who received IEC materials on immunization",
      "Number of  Mobile clinics organized and providing maternal and child care services",
      "Number of  Women reached through mobile clinics",
      "Number of  Health facility staff trained on growth monitoring methods and referral systems",
      "Number of  VHWs trained on growth monitoring methods and referral systems",
      "Number of  People successfully referred for health services (by service type; identification, treatment, counselling, etc.)",
      "Number of  Revived mother support groups",
      "Number of  Newly established Mother support groups",
      "Number of  Children enrolled in community-based growth monitoring",
      "Number of  Adolescents and young people (10-24 years) reached with life skills sessions",
      "Number of  SADC laws on child marriage domesticated in Lesotho",
      "Adoption and roll-out of the adolescent nutrition information system",
      "Status of nutrition guidelines (not started, underway, complete)",
      "Status of Community needs assessment report (not started, underway, completed)",
      "Status of Timed Targeted Counselling (TTC) case study (not started, underway, complete)",
      "Number of  Health facilities supported with nutritional equipment",
      "Status of national nutrition website (not started, underway, functional)",
    ],
    "Food Value Chain": [
      "Proportion of the population that is food insecure",
      "Proportion of the population consuming foods rich in iron, zinc, and Vitamin A",
      "Proportion of the population living under the national poverty line",
      "Proportion of households with a moderate to high dietary diversity (low is 8% and moderate is 27% and high is 66%)",
      "Post-harvest loss rate for staple crops",
      "National cereal food deficit",
      "Proportion of farmers using organic farming methods",
      "Proportion children 6-23 months of age who consumed foods and beverages from at least 5 out of 10 defined food groups during the previous day",
      "Proportion of households consuming biofortified food products",
      "Proportion of households with diversified homestead production (productive fruit tree, productive vegetable plots and short-cycled animals)",
      "Proportion of households using post-harvest technologies (food preservations strategies)",
      "Proportion of households using climate smart agriculture",
      "Proportion Households using advanced storage technologies",
      "Number of  Farmers sensitised on bio-fortified seeds use",
      "Number of  Indigenous species identified for use, by type",
      "Number of  Trained participants on dietary diversity (disaggregated by cadre)",
      "Number of  Partnerships formed (disaggregated by entity)",
      "Number of  Individuals trained on climate smart agriculture approaches",
      "Number of  Households/individuals who received small livestock breeds",
      "Number of  Farmers trained on animal husbandry practices",
      "Number of  Veterinary staff trained",
      "Number of  Community participants reached with nutrition education",
      "Number of  Nutrition education activities conducted",
      "Number of  Farmers who received post-harvest storage  technology items",
      "Number of  Vegetable market stores constructed",
      "Number of  Smallholder farmer initiatives commercialized",
      "Number of  Local products substituting imports, by type",
      "Number of  Individuals capacitated to undertake businesses of cottage industries (disaggregated by gender)",
    ],
    "Water, Sanitation, and Hygiene (WASH)": [
      "Proportion of the population with access to improved source of drinking water, disaggregated by geographic location",
      "Proportion Households using a basic drinking-water source",
      "Proportion of the population with access to an improved sanitation facility",
      "Proportion of children under 5 that had diarrhoea in the 2 weeks preceding the survey who received ORS/treatment",
      "Proportion of households with access to basic hygiene services (water and soap present and available)",
      "Proportion of adolescents who practice good hygiene behavior, by sex",
      "Proportion of schools with basic sanitation services and student to latrine ratio",
      "Proportion of schools with inclusive sanitation facilities (learners with special needs)",
      "Proportion of schools with adequate menstrual hygiene facilities in place",
      "Proportion of schools with access to a basic drinking water source",
      "Proportion of schools with access to a basic handwashing facility",
      "Number of People reached with messaging on water storage and treatment",
      "Number of Hand washing facilities constructed, by geographic setting",
      "Number of People reached with messaging on Menstrual Health Management (MHM)",
      "Number of Female learners provided with MHM materials in schools",
      "Number of Water systems constructed (disaggregated by geographical setting)",
      "Number of sanitation facilities constructed, by geographic setting",
    ],
    "Social Protection": [
      "Proportion of pregnant women, nursing mothers, and children have access to health and nutrition services",
      "Proportion of children from poor and ultra-poor households covered by complementary health and nutrition services",
      "Proportion of pregnant mothers/mothers of infants from poor and ultra-poor households covered  by complementary health and nutrition services",
      "Proportion of mothers of children 0-6 months of age receiving infant grant who are practicing exclusive breastfeeding",
      "Proportion of households receiving social assistance who have a moderate to high dietary diversity (minimum is 8% and moderate is 27%, and 66% is low)",
      "Proportion of learners receiving a nutritious meal, disaggregated by gender (school feeding)",
      "Expansion rate of social protection programmes in Lesotho",
      "Proportion of identified individuals successfully enrolled into social assistance",
      "Proportion of beneficiaries eligible for graduation from social assistance",
      "Existence of multi-sector Task team TORs",
      "Number of  Members of multi-stakeholder task team",
      "Status of infant grants programme (not started, underway, completed)",
      "Status of NISSA modules (not started, underway, operational)",
      "Number of  Campaigns held on infant grant sensitization",
      "Number of  People reached through campaigns on infant grant sensitization",
      "Number of  Beneficiaries enrolled into social assistance, by type",
      "Amount of Cash transfers distributed, by type",
      "Status of a Nutrition mainstreaming plan (not started, underway, complete)",
      "Number of  TV slots on nutrition education",
      "Number of  Radio slots on nutrition education",
      "Number of  People reached with nutrition education",
      "Status of Social protection multi-sectoral M&E framework (not started, underway, complete)",
      "Number of  food and spending support visits conducted, by community council",
      "Number of  Community committee members trained on good feeding practices",
      "Number of  Nutrition community committees established",
      "Status of multi-sectoral information system (not started, underway, complete)",
      "Number of  Pregnant women reached during breastfeeding campaigns",
      "Number of  Mothers of under 2s reached during breastfeeding campaigns",
      "Number of Stakeholder meetings held on establishing and/or strengthening referral mechanisms",
      "Number of  Stakeholders who attended meetings on establishing and/or strengthening referral mechanisms, by cadre",
    ],
    "Gender Equality and Female Empowerment": [
      "Proportion of teen females married before the age of 18 years",
      "Proportion of women who were married before the age of 18 years",
      "Proportion of mothers and caregivers of children 0-23 months whose spouses are involved in optimal child feeding",
      "Proportion of mothers and caregivers of children 0-23 months whose spouses are involved in hygiene",
      "Proportion of mothers and caregivers of children 0-23 months whose spouses are involved in health care",
      "Proportion of women of child-bearing age and caregivers of under fives with access to appropriate labour-saving technologies for food production, processing, preservation, and preparation.",
      "Proportion of women who participate in their own decisions on their own healthcare, major household purchases and visits to family or relatives.",
      "Number of Public gatherings held on the importance of sharing responsibilities",
      "Number of IEC/BCC materials developed and translated on sharing responsibilities",
      "Number of IEC/BCC materials printed and distributed in communities on sharing responsibilities",
      "Number of  People reached who received IEC/BCC materials on sharing responsibilities",
      "Number of  Life skills trainings held for women",
      "Number of  Women trained on life skills",
      "Number of individuals who received IYCF manuals (fathers, grandmothers and mothers-in-law)",
      "Number of Individuals trained on the usage of the father support manual",
      "Number of  IYCF father-led groups established",
      "Number of  Forums held on the importance of male involvement in child care",
      "Number of Participants reached through forums on male involvement in child care",
      "Number of  Male champions selected",
      "Number of  Fun walks held",
      "Number of  Participants who attended the fun walk",
      "Number of Public gatherings held on labour-saving technologies",
      "Number of  Women reached during the public gatherings",
      "Number of Artisans trained on labour-saving technologies",
      "Number of  Labour-saving technologies developed",
      "Number of Water systems installed for household and home farming, by geogrpahic setting",
      "Number of  Dialogues held on ANC, PNC, PMTCT attendance by couples",
      "Number of Participants who attended dialogues on ANC, PNC, and PMTCT attendance by couples,  by cadre",
      "Status of compulsory ANC, PNC, and PMTCT couple attendance ‘standard/practice’ (not started, underway, complete)",
      "Number of  Women of child-bearng age (15-49 years) who received IEC materials on female empowerment strategies",
    ],
    "Nutrition in Emergencies": [
      "Proportion of people affected by emergencies who have access to adequately nutritious food",
      "Proportion of people from special population groups (pregnant and lactating women, children 6-23 months of ages with Prevalence of stunting in children under 5 years of age, HIV/TB patients) who have access to fortified blended food during emergencies",
      "Proportion of water points managed by VDMTs meeting quality standards",
      "Proportion of (a) moderate (b) severe or (c) acute Prevalence of stunting in children under 5 years of age cases of children 6-23 months of age identified during emergencies",
      "Proportion of (a) moderate (b) severe or c) acute Prevalence of stunting in children under 5 years of age cases of pregnant and lactating mothers identified during emergencies",
      "Number of  Vulnerable households provided with food items",
      "Number of  Children 6-24 months provided fortified foods",
      "Number of  Pregnant and lactating mothers provided with fortified foods",
      "Number of  Malnourished TB patients provided with fortified foods",
      "Number of  Vulnerable households provided with cash transfers",
      "Number of  Children 6-59 months who received therapeutic feeding supplies",
      "Number of  Severely acute malnourished HIV/TB patients who received therapeutic feeding supplies",
      "Number of  Households who received hygiene kits",
      "Number of  Household who received water testing kits",
      "Number of  Tankers procured",
      "Number of  Storage tanks procured",
      "Number of  Temporary toilets mounted in areas prone to open defecation",
      "Number of  VDMTs trained on water management and water hygiene practices",
      "Number of  VDMTs trained on emergencies related health and nutrition issues",
      "Number of  VHWs trained on emergencies related health and nutrition issues",
      "Number of  VDMTs trained on concepts of disaster risk reduction and development of contingency plans, and preparedness and response plan",
      "Status of the Community owned vulnerability and capacity assessment (not started, underway, complete)",
      "Number of  Community disaster plans",
      "Number of  Disaster relief committees revived",
      "Number of periodical coordination and monitoring meetings held",
    ],
    "Strengthening Clinical Services": [
      "Proportion of health facilities adopting food service and nutrition guidelines",
      "Proportion of health facilities providing quality nutrition services for communicable (HIV&AIDS, TB, etc.) and non-communicable diseases",
      "Proportion of adult population practicing at least two or a combination of the top 5 healthy lifestyles",
      "Number of Trainings conducted for health professionals on food service and nutrition guidelines",
      "Number of Health professionals trained on food service and guidelines, by cadre",
      "Number of Health professionals trained on food service and guidelines, by cadre",
      "Number of  Health equipment distributed to health facilities, by type",
      "Number of Health facilities who received health equipment",
      "Number of nutrition IEC/BCC materials developed",
      "Number of nutrition IEC/BCC materials disseminated",
      "Status of BCC strategy (not started, underway, complete)",
      "Number of  Health days held",
      "Number of  People who attended health days",
      "Number of  Organisations who had health screening wellness days",
      "Number of  People screened during wellness days",
      "Curricula inclusive of NCDs",
      "Status of nutrition (not started, underway, complete)",
      "Number of  Wellness clinics established",
      "Status of Nutrition assessment (not started, underway, complete)",
      "Number of  Screening campaigns conducted",
      "Number of people reached through screening campaigns",
    ],
    "Capacity Building": [
      "Operational status food and nutrition coordinating framework implemented at community, district and national levels",
      "Operational status of the Lesotho Food and nutrition society",
      "Percentage Sectors with nutrition integrated into the sector plans and being implemented",
      "Percentage Partners with improved capacity to implement food and nutrition interventions",
      "Number of  Nutritionists reached with in-service training",
      "Number of Programme support staff (including field cadre) who are involved in nutrition service delivery and completed basic nutrition in-service training (TOTs, short courses, or external consultant-led trainings)",
      "Status of Stakeholder mapping analysis (not started, underway, complete)",
      "Status of National advocacy plan (not started, underway, complete)",
      "Number of food and nutrition Legal frameworks produced and approved",
      "Number of  Sector policies revised to mainstream nutrition",
      "Number of  Nutrition coordination meetings (with reports on progress made in implementation and resolutions)",
      "Number of  SUN networks established",
      "Number of  Sun focal point meetings held per year",
    ],
    "Enabling Environment": [
      "Proportion of national budget allocated to nutrition",
      "Proportion of funds from donors allocated for food and nutrition programming",
      "Operational status of food and nutrition information in the country and against global standards",
      "Operational status of food and nutrition legal frameworks, guidelines and standards endorsed by parliament and  cabinet (not started, underway, endorsed)",
      "Number of  Dialogues held with multi-sectoral stakeholders on nutrition budgeting",
      "Number of  Dialogues held with high level authorities (ministers, parlimentarians) on nutrition budgeting",
      "Number of meetings held with development partners on nutrition mainstreaming and budgeting",
      "Number of Development partners who participated in meetings on nutrition mainstreaming and budgeting",
      "Number of Meetings held with legal practitioners on nutrition mainstreaming",
      "Status of M&E results framework for food and nutrition services (not started, underway, complete)",
      "Number of  Meetings held by FNCO for nutrition stakeholders",
      "Status of food and nutrition bill (not started, underway adopted)",
      "Status of Regulations and standards on food and nutrition standards (not started, underway, complete)",
      "Number of  Food and nutrition policy reviews held",
      "Number of Participants who participated in the food and nutrition policy reviews, by cadre",
      "Number of  Curriculum reviews",
      "Existence of Terms of reference (TORs) for overseeing bodies (committees, society)",
      "Number of  Members of the surveillance team",
      "Number of food and nutrition surveillance results/findings dissemination meetings held",
      "Number of  Nutrition research papers published/ case studies",
      "Number of  People trained on the surveillance system",
      "Status of SUN system in (active, inactive)",
    ],
  };

  const Locations = [
    "Butha-Buthe",
    "Berea",
    "Leribe",
    "Maseru",
    "Mafeteng",
    "Mohales Hoek",
    "Quthing",
    "Qachas Nek",
    "Mokhotlong",
    "Thaba-Tseka",
  ];
  const Time = [
    "2017",
    "2018",
    "2019",
    "2020",
    "2021",
    "2022",
    "2023",
    "2024",
    "Last Month",
    "Last Quarter",
  ];

  const Technologies = [
    "Histogram",
    "Donut Chart",
    "Waterfall Chart",
    "Area Chart",
    "Choropleth Map",
  ];

  const keyItems = [
    "Summary Reports",
    "Performance Metrics",
    "Comparative Analysis",
  ];

  const formats = ["PDF", "PNG", "JPEG", "DOC", "XLS"];

  const handleIndicatorSelect = (indicator) => {
    setSelectedIndicator(indicator);
  };

  const handleKRASelect = (kraName, option) => {
    setSelectedIndicator(`${kraName}: ${option}`);
  };

  const handleAddFile = (event) => {
    const newFile = event.target.files[0];
    if (newFile) {
      setFiles((prevFiles) => [...prevFiles, newFile]);
    }
  };

  const handleDeleteFile = (fileName) => {
    setFiles((prevFiles) => prevFiles.filter((file) => file.name !== fileName));
  };

  const handleRemoveItem = (item) => {
    setSelectedFilter(
      selectedFilter.filter((selectedItem) => selectedItem !== item)
    );
  };

  const handleSelectLocation = (location) => {
    if (!selectedFilter.includes(location)) {
      setSelectedFilter([...selectedFilter, location]);
    }
  };

  const handleSelectTime = (time) => {
    if (!selectedFilter.includes(time)) {
      setSelectedFilter([...selectedFilter, time]);
    }
  };

  const handleAddTech = (tech) => {
    if (tech && !selectedTech.includes(tech)) {
      setSelectedTech([...selectedTech, tech]);
    }
  };

  // Remove Tech from the selected list
  const handleRemoveTech = (tech) => {
    setSelectedTech(selectedTech.filter((item) => item !== tech));
  };

  const handleSelect = (eventKey) => {
    setSelectedItem(eventKey);
  };

  const handleKeyItemSelect = (item) => {
    setSelectedKeyItem(item);
  };

  const handleFormatSelect = (format) => {
    setSelectedFormat(format);
  };

  const handleIncludeAnalysisChange = (e) =>
    setIncludeAnalysis(e.target.checked);

  const handleSaveReport = () => {
    console.log("Saving report...");
  };

  const handleGenerateReport = () => {
    console.log("Generating report...");
  };

  return (
    <div className="templates">
      <div className="templates-header">
        <div className="generate-report-title">
          <span className="toolsTitle" style={{ color: "#14773d" }}>
            Generate Report
          </span>

          <div className="select-indicator-container">
            {selectedIndicator && (
              <p>
                <span style={{ color: "#14773d" }}>For:</span>{" "}
                {selectedIndicator}
              </p>
            )}
          </div>
        </div>

        <button className="add-document-btn" title="Preview before Generating">
          <FaRegEye /> Preview
        </button>
      </div>

      <div className="dashboard-visuals">
        <div className="visuals-content">
          <div className="sidebar-section">
            <span className="visualizer-kra-title">
              Impact Level Indicators
            </span>

            <table className="custom-table">
              <tbody>
                {indicators.map((indicator, index) => (
                  <tr key={index}>
                    <td className="text-center">
                      <input
                        type="radio"
                        name="indicator"
                        id={`indicator-${index}`}
                        onChange={() => handleIndicatorSelect(indicator)}
                      />
                    </td>
                    <td>{indicator}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="sidebar-section">
            <span className="visualizer-kra-title">Key Result Areas</span>
            <table className="custom-table">
              <tbody>
                {kra.map((kraName, index) => (
                  <tr key={index}>
                    <td className="text-center">
                      <input
                        type="radio"
                        name="indicator"
                        id={`indicator-${index}`}
                        onChange={() => handleIndicatorSelect(kraName)}
                      />
                    </td>
                    <td>
                      <select
                        defaultValue=""
                        onChange={(e) =>
                          handleKRASelect(kraName, e.target.value)
                        }
                        style={{ border: "none" }}
                      >
                        <option value="" disabled>
                          {kraName}
                        </option>
                        {kraOptions[kraName]?.map((option, optionIndex) => (
                          <option key={optionIndex} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="visuals-sidebar">
          <div className="sidebar-section">
            <span>FILTER</span>

            {selectedFilter.length > 0 && (
              <div className="filter-choices">
                <h5>Selected Items:</h5>

                <ListGroup>
                  {selectedFilter.map((item, index) => (
                    <ListGroup.Item
                      key={index}
                      className="filter-choice-container"
                    >
                      {item}
                      <div
                        variant="outline-danger"
                        onClick={() => handleRemoveItem(item)}
                        className="filter-choice-btn"
                      >
                        <AiOutlineMinus
                          className="tech-item-minus-icon"
                          size={16}
                        />
                      </div>
                    </ListGroup.Item>
                  ))}
                </ListGroup>
              </div>
            )}

            <div className="filter-sectionOne">
              <DropdownButton
                id="dropdown-basic-button"
                title="Location"
                className="filter-dropdown"
              >
                {Locations.map((loc, index) => (
                  <Dropdown.Item
                    key={index}
                    onClick={() => handleSelectLocation(loc)}
                  >
                    {loc}
                  </Dropdown.Item>
                ))}
              </DropdownButton>

              <DropdownButton
                id="dropdown-basic-button"
                title="Time"
                className="filter-dropdown"
              >
                {Time.map((time, index) => (
                  <Dropdown.Item
                    key={index}
                    onClick={() => handleSelectTime(time)}
                  >
                    {time}
                  </Dropdown.Item>
                ))}
              </DropdownButton>
            </div>
          </div>

          <div className="sidebar-section">
            <span>VISUALIZATION TECHNIQUES</span>

            <div className="tech-sectionOne">
              <div className="tech-item">
                <span className="tech-item-add-text">Bar chart</span>

                <div
                  className="tech-item-add"
                  onClick={() => handleAddTech("Bar chart")}
                >
                  <AiOutlinePlus className="tech-item-add-icon" size={16} />
                </div>
              </div>

              <div className="tech-item">
                <span className="tech-item-add-text">Pie chart</span>

                <div
                  className="tech-item-add"
                  onClick={() => handleAddTech("Pie chart")}
                >
                  <AiOutlinePlus className="tech-item-add-icon" size={16} />
                </div>
              </div>
            </div>

            <div className="tech-sectionOne">
              <div className="tech-item">
                <span className="tech-item-add-text">Line graph</span>

                <span
                  className="tech-item-add"
                  variant="outline-secondary"
                  onClick={() => handleAddTech("Line graph")}
                >
                  <AiOutlinePlus className="tech-item-add-icon" size={16} />
                </span>
              </div>

              <div className="dropdown-container">
                <Dropdown onSelect={handleAddTech}>
                  <Dropdown.Toggle variant="light" id="dropdown-basic">
                    {selectedTech.length > 0
                      ? selectedTech[selectedTech.length - 1]
                      : "More.."}
                  </Dropdown.Toggle>

                  <Dropdown.Menu className="custom-dropdown-menu">
                    {Technologies.map((technology, index) => (
                      <Dropdown.Item key={index} eventKey={technology}>
                        {technology}
                      </Dropdown.Item>
                    ))}
                  </Dropdown.Menu>
                </Dropdown>
              </div>
            </div>

            {selectedTech.length > 0 && (
              <div className="filter-choices">
                <h5>Selected Items:</h5>

                <ListGroup>
                  {selectedTech.map((item, index) => (
                    <ListGroup.Item
                      key={index}
                      className="filter-choice-container"
                    >
                      {item}

                      <div
                        variant="outline-danger"
                        onClick={() => handleRemoveTech(item)}
                        className="filter-choice-btn"
                      >
                        <AiOutlineMinus
                          className="tech-item-minus-icon"
                          size={16}
                        />
                      </div>
                    </ListGroup.Item>
                  ))}
                </ListGroup>
              </div>
            )}
          </div>

          <div className="sidebar-section">
            <span>GENERATE REPORT</span>

            <div className="report-options">
              <Dropdown>
                <Dropdown.Toggle variant="light" id="dropdown-key-item">
                  {selectedKeyItem}
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  {keyItems.map((item, index) => (
                    <Dropdown.Item
                      key={index}
                      onClick={() => handleKeyItemSelect(item)}
                    >
                      {item}
                    </Dropdown.Item>
                  ))}
                </Dropdown.Menu>
              </Dropdown>

              <Dropdown>
                <Dropdown.Toggle variant="light" id="dropdown-format">
                  {selectedFormat}
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  {formats.map((format, index) => (
                    <Dropdown.Item
                      key={index}
                      onClick={() => handleFormatSelect(format)}
                    >
                      {format}
                    </Dropdown.Item>
                  ))}
                </Dropdown.Menu>
              </Dropdown>
            </div>

            <div className="report-options">
              <FormCheck
                type="checkbox"
                id="include-analysis"
                label="Include Analysis"
                checked={includeAnalysis}
                onChange={handleIncludeAnalysisChange}
              />
            </div>

            <div className="generate-options">
              <Button variant="outline-secondary" onClick={handleSaveReport}>
                <MdOutlineSaveAlt /> Save
              </Button>

              <Button
                variant="primary"
                onClick={handleGenerateReport}
                className="ml-2"
              >
                <FaDownload /> Download
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GenerateReport;
